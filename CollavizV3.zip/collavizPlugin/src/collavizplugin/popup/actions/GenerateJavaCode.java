package collavizplugin.popup.actions;


import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import collaviz_generator.mainPackage.KerRichFactory;
import collaviz_generator.mainPackage.MainClass;
import collavizplugin.Activator;

public class GenerateJavaCode implements IObjectActionDelegate {

	private Shell shell;
	
	//the current project
	private IProject project = null;
	//the generation folder
	private IFolder folder;
	//the selected file
	private IFile file;
	
	/**
	 * Constructor for Action1.
	 */
	public GenerateJavaCode() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		if(project!=null){
			findFolder();
			try{
				if (!project.exists()) project.create(null);
				if (!project.isOpen()) project.open(null);
				if (!folder.exists()) 
				    folder.create(IResource.NONE, true, null);
				
				// use a console for stdio
				k2.io.StdIO$.MODULE$.messagingSystem_$eq(Activator.getDefault().getMessaggingSystem());
				// make sure to load with kermeta factory, (ie. with kermeta aspects)
				collaviz_generatorrunner.DefaultRunner$.MODULE$.init4eclipse();
  
				
				//kermeta code
				MainClass m = KerRichFactory.createMainClass();
				m.mainOperation(file.getLocationURI().toString(), folder.getLocationURI().toString());

				//refresh folder
				folder.refreshLocal(IResource.DEPTH_INFINITE, new NullProgressMonitor()); 
				
			}catch(Exception e){
				Activator.getDefault().getMessaggingSystem().error(e.getMessage(), Activator.PLUGIN_ID, e);
				e.printStackTrace();
			}
		}
		MessageDialog.openInformation(
			shell,
			"CollavizPlugin",
			"Generate Java Code was executed");
	}

	//find the Generation folder
	private void findFolder() {
		
		folder  = file.getParent().getFolder(new Path("Generation"));

	}

	//this method retrieve the selected file and the current project

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		if(!selection.isEmpty()){
			try{
				StructuredSelection s = (StructuredSelection) selection;
				IFile f = (IFile) s.getFirstElement();
				this.file = f;
				this.project  = f.getProject();
			}catch(Exception e){
				e.printStackTrace();
			}			
		}
	}

}
