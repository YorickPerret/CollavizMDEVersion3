/**
 */
package CollavizInstance.provider;


import Collaviz.*;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.DependencyInstance;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link CollavizInstance.DependencyInstance} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class DependencyInstanceItemProvider
	extends ItemProviderAdapter
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DependencyInstanceItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addInstanceOfPropertyDescriptor(object);
			addTargetPropertyDescriptor(object);
			addNamePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Instance Of feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	/*protected void addInstanceOfPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_DependencyInstance_instanceOf_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_DependencyInstance_instanceOf_feature", "_UI_DependencyInstance_type"),
				 CollavizInstancePackage.Literals.DEPENDENCY_INSTANCE__INSTANCE_OF,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}
	*/
	
	protected void addInstanceOfPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(new ItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_DependencyInstance_instanceOf_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_DependencyInstance_instanceOf_feature", "_UI_DependencyInstance_type"),
				 CollavizInstancePackage.Literals.DEPENDENCY_INSTANCE__INSTANCE_OF,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null)
			{
		        @Override
		        public Collection<?> getChoiceOfValues(Object object)
		        {
			          List<Object> choiceOfValues = new	LinkedList<Object>(super.getChoiceOfValues(object));
			          // Filter the choices before returning them.
			          List<Object> selected = new LinkedList<Object>();
			          try{
						//l'instance de la d�pendance
						DependencyInstance d = (DependencyInstance) object;
						
						//l'instance de l'objet
						CollavizObjectInstance objectInstance = (CollavizObjectInstance) d.eContainer();

						
						//pour chaque item, est ce qu'il est valide ?
						Iterator<Object> it = choiceOfValues.iterator();
						 while(it.hasNext()){
							 Object next = it.next();
							 if(isValidChoice(objectInstance, d, next)){
								 selected.add(next);
							 }
						 }
			          }catch(Exception e){
						e.printStackTrace();
			          }
			          return selected;
		        }

				private boolean isValidChoice(CollavizObjectInstance objectInstance, DependencyInstance d, Object choice) {
				
					if(choice instanceof Dependency){
						Dependency c = (Dependency) choice;
						CollavizObject co = objectInstance.getInstanceOf();
						if(compare(co,c)){
							return true;
						}
						
						//superTypes
						
						EList<CollavizObject> superTypes = co.getAllSuperTypes();
						Iterator<CollavizObject> it = superTypes.iterator();
						while(it.hasNext()){
							if(compare(it.next(),c)){
								return true;
							}
						}
					}
					return false;
				}
				
		      }
			);
	}

	private boolean compare(CollavizObject co, Dependency c) {
		// TODO Auto-generated method stub
		EList<GenericAttribute> lga = co.getAttributes(); 
		Iterator<GenericAttribute> it = lga.iterator();
		while(it.hasNext()){
			GenericAttribute ga = it.next();
			//ga.getName().equals(c.getName())
			if(ga.equals(c)){
				return true;
			}
		}
		return false;
	}

	/**
	 * This adds a property descriptor for the Target feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	/*protected void addTargetPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_DependencyInstance_target_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_DependencyInstance_target_feature", "_UI_DependencyInstance_type"),
				 CollavizInstancePackage.Literals.DEPENDENCY_INSTANCE__TARGET,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}
	*/
	
	  protected void addTargetPropertyDescriptor(Object object)
	  {
	    itemPropertyDescriptors.add
	      (new ItemPropertyDescriptor
	        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
	         getResourceLocator(),
	         getString("_UI_DependencyInstance_target_feature"),
	         getString("_UI_PropertyDescriptor_description", "_UI_DependencyInstance_target_feature", "_UI_DependencyInstance_type"),
	         CollavizInstancePackage.Literals.DEPENDENCY_INSTANCE__TARGET,
	         true,
	         false,
	         true,
	         null,
	         null,
	         null)
	       {
	        @Override
	        public Collection<?> getChoiceOfValues(Object object)
	        {
	          List<Object> choiceOfValues = new	LinkedList<Object>(super.getChoiceOfValues(object));
	          // Filter the choices before returning them.
	          List<Object> selected = new LinkedList<Object>();
	          try{
				//l'instance de la d�pendance
				DependencyInstance d = (DependencyInstance) object;
				
				//pour chaque item, est ce qu'il est valide ?
				Iterator<Object> it = choiceOfValues.iterator();
				 while(it.hasNext()){
					 Object next = it.next();
					 if(isValidChoice(d, next)){
						 selected.add(next);
					 }
				 }
	          }catch(Exception e){
				e.printStackTrace();
	          }
	          return selected;
	         }

			private boolean isValidChoice(DependencyInstance d, Object choice) {
				try{
					CollavizObjectInstance c = (CollavizObjectInstance) choice;
					EList<CollavizObject> supertypes = c.getInstanceOf().getAllSuperTypes();
					Iterator<CollavizObject> it = supertypes.iterator();

					if(c.getInstanceOf().getName().equals(d.getInstanceOf().getType().getName())){
						return true;
					}
					while(it.hasNext()){
						CollavizObject next = it.next();
						if(next.getName().equals(d.getInstanceOf().getType().getName())){
							return true;
						}
					}
				}
				catch(Exception e){
					e.printStackTrace();
				}
					
				return false;
			}

			
	      });
	  }
	

	/**
	 * This adds a property descriptor for the Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_DependencyInstance_name_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_DependencyInstance_name_feature", "_UI_DependencyInstance_type"),
				 CollavizInstancePackage.Literals.DEPENDENCY_INSTANCE__NAME,
				 false,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This returns DependencyInstance.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/DependencyInstance"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((DependencyInstance)object).getName();
		return label == null || label.length() == 0 ?
			getString("_UI_DependencyInstance_type") :
			getString("_UI_DependencyInstance_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(DependencyInstance.class)) {
			case CollavizInstancePackage.DEPENDENCY_INSTANCE__NAME:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return CollavizInstanceEditPlugin.INSTANCE;
	}

}
