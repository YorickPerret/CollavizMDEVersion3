/**
 */
package CollavizInstance.provider;


import Collaviz.Attribute;
import Collaviz.CollavizObject;
import Collaviz.Dependency;
import Collaviz.GenericAttribute;
import CollavizInstance.AttributeInstance;
import CollavizInstance.CollavizInstanceFactory;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizObjectInstance;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link CollavizInstance.AttributeInstance} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class AttributeInstanceItemProvider
	extends ItemProviderAdapter
	implements
		IEditingDomainItemProvider,
		IStructuredItemContentProvider,
		ITreeItemContentProvider,
		IItemLabelProvider,
		IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeInstanceItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addInstanceOfPropertyDescriptor(object);
			addNamePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}



	/**
	 * This adds a property descriptor for the Instance Of feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
/*	protected void addInstanceOfPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_AttributeInstance_instanceOf_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_AttributeInstance_instanceOf_feature", "_UI_AttributeInstance_type"),
				 CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__INSTANCE_OF,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}
*/	
	protected void addInstanceOfPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(new ItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_AttributeInstance_instanceOf_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_AttributeInstance_instanceOf_feature", "_UI_AttributeInstance_type"),
				 CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__INSTANCE_OF,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null)
			{
		        @Override
		        public Collection<?> getChoiceOfValues(Object object)
		        {
			          List<Object> choiceOfValues = new	LinkedList<Object>(super.getChoiceOfValues(object));
			          // Filter the choices before returning them.
			          List<Object> selected = new LinkedList<Object>();
			          try{
						//l'instance de l'attribut
						AttributeInstance a = (AttributeInstance) object;
						
						//l'instance de l'objet
						CollavizObjectInstance objectInstance = (CollavizObjectInstance) a.eContainer();

						
						//pour chaque item, est ce qu'il est valide ?
						Iterator<Object> it = choiceOfValues.iterator();
						 while(it.hasNext()){
							 Object next = it.next();
							 if(isValidChoice(objectInstance, a, next)){
								 selected.add(next);
							 }
						 }
			          }catch(Exception e){
						e.printStackTrace();
			          }
			          return selected;
		        }

				private boolean isValidChoice(CollavizObjectInstance objectInstance, AttributeInstance a, Object choice) {
					if(choice instanceof Attribute){
						Attribute c = (Attribute) choice;
						CollavizObject co = objectInstance.getInstanceOf();
						if(compare(co,c)){
							return true;
						}
						
						//superTypes
						
						EList<CollavizObject> superTypes = co.getAllSuperTypes();
						Iterator<CollavizObject> it = superTypes.iterator();
						while(it.hasNext()){
							if(compare(it.next(),c)){
								return true;
							}
						}
					}
					return false;
				}
				
		      }
			);
	}

	/**
	 * This adds a property descriptor for the Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_AttributeInstance_name_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_AttributeInstance_name_feature", "_UI_AttributeInstance_type"),
				 CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__NAME,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	private boolean compare(CollavizObject co, Attribute c) {
		// TODO Auto-generated method stub
		EList<GenericAttribute> lga = co.getAttributes(); 
		Iterator<GenericAttribute> it = lga.iterator();
		while(it.hasNext()){
			GenericAttribute ga = it.next();
			//ga.getName().equals(c.getName())
			if(ga.equals(c)){
				return true;
			}
		}
		return false;
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	
	
	
	/**
	 * This returns AttributeInstance.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/AttributeInstance"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((AttributeInstance)object).getName();
		return label == null || label.length() == 0 ?
			getString("_UI_AttributeInstance_type") :
			getString("_UI_AttributeInstance_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(AttributeInstance.class)) {
			case CollavizInstancePackage.ATTRIBUTE_INSTANCE__NAME:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
			case CollavizInstancePackage.ATTRIBUTE_INSTANCE__VALUE:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createTransformEulerAngles()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createTransformEulerAnglesScale()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createTransformQuaternionScale()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createColor()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createIntegerInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createDoubleInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createBooleanInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createShortInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createStringInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createLongInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createFloatInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createCharInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createCollectionInstance()));

		newChildDescriptors.add
			(createChildParameter
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE__VALUE,
				 CollavizInstanceFactory.eINSTANCE.createTreeInstance()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return CollavizInstanceEditPlugin.INSTANCE;
	}

}
