/**
 */
package Collaviz.tests;

import Collaviz.GenericType;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Generic Type</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class GenericTypeTest extends NamedElementTest {

	/**
	 * Constructs a new Generic Type test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GenericTypeTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Generic Type test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected GenericType getFixture() {
		return (GenericType)fixture;
	}

} //GenericTypeTest
