/**
 */
package Collaviz.tests;

import Collaviz.GenericAttribute;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Generic Attribute</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class GenericAttributeTest extends PresentableTest {

	/**
	 * Constructs a new Generic Attribute test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GenericAttributeTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Generic Attribute test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected GenericAttribute getFixture() {
		return (GenericAttribute)fixture;
	}

} //GenericAttributeTest
