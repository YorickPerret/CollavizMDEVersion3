/**
 */
package Collaviz.tests;

import Collaviz.Presentable;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Presentable</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class PresentableTest extends TestCase {

	/**
	 * The fixture for this Presentable test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Presentable fixture = null;

	/**
	 * Constructs a new Presentable test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PresentableTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Presentable test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Presentable fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Presentable test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Presentable getFixture() {
		return fixture;
	}

} //PresentableTest
