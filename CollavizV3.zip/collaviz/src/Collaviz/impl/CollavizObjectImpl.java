/**
 */
package Collaviz.impl;

import Collaviz.CollavizObject;
import Collaviz.CollavizPackage;
import Collaviz.GenericAttribute;
import Collaviz.Operation;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.WrappedException;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getSuperType <em>Super Type</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getOperations <em>Operations</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getAbstract <em>Abstract</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getJavaCode <em>Java Code</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getPresentable <em>Presentable</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getSuperInterfaces <em>Super Interfaces</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CollavizObjectImpl extends GenericTypeImpl implements CollavizObject {
	/**
	 * The cached value of the '{@link #getSuperType() <em>Super Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuperType()
	 * @generated
	 * @ordered
	 */
	protected CollavizObject superType;

	/**
	 * The cached value of the '{@link #getOperations() <em>Operations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperations()
	 * @generated
	 * @ordered
	 */
	protected EList<Operation> operations;

	/**
	 * The default value of the '{@link #getAbstract() <em>Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstract()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean ABSTRACT_EDEFAULT = Boolean.FALSE;

	/**
	 * The cached value of the '{@link #getAbstract() <em>Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstract()
	 * @generated
	 * @ordered
	 */
	protected Boolean abstract_ = ABSTRACT_EDEFAULT;

	/**
	 * The default value of the '{@link #getJavaCode() <em>Java Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJavaCode()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean JAVA_CODE_EDEFAULT = Boolean.TRUE;

	/**
	 * The cached value of the '{@link #getJavaCode() <em>Java Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJavaCode()
	 * @generated
	 * @ordered
	 */
	protected Boolean javaCode = JAVA_CODE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList<GenericAttribute> attributes;

	/**
	 * The default value of the '{@link #getPresentable() <em>Presentable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPresentable()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean PRESENTABLE_EDEFAULT = Boolean.TRUE;

	/**
	 * The cached value of the '{@link #getPresentable() <em>Presentable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPresentable()
	 * @generated
	 * @ordered
	 */
	protected Boolean presentable = PRESENTABLE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSuperInterfaces() <em>Super Interfaces</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuperInterfaces()
	 * @generated
	 * @ordered
	 */
	protected EList<CollavizObject> superInterfaces;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizPackage.Literals.COLLAVIZ_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObject getSuperType() {
		if (superType != null && superType.eIsProxy()) {
			InternalEObject oldSuperType = (InternalEObject)superType;
			superType = (CollavizObject)eResolveProxy(oldSuperType);
			if (superType != oldSuperType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE, oldSuperType, superType));
			}
		}
		return superType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObject basicGetSuperType() {
		return superType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSuperType(CollavizObject newSuperType) {
		CollavizObject oldSuperType = superType;
		superType = newSuperType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE, oldSuperType, superType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Operation> getOperations() {
		if (operations == null) {
			operations = new EObjectContainmentEList<Operation>(Operation.class, this, CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS);
		}
		return operations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getAbstract() {
		return abstract_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAbstract(Boolean newAbstract) {
		Boolean oldAbstract = abstract_;
		abstract_ = newAbstract;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT, oldAbstract, abstract_));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getJavaCode() {
		return javaCode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setJavaCode(Boolean newJavaCode) {
		Boolean oldJavaCode = javaCode;
		javaCode = newJavaCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE, oldJavaCode, javaCode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GenericAttribute> getAttributes() {
		if (attributes == null) {
			attributes = new EObjectContainmentEList<GenericAttribute>(GenericAttribute.class, this, CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getPresentable() {
		return presentable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPresentable(Boolean newPresentable) {
		Boolean oldPresentable = presentable;
		presentable = newPresentable;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__PRESENTABLE, oldPresentable, presentable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CollavizObject> getSuperInterfaces() {
		if (superInterfaces == null) {
			superInterfaces = new EObjectResolvingEList<CollavizObject>(CollavizObject.class, this, CollavizPackage.COLLAVIZ_OBJECT__SUPER_INTERFACES);
		}
		return superInterfaces;
	}

	/**
	 * The cached invocation delegate for the '{@link #getAllSuperTypes() <em>Get All Super Types</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAllSuperTypes()
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate GET_ALL_SUPER_TYPES__EINVOCATION_DELEGATE = ((EOperation.Internal)CollavizPackage.Literals.COLLAVIZ_OBJECT.getEOperations().get(0)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public EList<CollavizObject> getAllSuperTypes() {
		try {
			return (EList<CollavizObject>)GET_ALL_SUPER_TYPES__EINVOCATION_DELEGATE.dynamicInvoke(this, null);
		}
		catch (InvocationTargetException ite) {
			throw new WrappedException(ite);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				return ((InternalEList<?>)getOperations()).basicRemove(otherEnd, msgs);
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				return ((InternalEList<?>)getAttributes()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				if (resolve) return getSuperType();
				return basicGetSuperType();
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				return getOperations();
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				return getAbstract();
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				return getJavaCode();
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				return getAttributes();
			case CollavizPackage.COLLAVIZ_OBJECT__PRESENTABLE:
				return getPresentable();
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_INTERFACES:
				return getSuperInterfaces();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				setSuperType((CollavizObject)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				getOperations().clear();
				getOperations().addAll((Collection<? extends Operation>)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				setAbstract((Boolean)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				setJavaCode((Boolean)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				getAttributes().clear();
				getAttributes().addAll((Collection<? extends GenericAttribute>)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__PRESENTABLE:
				setPresentable((Boolean)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_INTERFACES:
				getSuperInterfaces().clear();
				getSuperInterfaces().addAll((Collection<? extends CollavizObject>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				setSuperType((CollavizObject)null);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				getOperations().clear();
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				setAbstract(ABSTRACT_EDEFAULT);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				setJavaCode(JAVA_CODE_EDEFAULT);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				getAttributes().clear();
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__PRESENTABLE:
				setPresentable(PRESENTABLE_EDEFAULT);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_INTERFACES:
				getSuperInterfaces().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				return superType != null;
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				return operations != null && !operations.isEmpty();
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				return ABSTRACT_EDEFAULT == null ? abstract_ != null : !ABSTRACT_EDEFAULT.equals(abstract_);
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				return JAVA_CODE_EDEFAULT == null ? javaCode != null : !JAVA_CODE_EDEFAULT.equals(javaCode);
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				return attributes != null && !attributes.isEmpty();
			case CollavizPackage.COLLAVIZ_OBJECT__PRESENTABLE:
				return PRESENTABLE_EDEFAULT == null ? presentable != null : !PRESENTABLE_EDEFAULT.equals(presentable);
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_INTERFACES:
				return superInterfaces != null && !superInterfaces.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (abstract: ");
		result.append(abstract_);
		result.append(", javaCode: ");
		result.append(javaCode);
		result.append(", presentable: ");
		result.append(presentable);
		result.append(')');
		return result.toString();
	}

} //CollavizObjectImpl
