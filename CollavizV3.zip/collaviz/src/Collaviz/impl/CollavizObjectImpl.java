/**
 */
package Collaviz.impl;

import Collaviz.CollavizObject;
import Collaviz.CollavizPackage;
import Collaviz.GenericAttribute;
import Collaviz.GenericType;
import Collaviz.NamedElement;
import Collaviz.Operation;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getName <em>Name</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getSuperType <em>Super Type</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getOperations <em>Operations</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getAbstract <em>Abstract</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getJavaCode <em>Java Code</em>}</li>
 *   <li>{@link Collaviz.impl.CollavizObjectImpl#getAttributes <em>Attributes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CollavizObjectImpl extends PresentableImpl implements CollavizObject {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSuperType() <em>Super Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuperType()
	 * @generated
	 * @ordered
	 */
	protected CollavizObject superType;

	/**
	 * The cached value of the '{@link #getOperations() <em>Operations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperations()
	 * @generated
	 * @ordered
	 */
	protected EList<Operation> operations;

	/**
	 * The default value of the '{@link #getAbstract() <em>Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstract()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean ABSTRACT_EDEFAULT = Boolean.FALSE;

	/**
	 * The cached value of the '{@link #getAbstract() <em>Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstract()
	 * @generated
	 * @ordered
	 */
	protected Boolean abstract_ = ABSTRACT_EDEFAULT;

	/**
	 * The default value of the '{@link #getJavaCode() <em>Java Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJavaCode()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean JAVA_CODE_EDEFAULT = Boolean.TRUE;

	/**
	 * The cached value of the '{@link #getJavaCode() <em>Java Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJavaCode()
	 * @generated
	 * @ordered
	 */
	protected Boolean javaCode = JAVA_CODE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList<GenericAttribute> attributes;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizPackage.Literals.COLLAVIZ_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObject getSuperType() {
		if (superType != null && superType.eIsProxy()) {
			InternalEObject oldSuperType = (InternalEObject)superType;
			superType = (CollavizObject)eResolveProxy(oldSuperType);
			if (superType != oldSuperType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE, oldSuperType, superType));
			}
		}
		return superType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObject basicGetSuperType() {
		return superType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSuperType(CollavizObject newSuperType) {
		CollavizObject oldSuperType = superType;
		superType = newSuperType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE, oldSuperType, superType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Operation> getOperations() {
		if (operations == null) {
			operations = new EObjectContainmentEList<Operation>(Operation.class, this, CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS);
		}
		return operations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getAbstract() {
		return abstract_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAbstract(Boolean newAbstract) {
		Boolean oldAbstract = abstract_;
		abstract_ = newAbstract;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT, oldAbstract, abstract_));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getJavaCode() {
		return javaCode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setJavaCode(Boolean newJavaCode) {
		Boolean oldJavaCode = javaCode;
		javaCode = newJavaCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE, oldJavaCode, javaCode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GenericAttribute> getAttributes() {
		if (attributes == null) {
			attributes = new EObjectContainmentEList<GenericAttribute>(GenericAttribute.class, this, CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				return ((InternalEList<?>)getOperations()).basicRemove(otherEnd, msgs);
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				return ((InternalEList<?>)getAttributes()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__NAME:
				return getName();
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				if (resolve) return getSuperType();
				return basicGetSuperType();
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				return getOperations();
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				return getAbstract();
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				return getJavaCode();
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				return getAttributes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__NAME:
				setName((String)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				setSuperType((CollavizObject)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				getOperations().clear();
				getOperations().addAll((Collection<? extends Operation>)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				setAbstract((Boolean)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				setJavaCode((Boolean)newValue);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				getAttributes().clear();
				getAttributes().addAll((Collection<? extends GenericAttribute>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				setSuperType((CollavizObject)null);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				getOperations().clear();
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				setAbstract(ABSTRACT_EDEFAULT);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				setJavaCode(JAVA_CODE_EDEFAULT);
				return;
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				getAttributes().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizPackage.COLLAVIZ_OBJECT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CollavizPackage.COLLAVIZ_OBJECT__SUPER_TYPE:
				return superType != null;
			case CollavizPackage.COLLAVIZ_OBJECT__OPERATIONS:
				return operations != null && !operations.isEmpty();
			case CollavizPackage.COLLAVIZ_OBJECT__ABSTRACT:
				return ABSTRACT_EDEFAULT == null ? abstract_ != null : !ABSTRACT_EDEFAULT.equals(abstract_);
			case CollavizPackage.COLLAVIZ_OBJECT__JAVA_CODE:
				return JAVA_CODE_EDEFAULT == null ? javaCode != null : !JAVA_CODE_EDEFAULT.equals(javaCode);
			case CollavizPackage.COLLAVIZ_OBJECT__ATTRIBUTES:
				return attributes != null && !attributes.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == NamedElement.class) {
			switch (derivedFeatureID) {
				case CollavizPackage.COLLAVIZ_OBJECT__NAME: return CollavizPackage.NAMED_ELEMENT__NAME;
				default: return -1;
			}
		}
		if (baseClass == GenericType.class) {
			switch (derivedFeatureID) {
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == NamedElement.class) {
			switch (baseFeatureID) {
				case CollavizPackage.NAMED_ELEMENT__NAME: return CollavizPackage.COLLAVIZ_OBJECT__NAME;
				default: return -1;
			}
		}
		if (baseClass == GenericType.class) {
			switch (baseFeatureID) {
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", abstract: ");
		result.append(abstract_);
		result.append(", javaCode: ");
		result.append(javaCode);
		result.append(')');
		return result.toString();
	}

} //CollavizObjectImpl
