/**
 */
package Collaviz.impl;

import Collaviz.Attribute;
import Collaviz.CollavizFactory;
import Collaviz.CollavizModel;
import Collaviz.CollavizObject;
import Collaviz.CollavizPackage;
import Collaviz.Dependency;
import Collaviz.ExistClass;
import Collaviz.GenericAttribute;
import Collaviz.GenericType;
import Collaviz.NamedElement;
import Collaviz.Operation;
import Collaviz.Parameter;
import Collaviz.SimpleType;
import Collaviz.Type;
import Collaviz.TypedElement;

import Collaviz.util.CollavizValidator;

import CollavizInstance.CollavizInstancePackage;

import CollavizInstance.impl.CollavizInstancePackageImpl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizPackageImpl extends EPackageImpl implements CollavizPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dependencyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass typeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass operationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass parameterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass existClassEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass namedElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass typedElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass genericTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass genericAttributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType booleanEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType doubleEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType integerEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType stringEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see Collaviz.CollavizPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CollavizPackageImpl() {
		super(eNS_URI, CollavizFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link CollavizPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CollavizPackage init() {
		if (isInited) return (CollavizPackage)EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI);

		// Obtain or create and register package
		CollavizPackageImpl theCollavizPackage = (CollavizPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof CollavizPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new CollavizPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		CollavizInstancePackageImpl theCollavizInstancePackage = (CollavizInstancePackageImpl)(EPackage.Registry.INSTANCE.getEPackage(CollavizInstancePackage.eNS_URI) instanceof CollavizInstancePackageImpl ? EPackage.Registry.INSTANCE.getEPackage(CollavizInstancePackage.eNS_URI) : CollavizInstancePackage.eINSTANCE);

		// Create package meta-data objects
		theCollavizPackage.createPackageContents();
		theCollavizInstancePackage.createPackageContents();

		// Initialize created meta-data
		theCollavizPackage.initializePackageContents();
		theCollavizInstancePackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theCollavizPackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return CollavizValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theCollavizPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(CollavizPackage.eNS_URI, theCollavizPackage);
		return theCollavizPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizModel() {
		return collavizModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizModel_GenericTypes() {
		return (EReference)collavizModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizObject() {
		return collavizObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObject_SuperType() {
		return (EReference)collavizObjectEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObject_Operations() {
		return (EReference)collavizObjectEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObject_Abstract() {
		return (EAttribute)collavizObjectEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObject_JavaCode() {
		return (EAttribute)collavizObjectEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObject_Attributes() {
		return (EReference)collavizObjectEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObject_Presentable() {
		return (EAttribute)collavizObjectEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObject_SuperInterfaces() {
		return (EReference)collavizObjectEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDependency() {
		return dependencyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependency_Type() {
		return (EReference)dependencyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependency_Attributes() {
		return (EReference)dependencyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getType() {
		return typeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttribute() {
		return attributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttribute_Type() {
		return (EReference)attributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOperation() {
		return operationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOperation_Parameters() {
		return (EReference)operationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getParameter() {
		return parameterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimpleType() {
		return simpleTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExistClass() {
		return existClassEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getExistClass_Attributes() {
		return (EReference)existClassEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNamedElement() {
		return namedElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNamedElement_Name() {
		return (EAttribute)namedElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTypedElement() {
		return typedElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTypedElement_Type() {
		return (EReference)typedElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTypedElement_LowerBound() {
		return (EAttribute)typedElementEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTypedElement_UpperBound() {
		return (EAttribute)typedElementEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGenericType() {
		return genericTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGenericAttribute() {
		return genericAttributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGenericAttribute_LowerBound() {
		return (EAttribute)genericAttributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGenericAttribute_UpperBound() {
		return (EAttribute)genericAttributeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getboolean() {
		return booleanEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getdouble() {
		return doubleEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getInteger() {
		return integerEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getString() {
		return stringEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizFactory getCollavizFactory() {
		return (CollavizFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		collavizModelEClass = createEClass(COLLAVIZ_MODEL);
		createEReference(collavizModelEClass, COLLAVIZ_MODEL__GENERIC_TYPES);

		collavizObjectEClass = createEClass(COLLAVIZ_OBJECT);
		createEReference(collavizObjectEClass, COLLAVIZ_OBJECT__SUPER_TYPE);
		createEReference(collavizObjectEClass, COLLAVIZ_OBJECT__OPERATIONS);
		createEAttribute(collavizObjectEClass, COLLAVIZ_OBJECT__ABSTRACT);
		createEAttribute(collavizObjectEClass, COLLAVIZ_OBJECT__JAVA_CODE);
		createEReference(collavizObjectEClass, COLLAVIZ_OBJECT__ATTRIBUTES);
		createEAttribute(collavizObjectEClass, COLLAVIZ_OBJECT__PRESENTABLE);
		createEReference(collavizObjectEClass, COLLAVIZ_OBJECT__SUPER_INTERFACES);

		dependencyEClass = createEClass(DEPENDENCY);
		createEReference(dependencyEClass, DEPENDENCY__TYPE);
		createEReference(dependencyEClass, DEPENDENCY__ATTRIBUTES);

		typeEClass = createEClass(TYPE);

		attributeEClass = createEClass(ATTRIBUTE);
		createEReference(attributeEClass, ATTRIBUTE__TYPE);

		operationEClass = createEClass(OPERATION);
		createEReference(operationEClass, OPERATION__PARAMETERS);

		parameterEClass = createEClass(PARAMETER);

		simpleTypeEClass = createEClass(SIMPLE_TYPE);

		existClassEClass = createEClass(EXIST_CLASS);
		createEReference(existClassEClass, EXIST_CLASS__ATTRIBUTES);

		namedElementEClass = createEClass(NAMED_ELEMENT);
		createEAttribute(namedElementEClass, NAMED_ELEMENT__NAME);

		typedElementEClass = createEClass(TYPED_ELEMENT);
		createEReference(typedElementEClass, TYPED_ELEMENT__TYPE);
		createEAttribute(typedElementEClass, TYPED_ELEMENT__LOWER_BOUND);
		createEAttribute(typedElementEClass, TYPED_ELEMENT__UPPER_BOUND);

		genericTypeEClass = createEClass(GENERIC_TYPE);

		genericAttributeEClass = createEClass(GENERIC_ATTRIBUTE);
		createEAttribute(genericAttributeEClass, GENERIC_ATTRIBUTE__LOWER_BOUND);
		createEAttribute(genericAttributeEClass, GENERIC_ATTRIBUTE__UPPER_BOUND);

		// Create data types
		booleanEDataType = createEDataType(BOOLEAN);
		doubleEDataType = createEDataType(DOUBLE);
		integerEDataType = createEDataType(INTEGER);
		stringEDataType = createEDataType(STRING);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		collavizModelEClass.getESuperTypes().add(this.getNamedElement());
		collavizObjectEClass.getESuperTypes().add(this.getGenericType());
		dependencyEClass.getESuperTypes().add(this.getGenericAttribute());
		typeEClass.getESuperTypes().add(this.getGenericType());
		attributeEClass.getESuperTypes().add(this.getGenericAttribute());
		operationEClass.getESuperTypes().add(this.getTypedElement());
		parameterEClass.getESuperTypes().add(this.getTypedElement());
		simpleTypeEClass.getESuperTypes().add(this.getType());
		existClassEClass.getESuperTypes().add(this.getType());
		typedElementEClass.getESuperTypes().add(this.getNamedElement());
		genericTypeEClass.getESuperTypes().add(this.getNamedElement());
		genericAttributeEClass.getESuperTypes().add(this.getNamedElement());

		// Initialize classes and features; add operations and parameters
		initEClass(collavizModelEClass, CollavizModel.class, "CollavizModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizModel_GenericTypes(), this.getGenericType(), null, "genericTypes", null, 0, -1, CollavizModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(collavizObjectEClass, CollavizObject.class, "CollavizObject", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizObject_SuperType(), this.getCollavizObject(), null, "superType", null, 0, 1, CollavizObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObject_Operations(), this.getOperation(), null, "operations", null, 0, -1, CollavizObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObject_Abstract(), this.getboolean(), "abstract", "false", 1, 1, CollavizObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObject_JavaCode(), this.getboolean(), "javaCode", "true", 1, 1, CollavizObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObject_Attributes(), this.getGenericAttribute(), null, "attributes", null, 0, -1, CollavizObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObject_Presentable(), this.getboolean(), "presentable", "true", 1, 1, CollavizObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObject_SuperInterfaces(), this.getCollavizObject(), null, "superInterfaces", null, 0, -1, CollavizObject.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(collavizObjectEClass, this.getCollavizObject(), "getAllSuperTypes", 0, -1, !IS_UNIQUE, IS_ORDERED);

		initEClass(dependencyEClass, Dependency.class, "Dependency", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDependency_Type(), this.getCollavizObject(), null, "type", null, 1, 1, Dependency.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDependency_Attributes(), this.getAttribute(), null, "attributes", null, 0, -1, Dependency.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(typeEClass, Type.class, "Type", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(attributeEClass, Attribute.class, "Attribute", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttribute_Type(), this.getType(), null, "type", null, 1, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(operationEClass, Operation.class, "Operation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getOperation_Parameters(), this.getParameter(), null, "parameters", null, 0, -1, Operation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(parameterEClass, Parameter.class, "Parameter", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(simpleTypeEClass, SimpleType.class, "SimpleType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(existClassEClass, ExistClass.class, "ExistClass", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getExistClass_Attributes(), this.getAttribute(), null, "attributes", null, 0, -1, ExistClass.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(namedElementEClass, NamedElement.class, "NamedElement", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNamedElement_Name(), this.getString(), "name", null, 1, 1, NamedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(typedElementEClass, TypedElement.class, "TypedElement", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTypedElement_Type(), this.getGenericType(), null, "type", null, 1, 1, TypedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTypedElement_LowerBound(), this.getInteger(), "lowerBound", "0", 1, 1, TypedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTypedElement_UpperBound(), this.getInteger(), "upperBound", "1", 1, 1, TypedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(genericTypeEClass, GenericType.class, "GenericType", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(genericAttributeEClass, GenericAttribute.class, "GenericAttribute", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGenericAttribute_LowerBound(), this.getInteger(), "lowerBound", "0", 1, 1, GenericAttribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGenericAttribute_UpperBound(), this.getInteger(), "upperBound", "1", 1, 1, GenericAttribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize data types
		initEDataType(booleanEDataType, Boolean.class, "boolean", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(doubleEDataType, Double.class, "double", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(integerEDataType, Integer.class, "Integer", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(stringEDataType, String.class, "String", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL
		createOCLAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";		
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL"
		   });		
		addAnnotation
		  (collavizModelEClass, 
		   source, 
		   new String[] {
			 "constraints", "genericTypeIsUnique"
		   });			
		addAnnotation
		  (collavizObjectEClass, 
		   source, 
		   new String[] {
			 "constraints", "SuperTypeOrNoJavaCode operationIsUnique attributeIsUnique"
		   });				
		addAnnotation
		  (operationEClass, 
		   source, 
		   new String[] {
			 "constraints", "parameterIsUnique"
		   });			
		addAnnotation
		  (existClassEClass, 
		   source, 
		   new String[] {
			 "constraints", "attributeClassIsUnique"
		   });			
		addAnnotation
		  (namedElementEClass, 
		   source, 
		   new String[] {
			 "constraints", "nameNotEmpty"
		   });			
		addAnnotation
		  (typedElementEClass, 
		   source, 
		   new String[] {
			 "constraints", "LowerUpperBound"
		   });			
		addAnnotation
		  (genericAttributeEClass, 
		   source, 
		   new String[] {
			 "constraints", "LowerUpperBound"
		   });	
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createOCLAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL";				
		addAnnotation
		  (collavizModelEClass, 
		   source, 
		   new String[] {
			 "genericTypeIsUnique", "self.genericTypes.name->forAll(n1 : String | self.genericTypes.name->count(n1) = 1)"
		   });			
		addAnnotation
		  (collavizObjectEClass, 
		   source, 
		   new String[] {
			 "SuperTypeOrNoJavaCode", "self.javaCode = false or self.superType <> null",
			 "operationIsUnique", "self.operations.name->forAll(n1 : String | self.operations.name->count(n1) = 1)",
			 "attributeIsUnique", "let attributesName : Sequence(String) = self.getAllSuperTypes().attributes.name->union(self.attributes.name)\r\nin\r\nattributesName->forAll(n1 : String | attributesName->count(n1) = 1)"
		   });		
		addAnnotation
		  (collavizObjectEClass.getEOperations().get(0), 
		   source, 
		   new String[] {
			 "body", "if self.superType.oclIsUndefined() then\r\nSequence{}\r\nelse\r\nSequence{self.superType}->union(self.superType.getAllSuperTypes())\r\nendif"
		   });			
		addAnnotation
		  (operationEClass, 
		   source, 
		   new String[] {
			 "parameterIsUnique", "self.parameters.name->forAll(n1 : String | self.parameters.name->count(n1) = 1)"
		   });			
		addAnnotation
		  (existClassEClass, 
		   source, 
		   new String[] {
			 "attributeClassIsUnique", "self.attributes.name->forAll(n1 : String | self.attributes.name->count(n1) = 1)"
		   });			
		addAnnotation
		  (namedElementEClass, 
		   source, 
		   new String[] {
			 "nameNotEmpty", "if not(self.name.oclIsUndefined()) then\r\n\tself.name.size()>0\r\nelse\r\n\tfalse\r\nendif"
		   });			
		addAnnotation
		  (typedElementEClass, 
		   source, 
		   new String[] {
			 "LowerUpperBound", "self.lowerBound <= self.upperBound or self.upperBound=-1"
		   });			
		addAnnotation
		  (genericAttributeEClass, 
		   source, 
		   new String[] {
			 "LowerUpperBound", "self.lowerBound <= self.upperBound or self.upperBound=-1"
		   });
	}

} //CollavizPackageImpl
