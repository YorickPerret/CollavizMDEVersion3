/**
 */
package Collaviz.impl;

import Collaviz.CollavizPackage;
import Collaviz.Presentable;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Presentable</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link Collaviz.impl.PresentableImpl#getPresentable <em>Presentable</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class PresentableImpl extends EObjectImpl implements Presentable {
	/**
	 * The default value of the '{@link #getPresentable() <em>Presentable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPresentable()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean PRESENTABLE_EDEFAULT = Boolean.TRUE;

	/**
	 * The cached value of the '{@link #getPresentable() <em>Presentable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPresentable()
	 * @generated
	 * @ordered
	 */
	protected Boolean presentable = PRESENTABLE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PresentableImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizPackage.Literals.PRESENTABLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getPresentable() {
		return presentable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPresentable(Boolean newPresentable) {
		Boolean oldPresentable = presentable;
		presentable = newPresentable;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizPackage.PRESENTABLE__PRESENTABLE, oldPresentable, presentable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizPackage.PRESENTABLE__PRESENTABLE:
				return getPresentable();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizPackage.PRESENTABLE__PRESENTABLE:
				setPresentable((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizPackage.PRESENTABLE__PRESENTABLE:
				setPresentable(PRESENTABLE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizPackage.PRESENTABLE__PRESENTABLE:
				return PRESENTABLE_EDEFAULT == null ? presentable != null : !PRESENTABLE_EDEFAULT.equals(presentable);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (presentable: ");
		result.append(presentable);
		result.append(')');
		return result.toString();
	}

} //PresentableImpl
