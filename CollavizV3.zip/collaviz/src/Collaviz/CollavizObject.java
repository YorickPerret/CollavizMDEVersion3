/**
 */
package Collaviz;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Collaviz.CollavizObject#getSuperType <em>Super Type</em>}</li>
 *   <li>{@link Collaviz.CollavizObject#getOperations <em>Operations</em>}</li>
 *   <li>{@link Collaviz.CollavizObject#getAbstract <em>Abstract</em>}</li>
 *   <li>{@link Collaviz.CollavizObject#getJavaCode <em>Java Code</em>}</li>
 *   <li>{@link Collaviz.CollavizObject#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link Collaviz.CollavizObject#getPresentable <em>Presentable</em>}</li>
 * </ul>
 * </p>
 *
 * @see Collaviz.CollavizPackage#getCollavizObject()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='SuperTypeOrNoJavaCode operationIsUnique attributeIsUnique'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL SuperTypeOrNoJavaCode='self.javaCode = false or self.superType <> null' operationIsUnique='self.operations.name->forAll(n1 : String | self.operations.name->count(n1) = 1)' attributeIsUnique='self.attributes.name->forAll(n1 : String | self.attributes.name->count(n1) = 1)'"
 * @generated
 */
public interface CollavizObject extends GenericType {
	/**
	 * Returns the value of the '<em><b>Super Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Super Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Super Type</em>' reference.
	 * @see #setSuperType(CollavizObject)
	 * @see Collaviz.CollavizPackage#getCollavizObject_SuperType()
	 * @model
	 * @generated
	 */
	CollavizObject getSuperType();

	/**
	 * Sets the value of the '{@link Collaviz.CollavizObject#getSuperType <em>Super Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Super Type</em>' reference.
	 * @see #getSuperType()
	 * @generated
	 */
	void setSuperType(CollavizObject value);

	/**
	 * Returns the value of the '<em><b>Operations</b></em>' containment reference list.
	 * The list contents are of type {@link Collaviz.Operation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operations</em>' containment reference list.
	 * @see Collaviz.CollavizPackage#getCollavizObject_Operations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operation> getOperations();

	/**
	 * Returns the value of the '<em><b>Abstract</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Abstract</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Abstract</em>' attribute.
	 * @see #setAbstract(Boolean)
	 * @see Collaviz.CollavizPackage#getCollavizObject_Abstract()
	 * @model default="false" dataType="Collaviz.boolean" required="true"
	 * @generated
	 */
	Boolean getAbstract();

	/**
	 * Sets the value of the '{@link Collaviz.CollavizObject#getAbstract <em>Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Abstract</em>' attribute.
	 * @see #getAbstract()
	 * @generated
	 */
	void setAbstract(Boolean value);

	/**
	 * Returns the value of the '<em><b>Java Code</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Java Code</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Java Code</em>' attribute.
	 * @see #setJavaCode(Boolean)
	 * @see Collaviz.CollavizPackage#getCollavizObject_JavaCode()
	 * @model default="true" dataType="Collaviz.boolean" required="true"
	 * @generated
	 */
	Boolean getJavaCode();

	/**
	 * Sets the value of the '{@link Collaviz.CollavizObject#getJavaCode <em>Java Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Java Code</em>' attribute.
	 * @see #getJavaCode()
	 * @generated
	 */
	void setJavaCode(Boolean value);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link Collaviz.GenericAttribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see Collaviz.CollavizPackage#getCollavizObject_Attributes()
	 * @model containment="true"
	 * @generated
	 */
	EList<GenericAttribute> getAttributes();

	/**
	 * Returns the value of the '<em><b>Presentable</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Presentable</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Presentable</em>' attribute.
	 * @see #setPresentable(Boolean)
	 * @see Collaviz.CollavizPackage#getCollavizObject_Presentable()
	 * @model default="true" dataType="Collaviz.boolean" required="true"
	 * @generated
	 */
	Boolean getPresentable();

	/**
	 * Sets the value of the '{@link Collaviz.CollavizObject#getPresentable <em>Presentable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Presentable</em>' attribute.
	 * @see #getPresentable()
	 * @generated
	 */
	void setPresentable(Boolean value);

} // CollavizObject
