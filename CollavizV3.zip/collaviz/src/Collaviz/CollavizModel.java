/**
 */
package Collaviz;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Collaviz.CollavizModel#getGenericTypes <em>Generic Types</em>}</li>
 * </ul>
 * </p>
 *
 * @see Collaviz.CollavizPackage#getCollavizModel()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='genericTypeIsUnique'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL genericTypeIsUnique='self.genericTypes.name->forAll(n1 : String | self.genericTypes.name->count(n1) = 1)'"
 * @generated
 */
public interface CollavizModel extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Generic Types</b></em>' containment reference list.
	 * The list contents are of type {@link Collaviz.GenericType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Generic Types</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Generic Types</em>' containment reference list.
	 * @see Collaviz.CollavizPackage#getCollavizModel_GenericTypes()
	 * @model containment="true"
	 * @generated
	 */
	EList<GenericType> getGenericTypes();

} // CollavizModel
