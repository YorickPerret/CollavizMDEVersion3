/**
 */
package Collaviz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generic Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Collaviz.GenericAttribute#getLowerBound <em>Lower Bound</em>}</li>
 *   <li>{@link Collaviz.GenericAttribute#getUpperBound <em>Upper Bound</em>}</li>
 * </ul>
 * </p>
 *
 * @see Collaviz.CollavizPackage#getGenericAttribute()
 * @model abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='LowerUpperBound'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL LowerUpperBound='self.lowerBound <= self.upperBound'"
 * @generated
 */
public interface GenericAttribute extends Presentable, NamedElement {
	/**
	 * Returns the value of the '<em><b>Lower Bound</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lower Bound</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lower Bound</em>' attribute.
	 * @see #setLowerBound(Integer)
	 * @see Collaviz.CollavizPackage#getGenericAttribute_LowerBound()
	 * @model default="0" dataType="Collaviz.Integer" required="true"
	 * @generated
	 */
	Integer getLowerBound();

	/**
	 * Sets the value of the '{@link Collaviz.GenericAttribute#getLowerBound <em>Lower Bound</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lower Bound</em>' attribute.
	 * @see #getLowerBound()
	 * @generated
	 */
	void setLowerBound(Integer value);

	/**
	 * Returns the value of the '<em><b>Upper Bound</b></em>' attribute.
	 * The default value is <code>"1"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Upper Bound</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Upper Bound</em>' attribute.
	 * @see #setUpperBound(Integer)
	 * @see Collaviz.CollavizPackage#getGenericAttribute_UpperBound()
	 * @model default="1" dataType="Collaviz.Integer" required="true"
	 * @generated
	 */
	Integer getUpperBound();

	/**
	 * Sets the value of the '{@link Collaviz.GenericAttribute#getUpperBound <em>Upper Bound</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Upper Bound</em>' attribute.
	 * @see #getUpperBound()
	 * @generated
	 */
	void setUpperBound(Integer value);

} // GenericAttribute
