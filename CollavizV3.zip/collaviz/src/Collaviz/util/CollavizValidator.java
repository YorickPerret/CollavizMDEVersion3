/**
 */
package Collaviz.util;

import Collaviz.*;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Diagnostician;
import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see Collaviz.CollavizPackage
 * @generated
 */
public class CollavizValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final CollavizValidator INSTANCE = new CollavizValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "Collaviz";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return CollavizPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case CollavizPackage.COLLAVIZ_MODEL:
				return validateCollavizModel((CollavizModel)value, diagnostics, context);
			case CollavizPackage.COLLAVIZ_OBJECT:
				return validateCollavizObject((CollavizObject)value, diagnostics, context);
			case CollavizPackage.DEPENDENCY:
				return validateDependency((Dependency)value, diagnostics, context);
			case CollavizPackage.TYPE:
				return validateType((Type)value, diagnostics, context);
			case CollavizPackage.ATTRIBUTE:
				return validateAttribute((Attribute)value, diagnostics, context);
			case CollavizPackage.OPERATION:
				return validateOperation((Operation)value, diagnostics, context);
			case CollavizPackage.PARAMETER:
				return validateParameter((Parameter)value, diagnostics, context);
			case CollavizPackage.SIMPLE_TYPE:
				return validateSimpleType((SimpleType)value, diagnostics, context);
			case CollavizPackage.EXIST_CLASS:
				return validateExistClass((ExistClass)value, diagnostics, context);
			case CollavizPackage.NAMED_ELEMENT:
				return validateNamedElement((NamedElement)value, diagnostics, context);
			case CollavizPackage.TYPED_ELEMENT:
				return validateTypedElement((TypedElement)value, diagnostics, context);
			case CollavizPackage.GENERIC_TYPE:
				return validateGenericType((GenericType)value, diagnostics, context);
			case CollavizPackage.GENERIC_ATTRIBUTE:
				return validateGenericAttribute((GenericAttribute)value, diagnostics, context);
			case CollavizPackage.BOOLEAN:
				return validateboolean((Boolean)value, diagnostics, context);
			case CollavizPackage.DOUBLE:
				return validatedouble((Double)value, diagnostics, context);
			case CollavizPackage.INTEGER:
				return validateInteger((Integer)value, diagnostics, context);
			case CollavizPackage.STRING:
				return validateString((String)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizModel(CollavizModel collavizModel, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(collavizModel, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(collavizModel, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizModel_genericTypeIsUnique(collavizModel, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the genericTypeIsUnique constraint of '<em>Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_MODEL__GENERIC_TYPE_IS_UNIQUE__EEXPRESSION = "self.genericTypes.name->forAll(n1 : String | self.genericTypes.name->count(n1) = 1)";

	/**
	 * Validates the genericTypeIsUnique constraint of '<em>Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizModel_genericTypeIsUnique(CollavizModel collavizModel, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.COLLAVIZ_MODEL,
				 collavizModel,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "genericTypeIsUnique",
				 COLLAVIZ_MODEL__GENERIC_TYPE_IS_UNIQUE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObject(CollavizObject collavizObject, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(collavizObject, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObject_SuperTypeOrNoJavaCode(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObject_operationIsUnique(collavizObject, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObject_attributeIsUnique(collavizObject, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the SuperTypeOrNoJavaCode constraint of '<em>Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT__SUPER_TYPE_OR_NO_JAVA_CODE__EEXPRESSION = "self.javaCode = false or self.superType <> null";

	/**
	 * Validates the SuperTypeOrNoJavaCode constraint of '<em>Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObject_SuperTypeOrNoJavaCode(CollavizObject collavizObject, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.COLLAVIZ_OBJECT,
				 collavizObject,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "SuperTypeOrNoJavaCode",
				 COLLAVIZ_OBJECT__SUPER_TYPE_OR_NO_JAVA_CODE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the operationIsUnique constraint of '<em>Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT__OPERATION_IS_UNIQUE__EEXPRESSION = "self.operations.name->forAll(n1 : String | self.operations.name->count(n1) = 1)";

	/**
	 * Validates the operationIsUnique constraint of '<em>Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObject_operationIsUnique(CollavizObject collavizObject, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.COLLAVIZ_OBJECT,
				 collavizObject,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "operationIsUnique",
				 COLLAVIZ_OBJECT__OPERATION_IS_UNIQUE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the attributeIsUnique constraint of '<em>Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT__ATTRIBUTE_IS_UNIQUE__EEXPRESSION = "let attributesName : Sequence(String) = self.getAllSuperTypes().attributes.name->union(self.attributes.name)\r\n" +
		"in\r\n" +
		"attributesName->forAll(n1 : String | attributesName->count(n1) = 1)";

	/**
	 * Validates the attributeIsUnique constraint of '<em>Object</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObject_attributeIsUnique(CollavizObject collavizObject, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.COLLAVIZ_OBJECT,
				 collavizObject,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "attributeIsUnique",
				 COLLAVIZ_OBJECT__ATTRIBUTE_IS_UNIQUE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDependency(Dependency dependency, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(dependency, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(dependency, diagnostics, context);
		if (result || diagnostics != null) result &= validateGenericAttribute_LowerUpperBound(dependency, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateType(Type type, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(type, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(type, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(type, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(type, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(type, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(type, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(type, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(type, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(type, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(type, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAttribute(Attribute attribute, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(attribute, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(attribute, diagnostics, context);
		if (result || diagnostics != null) result &= validateGenericAttribute_LowerUpperBound(attribute, diagnostics, context);
		return result;
	}


	private boolean validateTest(final Attribute attribute,
			DiagnosticChain diagnostics, final Map<Object, Object> context) {
		if(attribute.getName().equals("x")){
diagnostics.add(new Diagnostic() {
				
				@Override
				public String getSource() {
					// TODO Auto-generated method stub
					return "org.eclipse.emf.ecore";
				}
				
				@Override
				public int getSeverity() {
					// TODO Auto-generated method stub
					return Diagnostic.ERROR;
				}
				
				@Override
				public String getMessage() {
					// TODO Auto-generated method stub
					return "le nom x n'est pas autoris� ";
				}
				
				@Override
				public Throwable getException() {
					// TODO Auto-generated method stub
					return null;
				}
				
				@Override
				public List<?> getData() {
					// TODO Auto-generated method stub
					//LinkedList<CollavizModel> l = new LinkedList<CollavizModel>();
					//l.add((CollavizModel) context.get("org.eclipse.emf.ecore.EObject_NoCircularContainment"));
					LinkedList<Attribute> l = new LinkedList<Attribute>();
					l.add(attribute);
					return l;
				}
				
				@Override
				public int getCode() {
					// TODO Auto-generated method stub
					return 0;
				}
				
				@Override
				public List<Diagnostic> getChildren() {
					// TODO Auto-generated method stub
					/*LinkedList<Diagnostic> l = new LinkedList<Diagnostic>();
					l.add(new Diagnostic() {
						
						@Override
						public String getSource() {
							// TODO Auto-generated method stub
							return "Collaviz";
						}
						
						@Override
						public int getSeverity() {
							// TODO Auto-generated method stub
							return Diagnostic.ERROR;
						}
						
						@Override
						public String getMessage() {
							// TODO Auto-generated method stub
							return "The name x is not authorized";
						}
						
						@Override
						public Throwable getException() {
							// TODO Auto-generated method stub
							return null;
						}
						
						@Override
						public List<?> getData() {
							// TODO Auto-generated method stub
							LinkedList<Attribute> l = new LinkedList<Attribute>();
							l.add(attribute);
							return l;
						}
						
						@Override
						public int getCode() {
							// TODO Auto-generated method stub
							return 0;
						}
						
						@Override
						public List<Diagnostic> getChildren() {
							// TODO Auto-generated method stub
							return null;
						}
					});
					return l;
					*/
					return new LinkedList<>();
				}
			});
			return false;
		}
			
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOperation(Operation operation, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(operation, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validateTypedElement_LowerUpperBound(operation, diagnostics, context);
		if (result || diagnostics != null) result &= validateOperation_parameterIsUnique(operation, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the parameterIsUnique constraint of '<em>Operation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String OPERATION__PARAMETER_IS_UNIQUE__EEXPRESSION = "self.parameters.name->forAll(n1 : String | self.parameters.name->count(n1) = 1)";

	/**
	 * Validates the parameterIsUnique constraint of '<em>Operation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOperation_parameterIsUnique(Operation operation, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.OPERATION,
				 operation,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "parameterIsUnique",
				 OPERATION__PARAMETER_IS_UNIQUE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateParameter(Parameter parameter, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(parameter, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validateTypedElement_LowerUpperBound(parameter, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSimpleType(SimpleType simpleType, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(simpleType, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(simpleType, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(simpleType, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateExistClass(ExistClass existClass, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(existClass, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(existClass, diagnostics, context);
		if (result || diagnostics != null) result &= validateExistClass_attributeClassIsUnique(existClass, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the attributeClassIsUnique constraint of '<em>Exist Class</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String EXIST_CLASS__ATTRIBUTE_CLASS_IS_UNIQUE__EEXPRESSION = "self.attributes.name->forAll(n1 : String | self.attributes.name->count(n1) = 1)";

	/**
	 * Validates the attributeClassIsUnique constraint of '<em>Exist Class</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateExistClass_attributeClassIsUnique(ExistClass existClass, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.EXIST_CLASS,
				 existClass,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "attributeClassIsUnique",
				 EXIST_CLASS__ATTRIBUTE_CLASS_IS_UNIQUE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNamedElement(NamedElement namedElement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(namedElement, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(namedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(namedElement, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the nameNotEmpty constraint of '<em>Named Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String NAMED_ELEMENT__NAME_NOT_EMPTY__EEXPRESSION = "if not(self.name.oclIsUndefined()) then\r\n" +
		"\tself.name.size()>0\r\n" +
		"else\r\n" +
		"\tfalse\r\n" +
		"endif";

	/**
	 * Validates the nameNotEmpty constraint of '<em>Named Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNamedElement_nameNotEmpty(NamedElement namedElement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.NAMED_ELEMENT,
				 namedElement,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "nameNotEmpty",
				 NAMED_ELEMENT__NAME_NOT_EMPTY__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTypedElement(TypedElement typedElement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(typedElement, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(typedElement, diagnostics, context);
		if (result || diagnostics != null) result &= validateTypedElement_LowerUpperBound(typedElement, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the LowerUpperBound constraint of '<em>Typed Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TYPED_ELEMENT__LOWER_UPPER_BOUND__EEXPRESSION = "self.lowerBound <= self.upperBound or self.upperBound=-1";

	/**
	 * Validates the LowerUpperBound constraint of '<em>Typed Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTypedElement_LowerUpperBound(TypedElement typedElement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.TYPED_ELEMENT,
				 typedElement,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "LowerUpperBound",
				 TYPED_ELEMENT__LOWER_UPPER_BOUND__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGenericType(GenericType genericType, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(genericType, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(genericType, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(genericType, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGenericAttribute(GenericAttribute genericAttribute, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(genericAttribute, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validateNamedElement_nameNotEmpty(genericAttribute, diagnostics, context);
		if (result || diagnostics != null) result &= validateGenericAttribute_LowerUpperBound(genericAttribute, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the LowerUpperBound constraint of '<em>Generic Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String GENERIC_ATTRIBUTE__LOWER_UPPER_BOUND__EEXPRESSION = "self.lowerBound <= self.upperBound or self.upperBound=-1";

	/**
	 * Validates the LowerUpperBound constraint of '<em>Generic Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGenericAttribute_LowerUpperBound(GenericAttribute genericAttribute, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizPackage.Literals.GENERIC_ATTRIBUTE,
				 genericAttribute,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "LowerUpperBound",
				 GENERIC_ATTRIBUTE__LOWER_UPPER_BOUND__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateboolean(Boolean boolean_, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatedouble(Double double_, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInteger(Integer integer, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateString(String string, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //CollavizValidator
