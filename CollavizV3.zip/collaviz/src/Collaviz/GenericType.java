/**
 */
package Collaviz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generic Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Collaviz.CollavizPackage#getGenericType()
 * @model abstract="true"
 * @generated
 */
public interface GenericType extends NamedElement {
} // GenericType
