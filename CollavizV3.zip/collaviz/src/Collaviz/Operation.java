/**
 */
package Collaviz;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Collaviz.Operation#getParameters <em>Parameters</em>}</li>
 * </ul>
 * </p>
 *
 * @see Collaviz.CollavizPackage#getOperation()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='parameterIsUnique'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL parameterIsUnique='self.parameters.name->forAll(n1 : String | self.parameters.name->count(n1) = 1)'"
 * @generated
 */
public interface Operation extends TypedElement {
	/**
	 * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link Collaviz.Parameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameters</em>' containment reference list.
	 * @see Collaviz.CollavizPackage#getOperation_Parameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<Parameter> getParameters();

} // Operation
