/**
 */
package Collaviz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Collaviz.CollavizPackage#getType()
 * @model abstract="true"
 * @generated
 */
public interface Type extends GenericType {
} // Type
