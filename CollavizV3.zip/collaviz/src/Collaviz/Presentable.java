/**
 */
package Collaviz;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Presentable</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link Collaviz.Presentable#getPresentable <em>Presentable</em>}</li>
 * </ul>
 * </p>
 *
 * @see Collaviz.CollavizPackage#getPresentable()
 * @model abstract="true"
 * @generated
 */
public interface Presentable extends EObject {
	/**
	 * Returns the value of the '<em><b>Presentable</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Presentable</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Presentable</em>' attribute.
	 * @see #setPresentable(Boolean)
	 * @see Collaviz.CollavizPackage#getPresentable_Presentable()
	 * @model default="true" dataType="Collaviz.boolean" required="true"
	 * @generated
	 */
	Boolean getPresentable();

	/**
	 * Sets the value of the '{@link Collaviz.Presentable#getPresentable <em>Presentable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Presentable</em>' attribute.
	 * @see #getPresentable()
	 * @generated
	 */
	void setPresentable(Boolean value);

} // Presentable
