/**
 */
package Collaviz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Collaviz.CollavizPackage#getSimpleType()
 * @model
 * @generated
 */
public interface SimpleType extends Type {
} // SimpleType
