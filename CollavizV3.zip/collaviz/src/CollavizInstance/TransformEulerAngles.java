/**
 */
package CollavizInstance;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transform Euler Angles</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.TransformEulerAngles#getH <em>H</em>}</li>
 *   <li>{@link CollavizInstance.TransformEulerAngles#getP <em>P</em>}</li>
 *   <li>{@link CollavizInstance.TransformEulerAngles#getR <em>R</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAngles()
 * @model
 * @generated
 */
public interface TransformEulerAngles extends Transform {
	/**
	 * Returns the value of the '<em><b>H</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>H</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>H</em>' attribute.
	 * @see #setH(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAngles_H()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getH();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAngles#getH <em>H</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>H</em>' attribute.
	 * @see #getH()
	 * @generated
	 */
	void setH(Double value);

	/**
	 * Returns the value of the '<em><b>P</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>P</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>P</em>' attribute.
	 * @see #setP(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAngles_P()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getP();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAngles#getP <em>P</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>P</em>' attribute.
	 * @see #getP()
	 * @generated
	 */
	void setP(Double value);

	/**
	 * Returns the value of the '<em><b>R</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>R</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>R</em>' attribute.
	 * @see #setR(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAngles_R()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getR();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAngles#getR <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>R</em>' attribute.
	 * @see #getR()
	 * @generated
	 */
	void setR(Double value);

} // TransformEulerAngles
