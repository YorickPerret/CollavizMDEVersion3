/**
 */
package CollavizInstance;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Position9</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see CollavizInstance.CollavizInstancePackage#getPosition9()
 * @model
 * @generated
 */
public interface Position9 extends Position {

} // Position9
