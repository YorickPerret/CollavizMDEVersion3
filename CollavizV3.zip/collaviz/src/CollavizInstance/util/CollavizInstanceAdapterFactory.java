/**
 */
package CollavizInstance.util;

import CollavizInstance.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstancePackage
 * @generated
 */
public class CollavizInstanceAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static CollavizInstancePackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = CollavizInstancePackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizInstanceSwitch<Adapter> modelSwitch =
		new CollavizInstanceSwitch<Adapter>() {
			@Override
			public Adapter caseCollavizModelInstance(CollavizModelInstance object) {
				return createCollavizModelInstanceAdapter();
			}
			@Override
			public Adapter caseCollavizObjectInstance(CollavizObjectInstance object) {
				return createCollavizObjectInstanceAdapter();
			}
			@Override
			public Adapter caseDependencyInstance(DependencyInstance object) {
				return createDependencyInstanceAdapter();
			}
			@Override
			public Adapter caseAttributeInstance(AttributeInstance object) {
				return createAttributeInstanceAdapter();
			}
			@Override
			public Adapter caseTransform(Transform object) {
				return createTransformAdapter();
			}
			@Override
			public Adapter caseTransformEulerAngles(TransformEulerAngles object) {
				return createTransformEulerAnglesAdapter();
			}
			@Override
			public Adapter caseTransformEulerAnglesScale(TransformEulerAnglesScale object) {
				return createTransformEulerAnglesScaleAdapter();
			}
			@Override
			public Adapter caseTransformQuaternionScale(TransformQuaternionScale object) {
				return createTransformQuaternionScaleAdapter();
			}
			@Override
			public Adapter caseColor(Color object) {
				return createColorAdapter();
			}
			@Override
			public Adapter caseIntegerInstance(IntegerInstance object) {
				return createIntegerInstanceAdapter();
			}
			@Override
			public Adapter caseDoubleInstance(DoubleInstance object) {
				return createDoubleInstanceAdapter();
			}
			@Override
			public Adapter caseBooleanInstance(BooleanInstance object) {
				return createBooleanInstanceAdapter();
			}
			@Override
			public Adapter caseShortInstance(ShortInstance object) {
				return createShortInstanceAdapter();
			}
			@Override
			public Adapter caseStringInstance(StringInstance object) {
				return createStringInstanceAdapter();
			}
			@Override
			public Adapter caseLongInstance(LongInstance object) {
				return createLongInstanceAdapter();
			}
			@Override
			public Adapter caseFloatInstance(FloatInstance object) {
				return createFloatInstanceAdapter();
			}
			@Override
			public Adapter caseCharInstance(CharInstance object) {
				return createCharInstanceAdapter();
			}
			@Override
			public Adapter caseCollectionInstance(CollectionInstance object) {
				return createCollectionInstanceAdapter();
			}
			@Override
			public Adapter caseTreeInstance(TreeInstance object) {
				return createTreeInstanceAdapter();
			}
			@Override
			public Adapter caseValue(Value object) {
				return createValueAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.CollavizModelInstance <em>Collaviz Model Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.CollavizModelInstance
	 * @generated
	 */
	public Adapter createCollavizModelInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.CollavizObjectInstance <em>Collaviz Object Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.CollavizObjectInstance
	 * @generated
	 */
	public Adapter createCollavizObjectInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.DependencyInstance <em>Dependency Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.DependencyInstance
	 * @generated
	 */
	public Adapter createDependencyInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.AttributeInstance <em>Attribute Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.AttributeInstance
	 * @generated
	 */
	public Adapter createAttributeInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.Transform <em>Transform</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.Transform
	 * @generated
	 */
	public Adapter createTransformAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.TransformEulerAngles <em>Transform Euler Angles</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.TransformEulerAngles
	 * @generated
	 */
	public Adapter createTransformEulerAnglesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.TransformEulerAnglesScale <em>Transform Euler Angles Scale</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.TransformEulerAnglesScale
	 * @generated
	 */
	public Adapter createTransformEulerAnglesScaleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.TransformQuaternionScale <em>Transform Quaternion Scale</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.TransformQuaternionScale
	 * @generated
	 */
	public Adapter createTransformQuaternionScaleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.Color <em>Color</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.Color
	 * @generated
	 */
	public Adapter createColorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.IntegerInstance <em>Integer Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.IntegerInstance
	 * @generated
	 */
	public Adapter createIntegerInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.DoubleInstance <em>Double Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.DoubleInstance
	 * @generated
	 */
	public Adapter createDoubleInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.BooleanInstance <em>Boolean Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.BooleanInstance
	 * @generated
	 */
	public Adapter createBooleanInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.ShortInstance <em>Short Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.ShortInstance
	 * @generated
	 */
	public Adapter createShortInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.StringInstance <em>String Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.StringInstance
	 * @generated
	 */
	public Adapter createStringInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.LongInstance <em>Long Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.LongInstance
	 * @generated
	 */
	public Adapter createLongInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.FloatInstance <em>Float Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.FloatInstance
	 * @generated
	 */
	public Adapter createFloatInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.CharInstance <em>Char Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.CharInstance
	 * @generated
	 */
	public Adapter createCharInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.CollectionInstance <em>Collection Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.CollectionInstance
	 * @generated
	 */
	public Adapter createCollectionInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.TreeInstance <em>Tree Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.TreeInstance
	 * @generated
	 */
	public Adapter createTreeInstanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CollavizInstance.Value <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CollavizInstance.Value
	 * @generated
	 */
	public Adapter createValueAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //CollavizInstanceAdapterFactory
