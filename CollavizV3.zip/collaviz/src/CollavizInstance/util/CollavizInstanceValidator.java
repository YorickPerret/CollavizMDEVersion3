/**
 */
package CollavizInstance.util;

import CollavizInstance.*;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstancePackage
 * @generated
 */
public class CollavizInstanceValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final CollavizInstanceValidator INSTANCE = new CollavizInstanceValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "CollavizInstance";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return CollavizInstancePackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE:
				return validateCollavizModelInstance((CollavizModelInstance)value, diagnostics, context);
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE:
				return validateCollavizObjectInstance((CollavizObjectInstance)value, diagnostics, context);
			case CollavizInstancePackage.DEPENDENCY_INSTANCE:
				return validateDependencyInstance((DependencyInstance)value, diagnostics, context);
			case CollavizInstancePackage.ATTRIBUTE_INSTANCE:
				return validateAttributeInstance((AttributeInstance)value, diagnostics, context);
			case CollavizInstancePackage.STRING:
				return validateString((String)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizModelInstance(CollavizModelInstance collavizModelInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(collavizModelInstance, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObjectInstance(CollavizObjectInstance collavizObjectInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(collavizObjectInstance, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObjectInstance_DependencyMustBeSet(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObjectInstance_DependencyInstanceIsUnique(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObjectInstance_DependencyOnlyInObjectDefinition(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObjectInstance_AttributeMustBeSet(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObjectInstance_AttributeInstanceIsUnique(collavizObjectInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateCollavizObjectInstance_AttributeOnlyInObjectDefinition(collavizObjectInstance, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the DependencyMustBeSet constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT_INSTANCE__DEPENDENCY_MUST_BE_SET__EEXPRESSION = "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\n" +
		"in\r\n" +
		"let dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\n" +
		"in\r\n" +
		"let dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\n" +
		"in\r\n" +
		"let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\n" +
		"in\r\n" +
		"dependencies->forAll(d : Collaviz::GenericAttribute | dependenciesInstance->includes(d)) and dependencies->size() <= dependenciesInstance->size()";

	/**
	 * Validates the DependencyMustBeSet constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObjectInstance_DependencyMustBeSet(CollavizObjectInstance collavizObjectInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.COLLAVIZ_OBJECT_INSTANCE,
				 collavizObjectInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "DependencyMustBeSet",
				 COLLAVIZ_OBJECT_INSTANCE__DEPENDENCY_MUST_BE_SET__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the DependencyInstanceIsUnique constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT_INSTANCE__DEPENDENCY_INSTANCE_IS_UNIQUE__EEXPRESSION = "let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\n" +
		"in\r\n" +
		"dependenciesInstance->forAll(d1 : Collaviz::Dependency |  dependenciesInstance->count(d1)=1)";

	/**
	 * Validates the DependencyInstanceIsUnique constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObjectInstance_DependencyInstanceIsUnique(CollavizObjectInstance collavizObjectInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.COLLAVIZ_OBJECT_INSTANCE,
				 collavizObjectInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "DependencyInstanceIsUnique",
				 COLLAVIZ_OBJECT_INSTANCE__DEPENDENCY_INSTANCE_IS_UNIQUE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the DependencyOnlyInObjectDefinition constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT_INSTANCE__DEPENDENCY_ONLY_IN_OBJECT_DEFINITION__EEXPRESSION = "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\n" +
		"in\r\n" +
		"let dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\n" +
		"in\r\n" +
		"let dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\n" +
		"in\r\n" +
		"let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\n" +
		"in\r\n" +
		"dependenciesInstance->forAll(di : Collaviz::Dependency | dependencies->includes(di))";

	/**
	 * Validates the DependencyOnlyInObjectDefinition constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObjectInstance_DependencyOnlyInObjectDefinition(CollavizObjectInstance collavizObjectInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.COLLAVIZ_OBJECT_INSTANCE,
				 collavizObjectInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "DependencyOnlyInObjectDefinition",
				 COLLAVIZ_OBJECT_INSTANCE__DEPENDENCY_ONLY_IN_OBJECT_DEFINITION__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the AttributeMustBeSet constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTE_MUST_BE_SET__EEXPRESSION = "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\n" +
		"in\r\n" +
		"let attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\n" +
		"in\r\n" +
		"let attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\n" +
		"in\r\n" +
		"let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\n" +
		"in\r\n" +
		"attributes->forAll(a : Collaviz::GenericAttribute | attributesInstance->includes(a)) and attributes->size() <= attributesInstance->size()";

	/**
	 * Validates the AttributeMustBeSet constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObjectInstance_AttributeMustBeSet(CollavizObjectInstance collavizObjectInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.COLLAVIZ_OBJECT_INSTANCE,
				 collavizObjectInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "AttributeMustBeSet",
				 COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTE_MUST_BE_SET__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the AttributeInstanceIsUnique constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTE_INSTANCE_IS_UNIQUE__EEXPRESSION = "let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\n" +
		"in\r\n" +
		"attributesInstance->forAll(a : Collaviz::Attribute |  attributesInstance->count(a)=1)";

	/**
	 * Validates the AttributeInstanceIsUnique constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObjectInstance_AttributeInstanceIsUnique(CollavizObjectInstance collavizObjectInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.COLLAVIZ_OBJECT_INSTANCE,
				 collavizObjectInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "AttributeInstanceIsUnique",
				 COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTE_INSTANCE_IS_UNIQUE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the AttributeOnlyInObjectDefinition constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTE_ONLY_IN_OBJECT_DEFINITION__EEXPRESSION = "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\n" +
		"in\r\n" +
		"let attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\n" +
		"in\r\n" +
		"let attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\n" +
		"in\r\n" +
		"let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\n" +
		"in\r\n" +
		"attributesInstance->forAll(ai : Collaviz::Attribute | attributes->includes(ai))";

	/**
	 * Validates the AttributeOnlyInObjectDefinition constraint of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCollavizObjectInstance_AttributeOnlyInObjectDefinition(CollavizObjectInstance collavizObjectInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.COLLAVIZ_OBJECT_INSTANCE,
				 collavizObjectInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "AttributeOnlyInObjectDefinition",
				 COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTE_ONLY_IN_OBJECT_DEFINITION__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDependencyInstance(DependencyInstance dependencyInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(dependencyInstance, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateDependencyInstance_DependencyInstanceTargetNumber(dependencyInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateDependencyInstance_DependencyInstanceTargetGoodType(dependencyInstance, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the DependencyInstanceTargetNumber constraint of '<em>Dependency Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String DEPENDENCY_INSTANCE__DEPENDENCY_INSTANCE_TARGET_NUMBER__EEXPRESSION = "if self.instanceOf.upperBound=-1 then\r\n" +
		"\tself.target->size()>=self.instanceOf.lowerBound\r\n" +
		"else\r\n" +
		"\tself.target->size()>=self.instanceOf.lowerBound and self.target->size()<=self.instanceOf.upperBound\r\n" +
		"endif";

	/**
	 * Validates the DependencyInstanceTargetNumber constraint of '<em>Dependency Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDependencyInstance_DependencyInstanceTargetNumber(DependencyInstance dependencyInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.DEPENDENCY_INSTANCE,
				 dependencyInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "DependencyInstanceTargetNumber",
				 DEPENDENCY_INSTANCE__DEPENDENCY_INSTANCE_TARGET_NUMBER__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the DependencyInstanceTargetGoodType constraint of '<em>Dependency Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String DEPENDENCY_INSTANCE__DEPENDENCY_INSTANCE_TARGET_GOOD_TYPE__EEXPRESSION = "self.target->forAll(t : CollavizObjectInstance | \t\t\r\n" +
		"\tlet superTypes : Sequence(Collaviz::CollavizObject)=t.instanceOf.getAllSuperTypes()->union(Sequence{t.instanceOf})\r\n" +
		"\tin\r\n" +
		"\tsuperTypes->includes(self.instanceOf.type))";

	/**
	 * Validates the DependencyInstanceTargetGoodType constraint of '<em>Dependency Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDependencyInstance_DependencyInstanceTargetGoodType(DependencyInstance dependencyInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.DEPENDENCY_INSTANCE,
				 dependencyInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "DependencyInstanceTargetGoodType",
				 DEPENDENCY_INSTANCE__DEPENDENCY_INSTANCE_TARGET_GOOD_TYPE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAttributeInstance(AttributeInstance attributeInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(attributeInstance, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(attributeInstance, diagnostics, context);
		if (result || diagnostics != null) result &= validateAttributeInstance_AttributeInstanceTargetNumber(attributeInstance, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the AttributeInstanceTargetNumber constraint of '<em>Attribute Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ATTRIBUTE_INSTANCE__ATTRIBUTE_INSTANCE_TARGET_NUMBER__EEXPRESSION = "if self.instanceOf.upperBound=-1 then\r\n" +
		"\tself.value->size()>=self.instanceOf.lowerBound\r\n" +
		"else\r\n" +
		"\tself.value->size()>=self.instanceOf.lowerBound and self.value->size()<=self.instanceOf.upperBound\r\n" +
		"endif";

	/**
	 * Validates the AttributeInstanceTargetNumber constraint of '<em>Attribute Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAttributeInstance_AttributeInstanceTargetNumber(AttributeInstance attributeInstance, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(CollavizInstancePackage.Literals.ATTRIBUTE_INSTANCE,
				 attributeInstance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL",
				 "AttributeInstanceTargetNumber",
				 ATTRIBUTE_INSTANCE__ATTRIBUTE_INSTANCE_TARGET_NUMBER__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateString(String string, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //CollavizInstanceValidator
