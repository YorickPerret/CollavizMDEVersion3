/**
 */
package CollavizInstance.util;

import CollavizInstance.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstancePackage
 * @generated
 */
public class CollavizInstanceSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static CollavizInstancePackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceSwitch() {
		if (modelPackage == null) {
			modelPackage = CollavizInstancePackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE: {
				CollavizModelInstance collavizModelInstance = (CollavizModelInstance)theEObject;
				T result = caseCollavizModelInstance(collavizModelInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE: {
				CollavizObjectInstance collavizObjectInstance = (CollavizObjectInstance)theEObject;
				T result = caseCollavizObjectInstance(collavizObjectInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.DEPENDENCY_INSTANCE: {
				DependencyInstance dependencyInstance = (DependencyInstance)theEObject;
				T result = caseDependencyInstance(dependencyInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.ATTRIBUTE_INSTANCE: {
				AttributeInstance attributeInstance = (AttributeInstance)theEObject;
				T result = caseAttributeInstance(attributeInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.TRANSFORM: {
				Transform transform = (Transform)theEObject;
				T result = caseTransform(transform);
				if (result == null) result = caseValue(transform);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES: {
				TransformEulerAngles transformEulerAngles = (TransformEulerAngles)theEObject;
				T result = caseTransformEulerAngles(transformEulerAngles);
				if (result == null) result = caseTransform(transformEulerAngles);
				if (result == null) result = caseValue(transformEulerAngles);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE: {
				TransformEulerAnglesScale transformEulerAnglesScale = (TransformEulerAnglesScale)theEObject;
				T result = caseTransformEulerAnglesScale(transformEulerAnglesScale);
				if (result == null) result = caseTransform(transformEulerAnglesScale);
				if (result == null) result = caseValue(transformEulerAnglesScale);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE: {
				TransformQuaternionScale transformQuaternionScale = (TransformQuaternionScale)theEObject;
				T result = caseTransformQuaternionScale(transformQuaternionScale);
				if (result == null) result = caseTransform(transformQuaternionScale);
				if (result == null) result = caseValue(transformQuaternionScale);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.COLOR: {
				Color color = (Color)theEObject;
				T result = caseColor(color);
				if (result == null) result = caseValue(color);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.INTEGER_INSTANCE: {
				IntegerInstance integerInstance = (IntegerInstance)theEObject;
				T result = caseIntegerInstance(integerInstance);
				if (result == null) result = caseValue(integerInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.DOUBLE_INSTANCE: {
				DoubleInstance doubleInstance = (DoubleInstance)theEObject;
				T result = caseDoubleInstance(doubleInstance);
				if (result == null) result = caseValue(doubleInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.BOOLEAN_INSTANCE: {
				BooleanInstance booleanInstance = (BooleanInstance)theEObject;
				T result = caseBooleanInstance(booleanInstance);
				if (result == null) result = caseValue(booleanInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.SHORT_INSTANCE: {
				ShortInstance shortInstance = (ShortInstance)theEObject;
				T result = caseShortInstance(shortInstance);
				if (result == null) result = caseValue(shortInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.STRING_INSTANCE: {
				StringInstance stringInstance = (StringInstance)theEObject;
				T result = caseStringInstance(stringInstance);
				if (result == null) result = caseValue(stringInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.LONG_INSTANCE: {
				LongInstance longInstance = (LongInstance)theEObject;
				T result = caseLongInstance(longInstance);
				if (result == null) result = caseValue(longInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.FLOAT_INSTANCE: {
				FloatInstance floatInstance = (FloatInstance)theEObject;
				T result = caseFloatInstance(floatInstance);
				if (result == null) result = caseValue(floatInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.CHAR_INSTANCE: {
				CharInstance charInstance = (CharInstance)theEObject;
				T result = caseCharInstance(charInstance);
				if (result == null) result = caseValue(charInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.COLLECTION_INSTANCE: {
				CollectionInstance collectionInstance = (CollectionInstance)theEObject;
				T result = caseCollectionInstance(collectionInstance);
				if (result == null) result = caseValue(collectionInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.TREE_INSTANCE: {
				TreeInstance treeInstance = (TreeInstance)theEObject;
				T result = caseTreeInstance(treeInstance);
				if (result == null) result = caseValue(treeInstance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case CollavizInstancePackage.VALUE: {
				Value value = (Value)theEObject;
				T result = caseValue(value);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Collaviz Model Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Collaviz Model Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCollavizModelInstance(CollavizModelInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Collaviz Object Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCollavizObjectInstance(CollavizObjectInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dependency Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dependency Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDependencyInstance(DependencyInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attribute Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attribute Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttributeInstance(AttributeInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transform</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transform</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransform(Transform object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transform Euler Angles</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transform Euler Angles</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransformEulerAngles(TransformEulerAngles object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transform Euler Angles Scale</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transform Euler Angles Scale</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransformEulerAnglesScale(TransformEulerAnglesScale object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transform Quaternion Scale</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transform Quaternion Scale</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransformQuaternionScale(TransformQuaternionScale object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Color</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Color</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseColor(Color object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Integer Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Integer Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIntegerInstance(IntegerInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Double Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Double Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDoubleInstance(DoubleInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Boolean Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Boolean Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBooleanInstance(BooleanInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Short Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Short Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseShortInstance(ShortInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>String Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>String Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStringInstance(StringInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Long Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Long Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLongInstance(LongInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Float Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Float Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFloatInstance(FloatInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Char Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Char Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCharInstance(CharInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Collection Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Collection Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCollectionInstance(CollectionInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tree Instance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tree Instance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTreeInstance(TreeInstance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Value</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Value</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseValue(Value object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //CollavizInstanceSwitch
