/**
 */
package CollavizInstance;

import Collaviz.Attribute;


import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.AttributeInstance#getValue <em>Value</em>}</li>
 *   <li>{@link CollavizInstance.AttributeInstance#getInstanceOf <em>Instance Of</em>}</li>
 *   <li>{@link CollavizInstance.AttributeInstance#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getAttributeInstance()
 * @model
 * @generated
 */
public interface AttributeInstance extends EObject {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' containment reference.
	 * @see #setValue(Value)
	 * @see CollavizInstance.CollavizInstancePackage#getAttributeInstance_Value()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Value getValue();

	/**
	 * Sets the value of the '{@link CollavizInstance.AttributeInstance#getValue <em>Value</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' containment reference.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(Value value);

	/**
	 * Returns the value of the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instance Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance Of</em>' reference.
	 * @see #setInstanceOf(Attribute)
	 * @see CollavizInstance.CollavizInstancePackage#getAttributeInstance_InstanceOf()
	 * @model required="true"
	 * @generated
	 */
	Attribute getInstanceOf();

	/**
	 * Sets the value of the '{@link CollavizInstance.AttributeInstance#getInstanceOf <em>Instance Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instance Of</em>' reference.
	 * @see #getInstanceOf()
	 * @generated
	 */
	void setInstanceOf(Attribute value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see CollavizInstance.CollavizInstancePackage#getAttributeInstance_Name()
	 * @model default="" dataType="Collaviz.String" changeable="false" derived="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL derivation='if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif'"
	 * @generated
	 */
	String getName();

} // AttributeInstance
