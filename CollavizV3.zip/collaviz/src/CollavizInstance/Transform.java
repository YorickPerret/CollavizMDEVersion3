/**
 */
package CollavizInstance;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transform</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.Transform#getIsRelative <em>Is Relative</em>}</li>
 *   <li>{@link CollavizInstance.Transform#getX <em>X</em>}</li>
 *   <li>{@link CollavizInstance.Transform#getY <em>Y</em>}</li>
 *   <li>{@link CollavizInstance.Transform#getZ <em>Z</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getTransform()
 * @model abstract="true"
 * @generated
 */
public interface Transform extends Value {
	/**
	 * Returns the value of the '<em><b>Is Relative</b></em>' attribute.
	 * The default value is <code>"position"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Relative</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Relative</em>' attribute.
	 * @see CollavizInstance.CollavizInstancePackage#getTransform_IsRelative()
	 * @model default="position" id="true" dataType="Collaviz.boolean" changeable="false"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL derivation='if self.getParent().support.oclIsUndefined() then\r\n\tfalse\r\nelse\r\n\ttrue\r\nendif'"
	 * @generated
	 */
	Boolean getIsRelative();

	/**
	 * Returns the value of the '<em><b>X</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>X</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>X</em>' attribute.
	 * @see #setX(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransform_X()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getX();

	/**
	 * Sets the value of the '{@link CollavizInstance.Transform#getX <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>X</em>' attribute.
	 * @see #getX()
	 * @generated
	 */
	void setX(Double value);

	/**
	 * Returns the value of the '<em><b>Y</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Y</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Y</em>' attribute.
	 * @see #setY(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransform_Y()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getY();

	/**
	 * Sets the value of the '{@link CollavizInstance.Transform#getY <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Y</em>' attribute.
	 * @see #getY()
	 * @generated
	 */
	void setY(Double value);

	/**
	 * Returns the value of the '<em><b>Z</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Z</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Z</em>' attribute.
	 * @see #setZ(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransform_Z()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getZ();

	/**
	 * Sets the value of the '{@link CollavizInstance.Transform#getZ <em>Z</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Z</em>' attribute.
	 * @see #getZ()
	 * @generated
	 */
	void setZ(Double value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation" required="true"
	 * @generated
	 */
	CollavizObjectInstance getParent();

} // Transform
