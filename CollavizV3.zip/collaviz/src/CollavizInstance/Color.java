/**
 */
package CollavizInstance;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Color</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.Color#getR <em>R</em>}</li>
 *   <li>{@link CollavizInstance.Color#getG <em>G</em>}</li>
 *   <li>{@link CollavizInstance.Color#getB <em>B</em>}</li>
 *   <li>{@link CollavizInstance.Color#getA <em>A</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getColor()
 * @model
 * @generated
 */
public interface Color extends Value {
	/**
	 * Returns the value of the '<em><b>R</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>R</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>R</em>' attribute.
	 * @see #setR(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getColor_R()
	 * @model dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getR();

	/**
	 * Sets the value of the '{@link CollavizInstance.Color#getR <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>R</em>' attribute.
	 * @see #getR()
	 * @generated
	 */
	void setR(Double value);

	/**
	 * Returns the value of the '<em><b>G</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>G</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>G</em>' attribute.
	 * @see #setG(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getColor_G()
	 * @model dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getG();

	/**
	 * Sets the value of the '{@link CollavizInstance.Color#getG <em>G</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>G</em>' attribute.
	 * @see #getG()
	 * @generated
	 */
	void setG(Double value);

	/**
	 * Returns the value of the '<em><b>B</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>B</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>B</em>' attribute.
	 * @see #setB(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getColor_B()
	 * @model dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getB();

	/**
	 * Sets the value of the '{@link CollavizInstance.Color#getB <em>B</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>B</em>' attribute.
	 * @see #getB()
	 * @generated
	 */
	void setB(Double value);

	/**
	 * Returns the value of the '<em><b>A</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>A</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>A</em>' attribute.
	 * @see #setA(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getColor_A()
	 * @model dataType="Collaviz.double"
	 * @generated
	 */
	Double getA();

	/**
	 * Sets the value of the '{@link CollavizInstance.Color#getA <em>A</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>A</em>' attribute.
	 * @see #getA()
	 * @generated
	 */
	void setA(Double value);

} // Color
