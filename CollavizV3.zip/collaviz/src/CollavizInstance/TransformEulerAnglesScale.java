/**
 */
package CollavizInstance;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transform Euler Angles Scale</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.TransformEulerAnglesScale#getH <em>H</em>}</li>
 *   <li>{@link CollavizInstance.TransformEulerAnglesScale#getP <em>P</em>}</li>
 *   <li>{@link CollavizInstance.TransformEulerAnglesScale#getR <em>R</em>}</li>
 *   <li>{@link CollavizInstance.TransformEulerAnglesScale#getSx <em>Sx</em>}</li>
 *   <li>{@link CollavizInstance.TransformEulerAnglesScale#getSy <em>Sy</em>}</li>
 *   <li>{@link CollavizInstance.TransformEulerAnglesScale#getSz <em>Sz</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAnglesScale()
 * @model
 * @generated
 */
public interface TransformEulerAnglesScale extends Transform {
	/**
	 * Returns the value of the '<em><b>H</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>H</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>H</em>' attribute.
	 * @see #setH(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAnglesScale_H()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getH();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAnglesScale#getH <em>H</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>H</em>' attribute.
	 * @see #getH()
	 * @generated
	 */
	void setH(Double value);

	/**
	 * Returns the value of the '<em><b>P</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>P</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>P</em>' attribute.
	 * @see #setP(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAnglesScale_P()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getP();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAnglesScale#getP <em>P</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>P</em>' attribute.
	 * @see #getP()
	 * @generated
	 */
	void setP(Double value);

	/**
	 * Returns the value of the '<em><b>R</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>R</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>R</em>' attribute.
	 * @see #setR(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAnglesScale_R()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getR();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAnglesScale#getR <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>R</em>' attribute.
	 * @see #getR()
	 * @generated
	 */
	void setR(Double value);

	/**
	 * Returns the value of the '<em><b>Sx</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sx</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sx</em>' attribute.
	 * @see #setSx(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAnglesScale_Sx()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getSx();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAnglesScale#getSx <em>Sx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sx</em>' attribute.
	 * @see #getSx()
	 * @generated
	 */
	void setSx(Double value);

	/**
	 * Returns the value of the '<em><b>Sy</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sy</em>' attribute.
	 * @see #setSy(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAnglesScale_Sy()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getSy();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAnglesScale#getSy <em>Sy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sy</em>' attribute.
	 * @see #getSy()
	 * @generated
	 */
	void setSy(Double value);

	/**
	 * Returns the value of the '<em><b>Sz</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sz</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sz</em>' attribute.
	 * @see #setSz(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformEulerAnglesScale_Sz()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getSz();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformEulerAnglesScale#getSz <em>Sz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sz</em>' attribute.
	 * @see #getSz()
	 * @generated
	 */
	void setSz(Double value);

} // TransformEulerAnglesScale
