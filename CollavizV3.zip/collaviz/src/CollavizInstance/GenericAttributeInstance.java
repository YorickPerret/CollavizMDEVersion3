/**
 */
package CollavizInstance;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generic Attribute Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see CollavizInstance.CollavizInstancePackage#getGenericAttributeInstance()
 * @model abstract="true"
 * @generated
 */
public interface GenericAttributeInstance extends EObject {
} // GenericAttributeInstance
