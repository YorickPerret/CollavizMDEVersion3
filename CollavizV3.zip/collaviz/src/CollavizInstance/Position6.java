/**
 */
package CollavizInstance;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Position6</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see CollavizInstance.CollavizInstancePackage#getPosition6()
 * @model
 * @generated
 */
public interface Position6 extends Position {

} // Position6
