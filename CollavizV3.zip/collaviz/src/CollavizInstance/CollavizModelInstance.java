/**
 */
package CollavizInstance;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collaviz Model Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.CollavizModelInstance#getObjectInstances <em>Object Instances</em>}</li>
 *   <li>{@link CollavizInstance.CollavizModelInstance#getName <em>Name</em>}</li>
 *   <li>{@link CollavizInstance.CollavizModelInstance#getFileType <em>File Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getCollavizModelInstance()
 * @model
 * @generated
 */
public interface CollavizModelInstance extends EObject {
	/**
	 * Returns the value of the '<em><b>Object Instances</b></em>' containment reference list.
	 * The list contents are of type {@link CollavizInstance.CollavizObjectInstance}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Instances</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Instances</em>' containment reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizModelInstance_ObjectInstances()
	 * @model containment="true"
	 * @generated
	 */
	EList<CollavizObjectInstance> getObjectInstances();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizModelInstance_Name()
	 * @model dataType="Collaviz.String" required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizModelInstance#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>File Type</b></em>' attribute.
	 * The default value is <code>"1"</code>.
	 * The literals are from the enumeration {@link CollavizInstance.FileType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>File Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>File Type</em>' attribute.
	 * @see CollavizInstance.FileType
	 * @see #setFileType(FileType)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizModelInstance_FileType()
	 * @model default="1" required="true"
	 * @generated
	 */
	FileType getFileType();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizModelInstance#getFileType <em>File Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Type</em>' attribute.
	 * @see CollavizInstance.FileType
	 * @see #getFileType()
	 * @generated
	 */
	void setFileType(FileType value);

} // CollavizModelInstance
