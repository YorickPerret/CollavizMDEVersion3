/**
 */
package CollavizInstance;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collaviz Model Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.CollavizModelInstance#getObjectInstances <em>Object Instances</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getCollavizModelInstance()
 * @model
 * @generated
 */
public interface CollavizModelInstance extends EObject {
	/**
	 * Returns the value of the '<em><b>Object Instances</b></em>' containment reference list.
	 * The list contents are of type {@link CollavizInstance.CollavizObjectInstance}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Object Instances</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Instances</em>' containment reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizModelInstance_ObjectInstances()
	 * @model containment="true"
	 * @generated
	 */
	EList<CollavizObjectInstance> getObjectInstances();

} // CollavizModelInstance
