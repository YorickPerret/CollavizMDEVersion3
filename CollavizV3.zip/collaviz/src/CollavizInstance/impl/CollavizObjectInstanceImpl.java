/**
 */
package CollavizInstance.impl;

import Collaviz.CollavizObject;

import CollavizInstance.AttributeInstance;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.DependencyInstance;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Collaviz Object Instance</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CollavizInstance.impl.CollavizObjectInstanceImpl#getInstanceOf <em>Instance Of</em>}</li>
 *   <li>{@link CollavizInstance.impl.CollavizObjectInstanceImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link CollavizInstance.impl.CollavizObjectInstanceImpl#getDependencies <em>Dependencies</em>}</li>
 *   <li>{@link CollavizInstance.impl.CollavizObjectInstanceImpl#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CollavizObjectInstanceImpl extends EObjectImpl implements CollavizObjectInstance {
	/**
	 * The cached value of the '{@link #getInstanceOf() <em>Instance Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstanceOf()
	 * @generated
	 * @ordered
	 */
	protected CollavizObject instanceOf;

	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList<AttributeInstance> attributes;

	/**
	 * The cached value of the '{@link #getDependencies() <em>Dependencies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDependencies()
	 * @generated
	 * @ordered
	 */
	protected EList<DependencyInstance> dependencies;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizObjectInstanceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizInstancePackage.Literals.COLLAVIZ_OBJECT_INSTANCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObject getInstanceOf() {
		if (instanceOf != null && instanceOf.eIsProxy()) {
			InternalEObject oldInstanceOf = (InternalEObject)instanceOf;
			instanceOf = (CollavizObject)eResolveProxy(oldInstanceOf);
			if (instanceOf != oldInstanceOf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF, oldInstanceOf, instanceOf));
			}
		}
		return instanceOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObject basicGetInstanceOf() {
		return instanceOf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInstanceOf(CollavizObject newInstanceOf) {
		CollavizObject oldInstanceOf = instanceOf;
		instanceOf = newInstanceOf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF, oldInstanceOf, instanceOf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AttributeInstance> getAttributes() {
		if (attributes == null) {
			attributes = new EObjectContainmentEList<AttributeInstance>(AttributeInstance.class, this, CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DependencyInstance> getDependencies() {
		if (dependencies == null) {
			dependencies = new EObjectContainmentEList<DependencyInstance>(DependencyInstance.class, this, CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES);
		}
		return dependencies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES:
				return ((InternalEList<?>)getAttributes()).basicRemove(otherEnd, msgs);
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES:
				return ((InternalEList<?>)getDependencies()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF:
				if (resolve) return getInstanceOf();
				return basicGetInstanceOf();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES:
				return getAttributes();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES:
				return getDependencies();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF:
				setInstanceOf((CollavizObject)newValue);
				return;
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES:
				getAttributes().clear();
				getAttributes().addAll((Collection<? extends AttributeInstance>)newValue);
				return;
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES:
				getDependencies().clear();
				getDependencies().addAll((Collection<? extends DependencyInstance>)newValue);
				return;
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF:
				setInstanceOf((CollavizObject)null);
				return;
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES:
				getAttributes().clear();
				return;
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES:
				getDependencies().clear();
				return;
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF:
				return instanceOf != null;
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES:
				return attributes != null && !attributes.isEmpty();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES:
				return dependencies != null && !dependencies.isEmpty();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //CollavizObjectInstanceImpl
