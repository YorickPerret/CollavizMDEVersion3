/**
 */
package CollavizInstance.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;
import org.eclipse.emf.ecore.impl.EPackageImpl;

import Collaviz.CollavizPackage;
import Collaviz.impl.CollavizPackageImpl;
import CollavizInstance.AttributeInstance;
import CollavizInstance.CollavizInstanceFactory;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizModelInstance;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.DependencyInstance;
import CollavizInstance.FileType;
import CollavizInstance.OwnersValue;
import CollavizInstance.Position;
import CollavizInstance.Position10;
import CollavizInstance.Position6;
import CollavizInstance.Position9;
import CollavizInstance.util.CollavizInstanceValidator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizInstancePackageImpl extends EPackageImpl implements CollavizInstancePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizModelInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizObjectInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dependencyInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass positionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass position6EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass position9EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass position10EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum ownersValueEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum fileTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see CollavizInstance.CollavizInstancePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CollavizInstancePackageImpl() {
		super(eNS_URI, CollavizInstanceFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link CollavizInstancePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CollavizInstancePackage init() {
		if (isInited) return (CollavizInstancePackage)EPackage.Registry.INSTANCE.getEPackage(CollavizInstancePackage.eNS_URI);

		// Obtain or create and register package
		CollavizInstancePackageImpl theCollavizInstancePackage = (CollavizInstancePackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof CollavizInstancePackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new CollavizInstancePackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		CollavizPackageImpl theCollavizPackage = (CollavizPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI) instanceof CollavizPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI) : CollavizPackage.eINSTANCE);

		// Create package meta-data objects
		theCollavizInstancePackage.createPackageContents();
		theCollavizPackage.createPackageContents();

		// Initialize created meta-data
		theCollavizInstancePackage.initializePackageContents();
		theCollavizPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theCollavizInstancePackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return CollavizInstanceValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theCollavizInstancePackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(CollavizInstancePackage.eNS_URI, theCollavizInstancePackage);
		return theCollavizInstancePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizModelInstance() {
		return collavizModelInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizModelInstance_ObjectInstances() {
		return (EReference)collavizModelInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizModelInstance_Name() {
		return (EAttribute)collavizModelInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizModelInstance_FileType() {
		return (EAttribute)collavizModelInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizObjectInstance() {
		return collavizObjectInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_InstanceOf() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Attributes() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Dependencies() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_Name() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Support() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Supported() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Position() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_Owners() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_AccessLevel() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_RefProxy() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_BecomeReferent() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_BecomeOwner() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDependencyInstance() {
		return dependencyInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependencyInstance_InstanceOf() {
		return (EReference)dependencyInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependencyInstance_Target() {
		return (EReference)dependencyInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDependencyInstance_Name() {
		return (EAttribute)dependencyInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttributeInstance() {
		return attributeInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttributeInstance_InstanceOf() {
		return (EReference)attributeInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttributeInstance_Value() {
		return (EAttribute)attributeInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttributeInstance_Name() {
		return (EAttribute)attributeInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPosition() {
		return positionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPosition_Name() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPosition_Value() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPosition6() {
		return position6EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPosition9() {
		return position9EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPosition10() {
		return position10EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOwnersValue() {
		return ownersValueEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getFileType() {
		return fileTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceFactory getCollavizInstanceFactory() {
		return (CollavizInstanceFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		collavizModelInstanceEClass = createEClass(COLLAVIZ_MODEL_INSTANCE);
		createEReference(collavizModelInstanceEClass, COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES);
		createEAttribute(collavizModelInstanceEClass, COLLAVIZ_MODEL_INSTANCE__NAME);
		createEAttribute(collavizModelInstanceEClass, COLLAVIZ_MODEL_INSTANCE__FILE_TYPE);

		collavizObjectInstanceEClass = createEClass(COLLAVIZ_OBJECT_INSTANCE);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__NAME);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__SUPPORT);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__SUPPORTED);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__POSITION);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__OWNERS);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__ACCESS_LEVEL);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__REF_PROXY);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__BECOME_REFERENT);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__BECOME_OWNER);

		dependencyInstanceEClass = createEClass(DEPENDENCY_INSTANCE);
		createEReference(dependencyInstanceEClass, DEPENDENCY_INSTANCE__INSTANCE_OF);
		createEReference(dependencyInstanceEClass, DEPENDENCY_INSTANCE__TARGET);
		createEAttribute(dependencyInstanceEClass, DEPENDENCY_INSTANCE__NAME);

		attributeInstanceEClass = createEClass(ATTRIBUTE_INSTANCE);
		createEReference(attributeInstanceEClass, ATTRIBUTE_INSTANCE__INSTANCE_OF);
		createEAttribute(attributeInstanceEClass, ATTRIBUTE_INSTANCE__VALUE);
		createEAttribute(attributeInstanceEClass, ATTRIBUTE_INSTANCE__NAME);

		positionEClass = createEClass(POSITION);
		createEAttribute(positionEClass, POSITION__NAME);
		createEAttribute(positionEClass, POSITION__VALUE);

		position6EClass = createEClass(POSITION6);

		position9EClass = createEClass(POSITION9);

		position10EClass = createEClass(POSITION10);

		// Create enums
		ownersValueEEnum = createEEnum(OWNERS_VALUE);
		fileTypeEEnum = createEEnum(FILE_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CollavizPackage theCollavizPackage = (CollavizPackage)EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		position6EClass.getESuperTypes().add(this.getPosition());
		position9EClass.getESuperTypes().add(this.getPosition());
		position10EClass.getESuperTypes().add(this.getPosition());

		// Initialize classes and features; add operations and parameters
		initEClass(collavizModelInstanceEClass, CollavizModelInstance.class, "CollavizModelInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizModelInstance_ObjectInstances(), this.getCollavizObjectInstance(), null, "objectInstances", null, 0, -1, CollavizModelInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizModelInstance_Name(), theCollavizPackage.getString(), "name", null, 1, 1, CollavizModelInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizModelInstance_FileType(), this.getFileType(), "fileType", "1", 1, 1, CollavizModelInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(collavizObjectInstanceEClass, CollavizObjectInstance.class, "CollavizObjectInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizObjectInstance_InstanceOf(), theCollavizPackage.getCollavizObject(), null, "instanceOf", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Attributes(), this.getAttributeInstance(), null, "attributes", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Dependencies(), this.getDependencyInstance(), null, "dependencies", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_Name(), theCollavizPackage.getString(), "name", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Support(), this.getCollavizObjectInstance(), this.getCollavizObjectInstance_Supported(), "support", null, 0, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Supported(), this.getCollavizObjectInstance(), this.getCollavizObjectInstance_Support(), "supported", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Position(), this.getPosition(), null, "position", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_Owners(), this.getOwnersValue(), "owners", "0", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_AccessLevel(), theCollavizPackage.getInteger(), "accessLevel", "3", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_RefProxy(), theCollavizPackage.getboolean(), "refProxy", "true", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_BecomeReferent(), theCollavizPackage.getboolean(), "becomeReferent", "true", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_BecomeOwner(), theCollavizPackage.getboolean(), "becomeOwner", "true", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dependencyInstanceEClass, DependencyInstance.class, "DependencyInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDependencyInstance_InstanceOf(), theCollavizPackage.getDependency(), null, "instanceOf", null, 1, 1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDependencyInstance_Target(), this.getCollavizObjectInstance(), null, "target", null, 1, -1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDependencyInstance_Name(), theCollavizPackage.getString(), "name", "", 0, 1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(attributeInstanceEClass, AttributeInstance.class, "AttributeInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttributeInstance_InstanceOf(), theCollavizPackage.getAttribute(), null, "instanceOf", null, 1, 1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttributeInstance_Value(), theCollavizPackage.getString(), "value", null, 1, -1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttributeInstance_Name(), theCollavizPackage.getString(), "name", "", 0, 1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(positionEClass, Position.class, "Position", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPosition_Name(), theCollavizPackage.getString(), "name", "position", 0, 1, Position.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPosition_Value(), theCollavizPackage.getString(), "value", "0 0 0 0 0 0", 1, 1, Position.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(positionEClass, this.getCollavizObjectInstance(), "getParent", 1, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(position6EClass, Position6.class, "Position6", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(position9EClass, Position9.class, "Position9", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(position10EClass, Position10.class, "Position10", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(ownersValueEEnum, OwnersValue.class, "OwnersValue");
		addEEnumLiteral(ownersValueEEnum, OwnersValue.ALL);
		addEEnumLiteral(ownersValueEEnum, OwnersValue.ME);

		initEEnum(fileTypeEEnum, FileType.class, "FileType");
		addEEnumLiteral(fileTypeEEnum, FileType.IVC_DESCRIPTION);
		addEEnumLiteral(fileTypeEEnum, FileType.WORLD_DESCRIPTION);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL
		createOCLAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";		
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL"
		   });		
		addAnnotation
		  (collavizObjectInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "DependencyMustBeSet DependencyInstanceIsUnique DependencyOnlyInObjectDefinition AttributeMustBeSet AttributeInstanceIsUnique AttributeOnlyInObjectDefinition"
		   });			
		addAnnotation
		  (dependencyInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "DependencyInstanceTargetNumber DependencyInstanceTargetGoodType"
		   });				
		addAnnotation
		  (attributeInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "AttributeInstanceTargetNumber"
		   });			
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createOCLAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL";				
		addAnnotation
		  (collavizObjectInstanceEClass, 
		   source, 
		   new String[] {
			 "DependencyMustBeSet", "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependencies->forAll(d : Collaviz::GenericAttribute | dependenciesInstance->includes(d)) and dependencies->size() <= dependenciesInstance->size()",
			 "DependencyInstanceIsUnique", "let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(d1 : Collaviz::Dependency |  dependenciesInstance->count(d1)=1)",
			 "DependencyOnlyInObjectDefinition", "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(di : Collaviz::Dependency | dependencies->includes(di))",
			 "AttributeMustBeSet", "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributes->forAll(a : Collaviz::GenericAttribute | attributesInstance->includes(a)) and attributes->size() <= attributesInstance->size()",
			 "AttributeInstanceIsUnique", "let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(a : Collaviz::Attribute |  attributesInstance->count(a)=1)",
			 "AttributeOnlyInObjectDefinition", "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(ai : Collaviz::Attribute | attributes->includes(ai))"
		   });			
		addAnnotation
		  (dependencyInstanceEClass, 
		   source, 
		   new String[] {
			 "DependencyInstanceTargetNumber", "if self.instanceOf.upperBound=-1 then\r\n\tself.target->size()>=self.instanceOf.lowerBound\r\nelse\r\n\tself.target->size()>=self.instanceOf.lowerBound and self.target->size()<=self.instanceOf.upperBound\r\nendif",
			 "DependencyInstanceTargetGoodType", "self.target->forAll(t : CollavizObjectInstance | \t\t\r\n\tlet superTypes : Sequence(Collaviz::CollavizObject)=t.instanceOf.getAllSuperTypes()->union(Sequence{t.instanceOf})\r\n\tin\r\n\tsuperTypes->includes(self.instanceOf.type))"
		   });		
		addAnnotation
		  (getDependencyInstance_Name(), 
		   source, 
		   new String[] {
			 "derivation", "if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif"
		   });			
		addAnnotation
		  (attributeInstanceEClass, 
		   source, 
		   new String[] {
			 "AttributeInstanceTargetNumber", "if self.instanceOf.upperBound=-1 then\r\n\tself.value->size()>=self.instanceOf.lowerBound\r\nelse\r\n\tself.value->size()>=self.instanceOf.lowerBound and self.value->size()<=self.instanceOf.upperBound\r\nendif"
		   });		
		addAnnotation
		  (getAttributeInstance_Name(), 
		   source, 
		   new String[] {
			 "derivation", "if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif"
		   });		
		addAnnotation
		  (getPosition_Name(), 
		   source, 
		   new String[] {
			 "derivation", "if self.getParent().support.oclIsUndefined() then\r\n\t\'position\'\r\nelse\r\n\t\'offset\'\r\nendif"
		   });
	}

} //CollavizInstancePackageImpl
