/**
 */
package CollavizInstance.impl;

import Collaviz.CollavizPackage;

import Collaviz.impl.CollavizPackageImpl;

import CollavizInstance.AttributeInstance;
import CollavizInstance.CollavizInstanceFactory;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizModelInstance;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.DependencyInstance;

import CollavizInstance.util.CollavizInstanceValidator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizInstancePackageImpl extends EPackageImpl implements CollavizInstancePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizModelInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizObjectInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dependencyInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType stringEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see CollavizInstance.CollavizInstancePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CollavizInstancePackageImpl() {
		super(eNS_URI, CollavizInstanceFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link CollavizInstancePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CollavizInstancePackage init() {
		if (isInited) return (CollavizInstancePackage)EPackage.Registry.INSTANCE.getEPackage(CollavizInstancePackage.eNS_URI);

		// Obtain or create and register package
		CollavizInstancePackageImpl theCollavizInstancePackage = (CollavizInstancePackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof CollavizInstancePackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new CollavizInstancePackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		CollavizPackageImpl theCollavizPackage = (CollavizPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI) instanceof CollavizPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI) : CollavizPackage.eINSTANCE);

		// Create package meta-data objects
		theCollavizInstancePackage.createPackageContents();
		theCollavizPackage.createPackageContents();

		// Initialize created meta-data
		theCollavizInstancePackage.initializePackageContents();
		theCollavizPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theCollavizInstancePackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return CollavizInstanceValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theCollavizInstancePackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(CollavizInstancePackage.eNS_URI, theCollavizInstancePackage);
		return theCollavizInstancePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizModelInstance() {
		return collavizModelInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizModelInstance_ObjectInstances() {
		return (EReference)collavizModelInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizObjectInstance() {
		return collavizObjectInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_InstanceOf() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Attributes() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Dependencies() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_Name() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDependencyInstance() {
		return dependencyInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependencyInstance_InstanceOf() {
		return (EReference)dependencyInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependencyInstance_Target() {
		return (EReference)dependencyInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDependencyInstance_Name() {
		return (EAttribute)dependencyInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttributeInstance() {
		return attributeInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttributeInstance_InstanceOf() {
		return (EReference)attributeInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttributeInstance_Value() {
		return (EAttribute)attributeInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttributeInstance_Name() {
		return (EAttribute)attributeInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getString() {
		return stringEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceFactory getCollavizInstanceFactory() {
		return (CollavizInstanceFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		collavizModelInstanceEClass = createEClass(COLLAVIZ_MODEL_INSTANCE);
		createEReference(collavizModelInstanceEClass, COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES);

		collavizObjectInstanceEClass = createEClass(COLLAVIZ_OBJECT_INSTANCE);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__NAME);

		dependencyInstanceEClass = createEClass(DEPENDENCY_INSTANCE);
		createEReference(dependencyInstanceEClass, DEPENDENCY_INSTANCE__INSTANCE_OF);
		createEReference(dependencyInstanceEClass, DEPENDENCY_INSTANCE__TARGET);
		createEAttribute(dependencyInstanceEClass, DEPENDENCY_INSTANCE__NAME);

		attributeInstanceEClass = createEClass(ATTRIBUTE_INSTANCE);
		createEReference(attributeInstanceEClass, ATTRIBUTE_INSTANCE__INSTANCE_OF);
		createEAttribute(attributeInstanceEClass, ATTRIBUTE_INSTANCE__VALUE);
		createEAttribute(attributeInstanceEClass, ATTRIBUTE_INSTANCE__NAME);

		// Create data types
		stringEDataType = createEDataType(STRING);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CollavizPackage theCollavizPackage = (CollavizPackage)EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(collavizModelInstanceEClass, CollavizModelInstance.class, "CollavizModelInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizModelInstance_ObjectInstances(), this.getCollavizObjectInstance(), null, "objectInstances", null, 0, -1, CollavizModelInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(collavizObjectInstanceEClass, CollavizObjectInstance.class, "CollavizObjectInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizObjectInstance_InstanceOf(), theCollavizPackage.getCollavizObject(), null, "instanceOf", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Attributes(), this.getAttributeInstance(), null, "attributes", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Dependencies(), this.getDependencyInstance(), null, "dependencies", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_Name(), this.getString(), "name", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dependencyInstanceEClass, DependencyInstance.class, "DependencyInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDependencyInstance_InstanceOf(), theCollavizPackage.getDependency(), null, "instanceOf", null, 1, 1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDependencyInstance_Target(), this.getCollavizObjectInstance(), null, "target", null, 1, -1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDependencyInstance_Name(), this.getString(), "name", "", 0, 1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(attributeInstanceEClass, AttributeInstance.class, "AttributeInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttributeInstance_InstanceOf(), theCollavizPackage.getAttribute(), null, "instanceOf", null, 1, 1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttributeInstance_Value(), this.getString(), "value", null, 1, -1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttributeInstance_Name(), this.getString(), "name", "", 0, 1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		// Initialize data types
		initEDataType(stringEDataType, String.class, "String", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL
		createOCLAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";		
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL"
		   });		
		addAnnotation
		  (collavizObjectInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "DependencyMustBeSet DependencyInstanceIsUnique DependencyOnlyInObjectDefinition AttributeMustBeSet AttributeInstanceIsUnique AttributeOnlyInObjectDefinition"
		   });			
		addAnnotation
		  (dependencyInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "DependencyInstanceTargetNumber DependencyInstanceTargetGoodType"
		   });				
		addAnnotation
		  (attributeInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "AttributeInstanceTargetNumber"
		   });		
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createOCLAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL";				
		addAnnotation
		  (collavizObjectInstanceEClass, 
		   source, 
		   new String[] {
			 "DependencyMustBeSet", "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependencies->forAll(d : Collaviz::GenericAttribute | dependenciesInstance->includes(d)) and dependencies->size() <= dependenciesInstance->size()",
			 "DependencyInstanceIsUnique", "let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(d1 : Collaviz::Dependency |  dependenciesInstance->count(d1)=1)",
			 "DependencyOnlyInObjectDefinition", "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(di : Collaviz::Dependency | dependencies->includes(di))",
			 "AttributeMustBeSet", "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributes->forAll(a : Collaviz::GenericAttribute | attributesInstance->includes(a)) and attributes->size() <= attributesInstance->size()",
			 "AttributeInstanceIsUnique", "let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(a : Collaviz::Attribute |  attributesInstance->count(a)=1)",
			 "AttributeOnlyInObjectDefinition", "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(ai : Collaviz::Attribute | attributes->includes(ai))"
		   });			
		addAnnotation
		  (dependencyInstanceEClass, 
		   source, 
		   new String[] {
			 "DependencyInstanceTargetNumber", "if self.instanceOf.upperBound=-1 then\r\n\tself.target->size()>=self.instanceOf.lowerBound\r\nelse\r\n\tself.target->size()>=self.instanceOf.lowerBound and self.target->size()<=self.instanceOf.upperBound\r\nendif",
			 "DependencyInstanceTargetGoodType", "self.target->forAll(t : CollavizObjectInstance | \t\t\r\n\tlet superTypes : Sequence(Collaviz::CollavizObject)=t.instanceOf.getAllSuperTypes()->union(Sequence{t.instanceOf})\r\n\tin\r\n\tsuperTypes->includes(self.instanceOf.type))"
		   });		
		addAnnotation
		  (getDependencyInstance_Name(), 
		   source, 
		   new String[] {
			 "derivation", "if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif"
		   });			
		addAnnotation
		  (attributeInstanceEClass, 
		   source, 
		   new String[] {
			 "AttributeInstanceTargetNumber", "if self.instanceOf.upperBound=-1 then\r\n\tself.value->size()>=self.instanceOf.lowerBound\r\nelse\r\n\tself.value->size()>=self.instanceOf.lowerBound and self.value->size()<=self.instanceOf.upperBound\r\nendif"
		   });		
		addAnnotation
		  (getAttributeInstance_Name(), 
		   source, 
		   new String[] {
			 "derivation", "if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif"
		   });
	}

} //CollavizInstancePackageImpl
