/**
 */
package CollavizInstance.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;
import org.eclipse.emf.ecore.impl.EPackageImpl;

import Collaviz.CollavizPackage;
import Collaviz.impl.CollavizPackageImpl;
import CollavizInstance.AttributeInstance;
import CollavizInstance.BooleanInstance;
import CollavizInstance.CharInstance;
import CollavizInstance.CollavizInstanceFactory;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizModelInstance;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.CollectionInstance;
import CollavizInstance.Color;
import CollavizInstance.DependencyInstance;
import CollavizInstance.DoubleInstance;
import CollavizInstance.FileType;
import CollavizInstance.FloatInstance;
import CollavizInstance.IntegerInstance;
import CollavizInstance.LongInstance;
import CollavizInstance.OwnersValue;
import CollavizInstance.ShortInstance;
import CollavizInstance.StringInstance;
import CollavizInstance.Transform;
import CollavizInstance.TransformEulerAngles;
import CollavizInstance.TransformEulerAnglesScale;
import CollavizInstance.TransformQuaternionScale;
import CollavizInstance.TreeInstance;
import CollavizInstance.Value;
import CollavizInstance.util.CollavizInstanceValidator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizInstancePackageImpl extends EPackageImpl implements CollavizInstancePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizModelInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collavizObjectInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dependencyInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transformEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transformEulerAnglesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transformEulerAnglesScaleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transformQuaternionScaleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass colorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass integerInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass doubleInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass booleanInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass shortInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stringInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass longInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass floatInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass charInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass collectionInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass treeInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum ownersValueEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum fileTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see CollavizInstance.CollavizInstancePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CollavizInstancePackageImpl() {
		super(eNS_URI, CollavizInstanceFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link CollavizInstancePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CollavizInstancePackage init() {
		if (isInited) return (CollavizInstancePackage)EPackage.Registry.INSTANCE.getEPackage(CollavizInstancePackage.eNS_URI);

		// Obtain or create and register package
		CollavizInstancePackageImpl theCollavizInstancePackage = (CollavizInstancePackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof CollavizInstancePackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new CollavizInstancePackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		CollavizPackageImpl theCollavizPackage = (CollavizPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI) instanceof CollavizPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI) : CollavizPackage.eINSTANCE);

		// Create package meta-data objects
		theCollavizInstancePackage.createPackageContents();
		theCollavizPackage.createPackageContents();

		// Initialize created meta-data
		theCollavizInstancePackage.initializePackageContents();
		theCollavizPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theCollavizInstancePackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return CollavizInstanceValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theCollavizInstancePackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(CollavizInstancePackage.eNS_URI, theCollavizInstancePackage);
		return theCollavizInstancePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizModelInstance() {
		return collavizModelInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizModelInstance_ObjectInstances() {
		return (EReference)collavizModelInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizModelInstance_Name() {
		return (EAttribute)collavizModelInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizModelInstance_FileType() {
		return (EAttribute)collavizModelInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollavizObjectInstance() {
		return collavizObjectInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_InstanceOf() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Attributes() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Dependencies() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_Name() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Support() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Supported() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Position() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_Owners() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_AccessLevel() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_RefProxy() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_BecomeReferent() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCollavizObjectInstance_BecomeOwner() {
		return (EAttribute)collavizObjectInstanceEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollavizObjectInstance_Color() {
		return (EReference)collavizObjectInstanceEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDependencyInstance() {
		return dependencyInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependencyInstance_InstanceOf() {
		return (EReference)dependencyInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDependencyInstance_Target() {
		return (EReference)dependencyInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDependencyInstance_Name() {
		return (EAttribute)dependencyInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttributeInstance() {
		return attributeInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttributeInstance_Value() {
		return (EReference)attributeInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAttributeInstance_InstanceOf() {
		return (EReference)attributeInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttributeInstance_Name() {
		return (EAttribute)attributeInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransform() {
		return transformEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransform_IsRelative() {
		return (EAttribute)transformEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransform_X() {
		return (EAttribute)transformEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransform_Y() {
		return (EAttribute)transformEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransform_Z() {
		return (EAttribute)transformEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransformEulerAngles() {
		return transformEulerAnglesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAngles_H() {
		return (EAttribute)transformEulerAnglesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAngles_P() {
		return (EAttribute)transformEulerAnglesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAngles_R() {
		return (EAttribute)transformEulerAnglesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransformEulerAnglesScale() {
		return transformEulerAnglesScaleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAnglesScale_H() {
		return (EAttribute)transformEulerAnglesScaleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAnglesScale_P() {
		return (EAttribute)transformEulerAnglesScaleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAnglesScale_R() {
		return (EAttribute)transformEulerAnglesScaleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAnglesScale_Sx() {
		return (EAttribute)transformEulerAnglesScaleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAnglesScale_Sy() {
		return (EAttribute)transformEulerAnglesScaleEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformEulerAnglesScale_Sz() {
		return (EAttribute)transformEulerAnglesScaleEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransformQuaternionScale() {
		return transformQuaternionScaleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformQuaternionScale_Qx() {
		return (EAttribute)transformQuaternionScaleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformQuaternionScale_Qy() {
		return (EAttribute)transformQuaternionScaleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformQuaternionScale_Qz() {
		return (EAttribute)transformQuaternionScaleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformQuaternionScale_Qw() {
		return (EAttribute)transformQuaternionScaleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformQuaternionScale_Sx() {
		return (EAttribute)transformQuaternionScaleEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformQuaternionScale_Sy() {
		return (EAttribute)transformQuaternionScaleEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransformQuaternionScale_Sz() {
		return (EAttribute)transformQuaternionScaleEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getColor() {
		return colorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getColor_R() {
		return (EAttribute)colorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getColor_G() {
		return (EAttribute)colorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getColor_B() {
		return (EAttribute)colorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getColor_A() {
		return (EAttribute)colorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIntegerInstance() {
		return integerInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIntegerInstance_Value() {
		return (EAttribute)integerInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDoubleInstance() {
		return doubleInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoubleInstance_Value() {
		return (EAttribute)doubleInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBooleanInstance() {
		return booleanInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBooleanInstance_Value() {
		return (EAttribute)booleanInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getShortInstance() {
		return shortInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShortInstance_Value() {
		return (EAttribute)shortInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStringInstance() {
		return stringInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStringInstance_Value() {
		return (EAttribute)stringInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLongInstance() {
		return longInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLongInstance_Value() {
		return (EAttribute)longInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFloatInstance() {
		return floatInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFloatInstance_Value() {
		return (EAttribute)floatInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCharInstance() {
		return charInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCharInstance_Value() {
		return (EAttribute)charInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCollectionInstance() {
		return collectionInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCollectionInstance_Values() {
		return (EReference)collectionInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTreeInstance() {
		return treeInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTreeInstance_Values() {
		return (EReference)treeInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTreeInstance_Name() {
		return (EAttribute)treeInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getValue() {
		return valueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOwnersValue() {
		return ownersValueEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getFileType() {
		return fileTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceFactory getCollavizInstanceFactory() {
		return (CollavizInstanceFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		collavizModelInstanceEClass = createEClass(COLLAVIZ_MODEL_INSTANCE);
		createEReference(collavizModelInstanceEClass, COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES);
		createEAttribute(collavizModelInstanceEClass, COLLAVIZ_MODEL_INSTANCE__NAME);
		createEAttribute(collavizModelInstanceEClass, COLLAVIZ_MODEL_INSTANCE__FILE_TYPE);

		collavizObjectInstanceEClass = createEClass(COLLAVIZ_OBJECT_INSTANCE);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__NAME);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__SUPPORT);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__SUPPORTED);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__POSITION);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__OWNERS);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__ACCESS_LEVEL);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__REF_PROXY);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__BECOME_REFERENT);
		createEAttribute(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__BECOME_OWNER);
		createEReference(collavizObjectInstanceEClass, COLLAVIZ_OBJECT_INSTANCE__COLOR);

		dependencyInstanceEClass = createEClass(DEPENDENCY_INSTANCE);
		createEReference(dependencyInstanceEClass, DEPENDENCY_INSTANCE__INSTANCE_OF);
		createEReference(dependencyInstanceEClass, DEPENDENCY_INSTANCE__TARGET);
		createEAttribute(dependencyInstanceEClass, DEPENDENCY_INSTANCE__NAME);

		attributeInstanceEClass = createEClass(ATTRIBUTE_INSTANCE);
		createEReference(attributeInstanceEClass, ATTRIBUTE_INSTANCE__VALUE);
		createEReference(attributeInstanceEClass, ATTRIBUTE_INSTANCE__INSTANCE_OF);
		createEAttribute(attributeInstanceEClass, ATTRIBUTE_INSTANCE__NAME);

		transformEClass = createEClass(TRANSFORM);
		createEAttribute(transformEClass, TRANSFORM__IS_RELATIVE);
		createEAttribute(transformEClass, TRANSFORM__X);
		createEAttribute(transformEClass, TRANSFORM__Y);
		createEAttribute(transformEClass, TRANSFORM__Z);

		transformEulerAnglesEClass = createEClass(TRANSFORM_EULER_ANGLES);
		createEAttribute(transformEulerAnglesEClass, TRANSFORM_EULER_ANGLES__H);
		createEAttribute(transformEulerAnglesEClass, TRANSFORM_EULER_ANGLES__P);
		createEAttribute(transformEulerAnglesEClass, TRANSFORM_EULER_ANGLES__R);

		transformEulerAnglesScaleEClass = createEClass(TRANSFORM_EULER_ANGLES_SCALE);
		createEAttribute(transformEulerAnglesScaleEClass, TRANSFORM_EULER_ANGLES_SCALE__H);
		createEAttribute(transformEulerAnglesScaleEClass, TRANSFORM_EULER_ANGLES_SCALE__P);
		createEAttribute(transformEulerAnglesScaleEClass, TRANSFORM_EULER_ANGLES_SCALE__R);
		createEAttribute(transformEulerAnglesScaleEClass, TRANSFORM_EULER_ANGLES_SCALE__SX);
		createEAttribute(transformEulerAnglesScaleEClass, TRANSFORM_EULER_ANGLES_SCALE__SY);
		createEAttribute(transformEulerAnglesScaleEClass, TRANSFORM_EULER_ANGLES_SCALE__SZ);

		transformQuaternionScaleEClass = createEClass(TRANSFORM_QUATERNION_SCALE);
		createEAttribute(transformQuaternionScaleEClass, TRANSFORM_QUATERNION_SCALE__QX);
		createEAttribute(transformQuaternionScaleEClass, TRANSFORM_QUATERNION_SCALE__QY);
		createEAttribute(transformQuaternionScaleEClass, TRANSFORM_QUATERNION_SCALE__QZ);
		createEAttribute(transformQuaternionScaleEClass, TRANSFORM_QUATERNION_SCALE__QW);
		createEAttribute(transformQuaternionScaleEClass, TRANSFORM_QUATERNION_SCALE__SX);
		createEAttribute(transformQuaternionScaleEClass, TRANSFORM_QUATERNION_SCALE__SY);
		createEAttribute(transformQuaternionScaleEClass, TRANSFORM_QUATERNION_SCALE__SZ);

		colorEClass = createEClass(COLOR);
		createEAttribute(colorEClass, COLOR__R);
		createEAttribute(colorEClass, COLOR__G);
		createEAttribute(colorEClass, COLOR__B);
		createEAttribute(colorEClass, COLOR__A);

		integerInstanceEClass = createEClass(INTEGER_INSTANCE);
		createEAttribute(integerInstanceEClass, INTEGER_INSTANCE__VALUE);

		doubleInstanceEClass = createEClass(DOUBLE_INSTANCE);
		createEAttribute(doubleInstanceEClass, DOUBLE_INSTANCE__VALUE);

		booleanInstanceEClass = createEClass(BOOLEAN_INSTANCE);
		createEAttribute(booleanInstanceEClass, BOOLEAN_INSTANCE__VALUE);

		shortInstanceEClass = createEClass(SHORT_INSTANCE);
		createEAttribute(shortInstanceEClass, SHORT_INSTANCE__VALUE);

		stringInstanceEClass = createEClass(STRING_INSTANCE);
		createEAttribute(stringInstanceEClass, STRING_INSTANCE__VALUE);

		longInstanceEClass = createEClass(LONG_INSTANCE);
		createEAttribute(longInstanceEClass, LONG_INSTANCE__VALUE);

		floatInstanceEClass = createEClass(FLOAT_INSTANCE);
		createEAttribute(floatInstanceEClass, FLOAT_INSTANCE__VALUE);

		charInstanceEClass = createEClass(CHAR_INSTANCE);
		createEAttribute(charInstanceEClass, CHAR_INSTANCE__VALUE);

		collectionInstanceEClass = createEClass(COLLECTION_INSTANCE);
		createEReference(collectionInstanceEClass, COLLECTION_INSTANCE__VALUES);

		treeInstanceEClass = createEClass(TREE_INSTANCE);
		createEReference(treeInstanceEClass, TREE_INSTANCE__VALUES);
		createEAttribute(treeInstanceEClass, TREE_INSTANCE__NAME);

		valueEClass = createEClass(VALUE);

		// Create enums
		ownersValueEEnum = createEEnum(OWNERS_VALUE);
		fileTypeEEnum = createEEnum(FILE_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CollavizPackage theCollavizPackage = (CollavizPackage)EPackage.Registry.INSTANCE.getEPackage(CollavizPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		transformEClass.getESuperTypes().add(this.getValue());
		transformEulerAnglesEClass.getESuperTypes().add(this.getTransform());
		transformEulerAnglesScaleEClass.getESuperTypes().add(this.getTransform());
		transformQuaternionScaleEClass.getESuperTypes().add(this.getTransform());
		colorEClass.getESuperTypes().add(this.getValue());
		integerInstanceEClass.getESuperTypes().add(this.getValue());
		doubleInstanceEClass.getESuperTypes().add(this.getValue());
		booleanInstanceEClass.getESuperTypes().add(this.getValue());
		shortInstanceEClass.getESuperTypes().add(this.getValue());
		stringInstanceEClass.getESuperTypes().add(this.getValue());
		longInstanceEClass.getESuperTypes().add(this.getValue());
		floatInstanceEClass.getESuperTypes().add(this.getValue());
		charInstanceEClass.getESuperTypes().add(this.getValue());
		collectionInstanceEClass.getESuperTypes().add(this.getValue());
		treeInstanceEClass.getESuperTypes().add(this.getValue());

		// Initialize classes and features; add operations and parameters
		initEClass(collavizModelInstanceEClass, CollavizModelInstance.class, "CollavizModelInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizModelInstance_ObjectInstances(), this.getCollavizObjectInstance(), null, "objectInstances", null, 0, -1, CollavizModelInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizModelInstance_Name(), theCollavizPackage.getString(), "name", null, 1, 1, CollavizModelInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizModelInstance_FileType(), this.getFileType(), "fileType", "1", 1, 1, CollavizModelInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(collavizObjectInstanceEClass, CollavizObjectInstance.class, "CollavizObjectInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollavizObjectInstance_InstanceOf(), theCollavizPackage.getCollavizObject(), null, "instanceOf", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Attributes(), this.getAttributeInstance(), null, "attributes", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Dependencies(), this.getDependencyInstance(), null, "dependencies", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_Name(), theCollavizPackage.getString(), "name", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Support(), this.getCollavizObjectInstance(), this.getCollavizObjectInstance_Supported(), "support", null, 0, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Supported(), this.getCollavizObjectInstance(), this.getCollavizObjectInstance_Support(), "supported", null, 0, -1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Position(), this.getTransform(), null, "position", null, 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_Owners(), this.getOwnersValue(), "owners", "0", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_AccessLevel(), theCollavizPackage.getint(), "accessLevel", "3", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_RefProxy(), theCollavizPackage.getboolean(), "refProxy", "true", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_BecomeReferent(), theCollavizPackage.getboolean(), "becomeReferent", "true", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCollavizObjectInstance_BecomeOwner(), theCollavizPackage.getboolean(), "becomeOwner", "true", 1, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCollavizObjectInstance_Color(), this.getColor(), null, "color", null, 0, 1, CollavizObjectInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dependencyInstanceEClass, DependencyInstance.class, "DependencyInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDependencyInstance_InstanceOf(), theCollavizPackage.getDependency(), null, "instanceOf", null, 1, 1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDependencyInstance_Target(), this.getCollavizObjectInstance(), null, "target", null, 1, -1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDependencyInstance_Name(), theCollavizPackage.getString(), "name", "", 0, 1, DependencyInstance.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(attributeInstanceEClass, AttributeInstance.class, "AttributeInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttributeInstance_Value(), this.getValue(), null, "value", null, 1, 1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttributeInstance_InstanceOf(), theCollavizPackage.getAttribute(), null, "instanceOf", null, 1, 1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttributeInstance_Name(), theCollavizPackage.getString(), "name", "", 0, 1, AttributeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(transformEClass, Transform.class, "Transform", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransform_IsRelative(), theCollavizPackage.getboolean(), "isRelative", "position", 0, 1, Transform.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransform_X(), theCollavizPackage.getdouble(), "x", "0.0", 1, 1, Transform.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransform_Y(), theCollavizPackage.getdouble(), "y", "0.0", 1, 1, Transform.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransform_Z(), theCollavizPackage.getdouble(), "z", "0.0", 1, 1, Transform.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(transformEClass, this.getCollavizObjectInstance(), "getParent", 1, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(transformEulerAnglesEClass, TransformEulerAngles.class, "TransformEulerAngles", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransformEulerAngles_H(), theCollavizPackage.getdouble(), "h", "0.0", 1, 1, TransformEulerAngles.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformEulerAngles_P(), theCollavizPackage.getdouble(), "p", "0.0", 1, 1, TransformEulerAngles.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformEulerAngles_R(), theCollavizPackage.getdouble(), "r", "0.0", 1, 1, TransformEulerAngles.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(transformEulerAnglesScaleEClass, TransformEulerAnglesScale.class, "TransformEulerAnglesScale", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransformEulerAnglesScale_H(), theCollavizPackage.getdouble(), "h", "0.0", 1, 1, TransformEulerAnglesScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformEulerAnglesScale_P(), theCollavizPackage.getdouble(), "p", "0.0", 1, 1, TransformEulerAnglesScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformEulerAnglesScale_R(), theCollavizPackage.getdouble(), "r", "0.0", 1, 1, TransformEulerAnglesScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformEulerAnglesScale_Sx(), theCollavizPackage.getdouble(), "sx", "0.0", 1, 1, TransformEulerAnglesScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformEulerAnglesScale_Sy(), theCollavizPackage.getdouble(), "sy", "0.0", 1, 1, TransformEulerAnglesScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformEulerAnglesScale_Sz(), theCollavizPackage.getdouble(), "sz", "0.0", 1, 1, TransformEulerAnglesScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(transformQuaternionScaleEClass, TransformQuaternionScale.class, "TransformQuaternionScale", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransformQuaternionScale_Qx(), theCollavizPackage.getdouble(), "qx", "0.0", 1, 1, TransformQuaternionScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformQuaternionScale_Qy(), theCollavizPackage.getdouble(), "qy", "0.0", 1, 1, TransformQuaternionScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformQuaternionScale_Qz(), theCollavizPackage.getdouble(), "qz", "0.0", 1, 1, TransformQuaternionScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformQuaternionScale_Qw(), theCollavizPackage.getdouble(), "qw", "0.0", 1, 1, TransformQuaternionScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformQuaternionScale_Sx(), theCollavizPackage.getdouble(), "sx", "0.0", 1, 1, TransformQuaternionScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformQuaternionScale_Sy(), theCollavizPackage.getdouble(), "sy", "0.0", 1, 1, TransformQuaternionScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransformQuaternionScale_Sz(), theCollavizPackage.getdouble(), "sz", "0.0", 1, 1, TransformQuaternionScale.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(colorEClass, Color.class, "Color", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getColor_R(), theCollavizPackage.getdouble(), "r", null, 1, 1, Color.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getColor_G(), theCollavizPackage.getdouble(), "g", null, 1, 1, Color.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getColor_B(), theCollavizPackage.getdouble(), "b", null, 1, 1, Color.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getColor_A(), theCollavizPackage.getdouble(), "a", null, 0, 1, Color.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(integerInstanceEClass, IntegerInstance.class, "IntegerInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIntegerInstance_Value(), theCollavizPackage.getint(), "value", null, 1, 1, IntegerInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(doubleInstanceEClass, DoubleInstance.class, "DoubleInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDoubleInstance_Value(), theCollavizPackage.getdouble(), "value", null, 1, 1, DoubleInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(booleanInstanceEClass, BooleanInstance.class, "BooleanInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBooleanInstance_Value(), theCollavizPackage.getboolean(), "value", null, 1, 1, BooleanInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(shortInstanceEClass, ShortInstance.class, "ShortInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getShortInstance_Value(), theCollavizPackage.getshort(), "value", null, 1, 1, ShortInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(stringInstanceEClass, StringInstance.class, "StringInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStringInstance_Value(), theCollavizPackage.getString(), "value", null, 1, 1, StringInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(longInstanceEClass, LongInstance.class, "LongInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLongInstance_Value(), theCollavizPackage.getlong(), "value", null, 1, 1, LongInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(floatInstanceEClass, FloatInstance.class, "FloatInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFloatInstance_Value(), theCollavizPackage.getfloat(), "value", null, 1, 1, FloatInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(charInstanceEClass, CharInstance.class, "CharInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCharInstance_Value(), theCollavizPackage.getchar(), "value", null, 1, 1, CharInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(collectionInstanceEClass, CollectionInstance.class, "CollectionInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCollectionInstance_Values(), this.getValue(), null, "values", null, 0, -1, CollectionInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(treeInstanceEClass, TreeInstance.class, "TreeInstance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTreeInstance_Values(), this.getValue(), null, "values", null, 0, -1, TreeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTreeInstance_Name(), theCollavizPackage.getString(), "name", null, 1, 1, TreeInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(valueEClass, Value.class, "Value", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(ownersValueEEnum, OwnersValue.class, "OwnersValue");
		addEEnumLiteral(ownersValueEEnum, OwnersValue.ALL);
		addEEnumLiteral(ownersValueEEnum, OwnersValue.ME);

		initEEnum(fileTypeEEnum, FileType.class, "FileType");
		addEEnumLiteral(fileTypeEEnum, FileType.IVC_DESCRIPTION);
		addEEnumLiteral(fileTypeEEnum, FileType.WORLD_DESCRIPTION);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL
		createOCLAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";		
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL"
		   });		
		addAnnotation
		  (collavizObjectInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "DependencyMustBeSet DependencyInstanceIsUnique DependencyOnlyInObjectDefinition AttributeMustBeSet AttributeInstanceIsUnique AttributeOnlyInObjectDefinition"
		   });			
		addAnnotation
		  (dependencyInstanceEClass, 
		   source, 
		   new String[] {
			 "constraints", "DependencyInstanceTargetNumber DependencyInstanceTargetGoodType"
		   });				
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createOCLAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL";				
		addAnnotation
		  (collavizObjectInstanceEClass, 
		   source, 
		   new String[] {
			 "DependencyMustBeSet", "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependencies->forAll(d : Collaviz::GenericAttribute | dependenciesInstance->includes(d)) and dependencies->size() <= dependenciesInstance->size()",
			 "DependencyInstanceIsUnique", "let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(d1 : Collaviz::Dependency |  dependenciesInstance->count(d1)=1)",
			 "DependencyOnlyInObjectDefinition", "let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(di : Collaviz::Dependency | dependencies->includes(di))",
			 "AttributeMustBeSet", "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributes->forAll(a : Collaviz::GenericAttribute | attributesInstance->includes(a)) and attributes->size() <= attributesInstance->size()",
			 "AttributeInstanceIsUnique", "let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(a : Collaviz::Attribute |  attributesInstance->count(a)=1)",
			 "AttributeOnlyInObjectDefinition", "let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(ai : Collaviz::Attribute | attributes->includes(ai))"
		   });			
		addAnnotation
		  (dependencyInstanceEClass, 
		   source, 
		   new String[] {
			 "DependencyInstanceTargetNumber", "if self.instanceOf.upperBound=-1 then\r\n\tself.target->size()>=self.instanceOf.lowerBound\r\nelse\r\n\tself.target->size()>=self.instanceOf.lowerBound and self.target->size()<=self.instanceOf.upperBound\r\nendif",
			 "DependencyInstanceTargetGoodType", "self.target->forAll(t : CollavizObjectInstance | \t\t\r\n\tlet superTypes : Sequence(Collaviz::CollavizObject)=t.instanceOf.getAllSuperTypes()->union(Sequence{t.instanceOf})\r\n\tin\r\n\tsuperTypes->includes(self.instanceOf.type))"
		   });		
		addAnnotation
		  (getDependencyInstance_Name(), 
		   source, 
		   new String[] {
			 "derivation", "if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif"
		   });		
		addAnnotation
		  (getAttributeInstance_Name(), 
		   source, 
		   new String[] {
			 "derivation", "if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif"
		   });		
		addAnnotation
		  (getTransform_IsRelative(), 
		   source, 
		   new String[] {
			 "derivation", "if self.getParent().support.oclIsUndefined() then\r\n\tfalse\r\nelse\r\n\ttrue\r\nendif"
		   });
	}

} //CollavizInstancePackageImpl
