/**
 */
package CollavizInstance.impl;

import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.Transform;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transform</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CollavizInstance.impl.TransformImpl#getIsRelative <em>Is Relative</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformImpl#getX <em>X</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformImpl#getY <em>Y</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformImpl#getZ <em>Z</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class TransformImpl extends ValueImpl implements Transform {
	/**
	 * The cached setting delegate for the '{@link #getIsRelative() <em>Is Relative</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsRelative()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate IS_RELATIVE__ESETTING_DELEGATE = ((EStructuralFeature.Internal)CollavizInstancePackage.Literals.TRANSFORM__IS_RELATIVE).getSettingDelegate();

	/**
	 * The default value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected static final Double X_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getX() <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX()
	 * @generated
	 * @ordered
	 */
	protected Double x = X_EDEFAULT;

	/**
	 * The default value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected static final Double Y_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getY() <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY()
	 * @generated
	 * @ordered
	 */
	protected Double y = Y_EDEFAULT;

	/**
	 * The default value of the '{@link #getZ() <em>Z</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getZ()
	 * @generated
	 * @ordered
	 */
	protected static final Double Z_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getZ() <em>Z</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getZ()
	 * @generated
	 * @ordered
	 */
	protected Double z = Z_EDEFAULT;

	
	/**
	 * Convert attributes x y z to String
	 */
	protected static final String XYZ_EDEFAULT = "0 0 0";
	protected String XYZ = XYZ_EDEFAULT;
	
	public void setXYZ(String xyz){
		try{
			String[] st = xyz.split(" ");
			Double x_tmp = Double.parseDouble(st[0]);
			Double y_tmp = Double.parseDouble(st[1]);
			Double z_tmp = Double.parseDouble(st[2]);
			setX(x_tmp);
			setY(y_tmp);
			setZ(z_tmp);
			XYZ = x_tmp+" "+y_tmp+" "+z_tmp;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String getXYZ(){
		return XYZ;
	}
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransformImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizInstancePackage.Literals.TRANSFORM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsRelative() {
		return (Boolean)IS_RELATIVE__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getX() {
		return x;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setX(Double newX) {
		Double oldX = x;
		x = newX;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM__X, oldX, x));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getY() {
		return y;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setY(Double newY) {
		Double oldY = y;
		y = newY;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM__Y, oldY, y));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getZ() {
		return z;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setZ(Double newZ) {
		Double oldZ = z;
		z = newZ;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM__Z, oldZ, z));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	public CollavizObjectInstance getParent() {
		if(this.eContainer()!=null){
			return (CollavizObjectInstance) this.eContainer();
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM__IS_RELATIVE:
				return getIsRelative();
			case CollavizInstancePackage.TRANSFORM__X:
				return getX();
			case CollavizInstancePackage.TRANSFORM__Y:
				return getY();
			case CollavizInstancePackage.TRANSFORM__Z:
				return getZ();
			case CollavizInstancePackage.TRANSFORM__XYZ:
				return getXYZ();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM__X:
				setX((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM__Y:
				setY((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM__Z:
				setZ((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM__XYZ:
				setXYZ((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM__X:
				setX(X_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM__Y:
				setY(Y_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM__Z:
				setZ(Z_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM__IS_RELATIVE:
				return IS_RELATIVE__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
			case CollavizInstancePackage.TRANSFORM__X:
				return X_EDEFAULT == null ? x != null : !X_EDEFAULT.equals(x);
			case CollavizInstancePackage.TRANSFORM__Y:
				return Y_EDEFAULT == null ? y != null : !Y_EDEFAULT.equals(y);
			case CollavizInstancePackage.TRANSFORM__Z:
				return Z_EDEFAULT == null ? z != null : !Z_EDEFAULT.equals(z);
			case CollavizInstancePackage.TRANSFORM__XYZ:
				return XYZ_EDEFAULT == null ? XYZ != null : !XYZ_EDEFAULT.equals(XYZ);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (x: ");
		result.append(x);
		result.append(", y: ");
		result.append(y);
		result.append(", z: ");
		result.append(z);
		result.append(')');
		return result.toString();
	}

} //TransformImpl
