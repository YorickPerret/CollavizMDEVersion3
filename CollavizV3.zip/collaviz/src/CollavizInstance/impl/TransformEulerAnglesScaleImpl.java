/**
 */
package CollavizInstance.impl;

import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.TransformEulerAnglesScale;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transform Euler Angles Scale</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl#getH <em>H</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl#getP <em>P</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl#getR <em>R</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl#getSx <em>Sx</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl#getSy <em>Sy</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl#getSz <em>Sz</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TransformEulerAnglesScaleImpl extends TransformImpl implements TransformEulerAnglesScale {
	/**
	 * The default value of the '{@link #getH() <em>H</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getH()
	 * @generated
	 * @ordered
	 */
	protected static final Double H_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getH() <em>H</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getH()
	 * @generated
	 * @ordered
	 */
	protected Double h = H_EDEFAULT;

	/**
	 * The default value of the '{@link #getP() <em>P</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getP()
	 * @generated
	 * @ordered
	 */
	protected static final Double P_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getP() <em>P</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getP()
	 * @generated
	 * @ordered
	 */
	protected Double p = P_EDEFAULT;

	/**
	 * The default value of the '{@link #getR() <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getR()
	 * @generated
	 * @ordered
	 */
	protected static final Double R_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getR() <em>R</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getR()
	 * @generated
	 * @ordered
	 */
	protected Double r = R_EDEFAULT;

	/**
	 * The default value of the '{@link #getSx() <em>Sx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSx()
	 * @generated
	 * @ordered
	 */
	protected static final Double SX_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getSx() <em>Sx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSx()
	 * @generated
	 * @ordered
	 */
	protected Double sx = SX_EDEFAULT;

	/**
	 * The default value of the '{@link #getSy() <em>Sy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSy()
	 * @generated
	 * @ordered
	 */
	protected static final Double SY_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getSy() <em>Sy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSy()
	 * @generated
	 * @ordered
	 */
	protected Double sy = SY_EDEFAULT;

	/**
	 * The default value of the '{@link #getSz() <em>Sz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSz()
	 * @generated
	 * @ordered
	 */
	protected static final Double SZ_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getSz() <em>Sz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSz()
	 * @generated
	 * @ordered
	 */
	protected Double sz = SZ_EDEFAULT;

	
	/**
	 * convert h p r to string
	 */
	private static final String HPR_EDEFAULT = "";
	protected String hpr = HPR_EDEFAULT;
	
	public void setHPR(String newHPR){
		try{
			String[] st = newHPR.split(" ");
			Double h_tmp = Double.parseDouble(st[0]);
			Double p_tmp = Double.parseDouble(st[1]);
			Double r_tmp = Double.parseDouble(st[2]);
			setH(h_tmp);
			setP(p_tmp);
			setR(r_tmp);
			hpr = h_tmp+" "+p_tmp+" "+r_tmp;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String getHPR(){
		return hpr;
	}
	
	
	/**
	 * convert sx sy sz to string
	 */
	private static final String SXSYSZ_EDEFAULT = "";
	protected String sxsysz = SXSYSZ_EDEFAULT;
	
	public void setSXSYSZ(String newSXSYSZ){
		try{
			String[] st = newSXSYSZ.split(" ");
			Double sx_tmp = Double.parseDouble(st[0]);
			Double sy_tmp = Double.parseDouble(st[1]);
			Double sz_tmp = Double.parseDouble(st[2]);
			setSx(sx_tmp);
			setSy(sy_tmp);
			setSz(sz_tmp);
			sxsysz = sx_tmp+" "+sy_tmp+" "+sz_tmp;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String getSXSYSZ(){
		return sxsysz;
	}
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransformEulerAnglesScaleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizInstancePackage.Literals.TRANSFORM_EULER_ANGLES_SCALE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getH() {
		return h;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setH(Double newH) {
		Double oldH = h;
		h = newH;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__H, oldH, h));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getP() {
		return p;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setP(Double newP) {
		Double oldP = p;
		p = newP;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__P, oldP, p));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getR() {
		return r;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setR(Double newR) {
		Double oldR = r;
		r = newR;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__R, oldR, r));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getSx() {
		return sx;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSx(Double newSx) {
		Double oldSx = sx;
		sx = newSx;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SX, oldSx, sx));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getSy() {
		return sy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSy(Double newSy) {
		Double oldSy = sy;
		sy = newSy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SY, oldSy, sy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getSz() {
		return sz;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSz(Double newSz) {
		Double oldSz = sz;
		sz = newSz;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SZ, oldSz, sz));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__H:
				return getH();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__P:
				return getP();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__R:
				return getR();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SX:
				return getSx();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SY:
				return getSy();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SZ:
				return getSz();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__HPR:
				return getHPR();	
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SXSYSZ:
				return getSXSYSZ();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__H:
				setH((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__P:
				setP((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__R:
				setR((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SX:
				setSx((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SY:
				setSy((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SZ:
				setSz((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__HPR:
				setHPR((String)newValue);
				return;	
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SXSYSZ:
				setSXSYSZ((String)newValue);
				return;	
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__H:
				setH(H_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__P:
				setP(P_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__R:
				setR(R_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SX:
				setSx(SX_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SY:
				setSy(SY_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SZ:
				setSz(SZ_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__H:
				return H_EDEFAULT == null ? h != null : !H_EDEFAULT.equals(h);
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__P:
				return P_EDEFAULT == null ? p != null : !P_EDEFAULT.equals(p);
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__R:
				return R_EDEFAULT == null ? r != null : !R_EDEFAULT.equals(r);
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SX:
				return SX_EDEFAULT == null ? sx != null : !SX_EDEFAULT.equals(sx);
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SY:
				return SY_EDEFAULT == null ? sy != null : !SY_EDEFAULT.equals(sy);
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE__SZ:
				return SZ_EDEFAULT == null ? sz != null : !SZ_EDEFAULT.equals(sz);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (h: ");
		result.append(h);
		result.append(", p: ");
		result.append(p);
		result.append(", r: ");
		result.append(r);
		result.append(", sx: ");
		result.append(sx);
		result.append(", sy: ");
		result.append(sy);
		result.append(", sz: ");
		result.append(sz);
		result.append(')');
		return result.toString();
	}

} //TransformEulerAnglesScaleImpl
