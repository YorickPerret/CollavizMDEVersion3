/**
 */
package CollavizInstance.impl;

import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.TransformQuaternionScale;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transform Quaternion Scale</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CollavizInstance.impl.TransformQuaternionScaleImpl#getQx <em>Qx</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformQuaternionScaleImpl#getQy <em>Qy</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformQuaternionScaleImpl#getQz <em>Qz</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformQuaternionScaleImpl#getQw <em>Qw</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformQuaternionScaleImpl#getSx <em>Sx</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformQuaternionScaleImpl#getSy <em>Sy</em>}</li>
 *   <li>{@link CollavizInstance.impl.TransformQuaternionScaleImpl#getSz <em>Sz</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TransformQuaternionScaleImpl extends TransformImpl implements TransformQuaternionScale {
	/**
	 * The default value of the '{@link #getQx() <em>Qx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQx()
	 * @generated
	 * @ordered
	 */
	protected static final Double QX_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getQx() <em>Qx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQx()
	 * @generated
	 * @ordered
	 */
	protected Double qx = QX_EDEFAULT;

	/**
	 * The default value of the '{@link #getQy() <em>Qy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQy()
	 * @generated
	 * @ordered
	 */
	protected static final Double QY_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getQy() <em>Qy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQy()
	 * @generated
	 * @ordered
	 */
	protected Double qy = QY_EDEFAULT;

	/**
	 * The default value of the '{@link #getQz() <em>Qz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQz()
	 * @generated
	 * @ordered
	 */
	protected static final Double QZ_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getQz() <em>Qz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQz()
	 * @generated
	 * @ordered
	 */
	protected Double qz = QZ_EDEFAULT;

	/**
	 * The default value of the '{@link #getQw() <em>Qw</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQw()
	 * @generated
	 * @ordered
	 */
	protected static final Double QW_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getQw() <em>Qw</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQw()
	 * @generated
	 * @ordered
	 */
	protected Double qw = QW_EDEFAULT;

	/**
	 * The default value of the '{@link #getSx() <em>Sx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSx()
	 * @generated
	 * @ordered
	 */
	protected static final Double SX_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getSx() <em>Sx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSx()
	 * @generated
	 * @ordered
	 */
	protected Double sx = SX_EDEFAULT;

	/**
	 * The default value of the '{@link #getSy() <em>Sy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSy()
	 * @generated
	 * @ordered
	 */
	protected static final Double SY_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getSy() <em>Sy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSy()
	 * @generated
	 * @ordered
	 */
	protected Double sy = SY_EDEFAULT;

	/**
	 * The default value of the '{@link #getSz() <em>Sz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSz()
	 * @generated
	 * @ordered
	 */
	protected static final Double SZ_EDEFAULT = new Double(0.0);

	/**
	 * The cached value of the '{@link #getSz() <em>Sz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSz()
	 * @generated
	 * @ordered
	 */
	protected Double sz = SZ_EDEFAULT;

	
	/**
	 * convert qx qy qz qw to string
	 */
	private static final String QXQYQZQW_EDEFAULT = "0.0 0.0 0.0 0.0";
	protected String qxqyqzqw = QXQYQZQW_EDEFAULT;
	
	public void setQXQYQZQW(String value){
		try{
			String[] st = value.split(" ");
			Double qx_tmp = Double.parseDouble(st[0]);
			Double qy_tmp = Double.parseDouble(st[1]);
			Double qz_tmp = Double.parseDouble(st[2]);
			Double qw_tmp = Double.parseDouble(st[3]);
			setQx(qx_tmp);
			setQy(qy_tmp);
			setQz(qz_tmp);
			setQw(qw_tmp);
			qxqyqzqw = qx_tmp+" "+qy_tmp+" "+qz_tmp+" "+qw;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String getQXQYQZQW(){
		return qxqyqzqw;
	}
	
	/**
	 * convert sx sy sz to string
	 */
	private static final String SXSYSZ_EDEFAULT = "0.0 0.0 0.0";
	protected String sxsysz = SXSYSZ_EDEFAULT;
	
	public void setSXSYSZ(String newSXSYSZ){
		try{
			String[] st = newSXSYSZ.split(" ");
			Double sx_tmp = Double.parseDouble(st[0]);
			Double sy_tmp = Double.parseDouble(st[1]);
			Double sz_tmp = Double.parseDouble(st[2]);
			setSx(sx_tmp);
			setSy(sy_tmp);
			setSz(sz_tmp);
			sxsysz = sx_tmp+" "+sy_tmp+" "+sz_tmp;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String getSXSYSZ(){
		return sxsysz;
	}
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransformQuaternionScaleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizInstancePackage.Literals.TRANSFORM_QUATERNION_SCALE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getQx() {
		return qx;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQx(Double newQx) {
		Double oldQx = qx;
		qx = newQx;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QX, oldQx, qx));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getQy() {
		return qy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQy(Double newQy) {
		Double oldQy = qy;
		qy = newQy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QY, oldQy, qy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getQz() {
		return qz;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQz(Double newQz) {
		Double oldQz = qz;
		qz = newQz;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QZ, oldQz, qz));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getQw() {
		return qw;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQw(Double newQw) {
		Double oldQw = qw;
		qw = newQw;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QW, oldQw, qw));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getSx() {
		return sx;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSx(Double newSx) {
		Double oldSx = sx;
		sx = newSx;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SX, oldSx, sx));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getSy() {
		return sy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSy(Double newSy) {
		Double oldSy = sy;
		sy = newSy;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SY, oldSy, sy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double getSz() {
		return sz;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSz(Double newSz) {
		Double oldSz = sz;
		sz = newSz;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SZ, oldSz, sz));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QX:
				return getQx();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QY:
				return getQy();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QZ:
				return getQz();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QW:
				return getQw();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SX:
				return getSx();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SY:
				return getSy();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SZ:
				return getSz();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QXQYQZQW:
				return getQXQYQZQW();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SXSYSZ:
				return getSXSYSZ();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QX:
				setQx((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QY:
				setQy((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QZ:
				setQz((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QW:
				setQw((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SX:
				setSx((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SY:
				setSy((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SZ:
				setSz((Double)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QXQYQZQW:
				setQXQYQZQW((String)newValue);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SXSYSZ:
				setSXSYSZ((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QX:
				setQx(QX_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QY:
				setQy(QY_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QZ:
				setQz(QZ_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QW:
				setQw(QW_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SX:
				setSx(SX_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SY:
				setSy(SY_EDEFAULT);
				return;
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SZ:
				setSz(SZ_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QX:
				return QX_EDEFAULT == null ? qx != null : !QX_EDEFAULT.equals(qx);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QY:
				return QY_EDEFAULT == null ? qy != null : !QY_EDEFAULT.equals(qy);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QZ:
				return QZ_EDEFAULT == null ? qz != null : !QZ_EDEFAULT.equals(qz);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QW:
				return QW_EDEFAULT == null ? qw != null : !QW_EDEFAULT.equals(qw);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SX:
				return SX_EDEFAULT == null ? sx != null : !SX_EDEFAULT.equals(sx);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SY:
				return SY_EDEFAULT == null ? sy != null : !SY_EDEFAULT.equals(sy);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SZ:
				return SZ_EDEFAULT == null ? sz != null : !SZ_EDEFAULT.equals(sz);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__QXQYQZQW:
				return QXQYQZQW_EDEFAULT == null ? qxqyqzqw != null : !QXQYQZQW_EDEFAULT.equals(qxqyqzqw);
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE__SXSYSZ:
				return SXSYSZ_EDEFAULT == null ? sxsysz != null : !SXSYSZ_EDEFAULT.equals(sxsysz);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (qx: ");
		result.append(qx);
		result.append(", qy: ");
		result.append(qy);
		result.append(", qz: ");
		result.append(qz);
		result.append(", qw: ");
		result.append(qw);
		result.append(", sx: ");
		result.append(sx);
		result.append(", sy: ");
		result.append(sy);
		result.append(", sz: ");
		result.append(sz);
		result.append(')');
		return result.toString();
	}

} //TransformQuaternionScaleImpl
