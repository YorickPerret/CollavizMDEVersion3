/**
 */
package CollavizInstance.impl;

import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizModelInstance;
import CollavizInstance.CollavizObjectInstance;

import CollavizInstance.FileType;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Collaviz Model Instance</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CollavizInstance.impl.CollavizModelInstanceImpl#getObjectInstances <em>Object Instances</em>}</li>
 *   <li>{@link CollavizInstance.impl.CollavizModelInstanceImpl#getName <em>Name</em>}</li>
 *   <li>{@link CollavizInstance.impl.CollavizModelInstanceImpl#getFileType <em>File Type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CollavizModelInstanceImpl extends EObjectImpl implements CollavizModelInstance {
	/**
	 * The cached value of the '{@link #getObjectInstances() <em>Object Instances</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectInstances()
	 * @generated
	 * @ordered
	 */
	protected EList<CollavizObjectInstance> objectInstances;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getFileType() <em>File Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileType()
	 * @generated
	 * @ordered
	 */
	protected static final FileType FILE_TYPE_EDEFAULT = FileType.IVC_DESCRIPTION;

	/**
	 * The cached value of the '{@link #getFileType() <em>File Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileType()
	 * @generated
	 * @ordered
	 */
	protected FileType fileType = FILE_TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizModelInstanceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizInstancePackage.Literals.COLLAVIZ_MODEL_INSTANCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CollavizObjectInstance> getObjectInstances() {
		if (objectInstances == null) {
			objectInstances = new EObjectContainmentEList<CollavizObjectInstance>(CollavizObjectInstance.class, this, CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES);
		}
		return objectInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FileType getFileType() {
		return fileType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFileType(FileType newFileType) {
		FileType oldFileType = fileType;
		fileType = newFileType == null ? FILE_TYPE_EDEFAULT : newFileType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__FILE_TYPE, oldFileType, fileType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				return ((InternalEList<?>)getObjectInstances()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				return getObjectInstances();
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__NAME:
				return getName();
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__FILE_TYPE:
				return getFileType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				getObjectInstances().clear();
				getObjectInstances().addAll((Collection<? extends CollavizObjectInstance>)newValue);
				return;
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__NAME:
				setName((String)newValue);
				return;
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__FILE_TYPE:
				setFileType((FileType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				getObjectInstances().clear();
				return;
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__FILE_TYPE:
				setFileType(FILE_TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				return objectInstances != null && !objectInstances.isEmpty();
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__FILE_TYPE:
				return fileType != FILE_TYPE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", fileType: ");
		result.append(fileType);
		result.append(')');
		return result.toString();
	}

} //CollavizModelInstanceImpl
