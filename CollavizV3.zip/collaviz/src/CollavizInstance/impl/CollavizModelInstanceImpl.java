/**
 */
package CollavizInstance.impl;

import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizModelInstance;
import CollavizInstance.CollavizObjectInstance;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Collaviz Model Instance</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link CollavizInstance.impl.CollavizModelInstanceImpl#getObjectInstances <em>Object Instances</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CollavizModelInstanceImpl extends EObjectImpl implements CollavizModelInstance {
	/**
	 * The cached value of the '{@link #getObjectInstances() <em>Object Instances</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjectInstances()
	 * @generated
	 * @ordered
	 */
	protected EList<CollavizObjectInstance> objectInstances;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizModelInstanceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizInstancePackage.Literals.COLLAVIZ_MODEL_INSTANCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CollavizObjectInstance> getObjectInstances() {
		if (objectInstances == null) {
			objectInstances = new EObjectContainmentEList<CollavizObjectInstance>(CollavizObjectInstance.class, this, CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES);
		}
		return objectInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				return ((InternalEList<?>)getObjectInstances()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				return getObjectInstances();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				getObjectInstances().clear();
				getObjectInstances().addAll((Collection<? extends CollavizObjectInstance>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				getObjectInstances().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES:
				return objectInstances != null && !objectInstances.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //CollavizModelInstanceImpl
