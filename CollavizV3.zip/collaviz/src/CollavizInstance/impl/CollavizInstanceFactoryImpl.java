/**
 */
package CollavizInstance.impl;

import CollavizInstance.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizInstanceFactoryImpl extends EFactoryImpl implements CollavizInstanceFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CollavizInstanceFactory init() {
		try {
			CollavizInstanceFactory theCollavizInstanceFactory = (CollavizInstanceFactory)EPackage.Registry.INSTANCE.getEFactory("http://CollavizInstance"); 
			if (theCollavizInstanceFactory != null) {
				return theCollavizInstanceFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CollavizInstanceFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE: return createCollavizModelInstance();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE: return createCollavizObjectInstance();
			case CollavizInstancePackage.DEPENDENCY_INSTANCE: return createDependencyInstance();
			case CollavizInstancePackage.ATTRIBUTE_INSTANCE: return createAttributeInstance();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case CollavizInstancePackage.STRING:
				return createStringFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case CollavizInstancePackage.STRING:
				return convertStringToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizModelInstance createCollavizModelInstance() {
		CollavizModelInstanceImpl collavizModelInstance = new CollavizModelInstanceImpl();
		return collavizModelInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObjectInstance createCollavizObjectInstance() {
		CollavizObjectInstanceImpl collavizObjectInstance = new CollavizObjectInstanceImpl();
		return collavizObjectInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DependencyInstance createDependencyInstance() {
		DependencyInstanceImpl dependencyInstance = new DependencyInstanceImpl();
		return dependencyInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeInstance createAttributeInstance() {
		AttributeInstanceImpl attributeInstance = new AttributeInstanceImpl();
		return attributeInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createStringFromString(EDataType eDataType, String initialValue) {
		return (String)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertStringToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstancePackage getCollavizInstancePackage() {
		return (CollavizInstancePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CollavizInstancePackage getPackage() {
		return CollavizInstancePackage.eINSTANCE;
	}

} //CollavizInstanceFactoryImpl
