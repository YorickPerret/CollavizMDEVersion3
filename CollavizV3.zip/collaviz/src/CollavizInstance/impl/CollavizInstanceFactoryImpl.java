/**
 */
package CollavizInstance.impl;

import CollavizInstance.*;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;

import CollavizInstance.AttributeInstance;
import CollavizInstance.CollavizInstanceFactory;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizModelInstance;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.DependencyInstance;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizInstanceFactoryImpl extends EFactoryImpl implements CollavizInstanceFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CollavizInstanceFactory init() {
		try {
			CollavizInstanceFactory theCollavizInstanceFactory = (CollavizInstanceFactory)EPackage.Registry.INSTANCE.getEFactory("http://CollavizInstance"); 
			if (theCollavizInstanceFactory != null) {
				return theCollavizInstanceFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CollavizInstanceFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE: return createCollavizModelInstance();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE: return createCollavizObjectInstance();
			case CollavizInstancePackage.DEPENDENCY_INSTANCE: return createDependencyInstance();
			case CollavizInstancePackage.ATTRIBUTE_INSTANCE: return createAttributeInstance();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES: return createTransformEulerAngles();
			case CollavizInstancePackage.TRANSFORM_EULER_ANGLES_SCALE: return createTransformEulerAnglesScale();
			case CollavizInstancePackage.TRANSFORM_QUATERNION_SCALE: return createTransformQuaternionScale();
			case CollavizInstancePackage.COLOR: return createColor();
			case CollavizInstancePackage.INTEGER_INSTANCE: return createIntegerInstance();
			case CollavizInstancePackage.DOUBLE_INSTANCE: return createDoubleInstance();
			case CollavizInstancePackage.BOOLEAN_INSTANCE: return createBooleanInstance();
			case CollavizInstancePackage.SHORT_INSTANCE: return createShortInstance();
			case CollavizInstancePackage.STRING_INSTANCE: return createStringInstance();
			case CollavizInstancePackage.LONG_INSTANCE: return createLongInstance();
			case CollavizInstancePackage.FLOAT_INSTANCE: return createFloatInstance();
			case CollavizInstancePackage.CHAR_INSTANCE: return createCharInstance();
			case CollavizInstancePackage.COLLECTION_INSTANCE: return createCollectionInstance();
			case CollavizInstancePackage.TREE_INSTANCE: return createTreeInstance();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case CollavizInstancePackage.OWNERS_VALUE:
				return createOwnersValueFromString(eDataType, initialValue);
			case CollavizInstancePackage.FILE_TYPE:
				return createFileTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case CollavizInstancePackage.OWNERS_VALUE:
				return convertOwnersValueToString(eDataType, instanceValue);
			case CollavizInstancePackage.FILE_TYPE:
				return convertFileTypeToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizModelInstance createCollavizModelInstance() {
		CollavizModelInstanceImpl collavizModelInstance = new CollavizModelInstanceImpl();
		return collavizModelInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObjectInstance createCollavizObjectInstance() {
		CollavizObjectInstanceImpl collavizObjectInstance = new CollavizObjectInstanceImpl();
		return collavizObjectInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DependencyInstance createDependencyInstance() {
		DependencyInstanceImpl dependencyInstance = new DependencyInstanceImpl();
		return dependencyInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeInstance createAttributeInstance() {
		AttributeInstanceImpl attributeInstance = new AttributeInstanceImpl();
		return attributeInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransformEulerAngles createTransformEulerAngles() {
		TransformEulerAnglesImpl transformEulerAngles = new TransformEulerAnglesImpl();
		return transformEulerAngles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransformEulerAnglesScale createTransformEulerAnglesScale() {
		TransformEulerAnglesScaleImpl transformEulerAnglesScale = new TransformEulerAnglesScaleImpl();
		return transformEulerAnglesScale;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransformQuaternionScale createTransformQuaternionScale() {
		TransformQuaternionScaleImpl transformQuaternionScale = new TransformQuaternionScaleImpl();
		return transformQuaternionScale;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Color createColor() {
		ColorImpl color = new ColorImpl();
		return color;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IntegerInstance createIntegerInstance() {
		IntegerInstanceImpl integerInstance = new IntegerInstanceImpl();
		return integerInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DoubleInstance createDoubleInstance() {
		DoubleInstanceImpl doubleInstance = new DoubleInstanceImpl();
		return doubleInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BooleanInstance createBooleanInstance() {
		BooleanInstanceImpl booleanInstance = new BooleanInstanceImpl();
		return booleanInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShortInstance createShortInstance() {
		ShortInstanceImpl shortInstance = new ShortInstanceImpl();
		return shortInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StringInstance createStringInstance() {
		StringInstanceImpl stringInstance = new StringInstanceImpl();
		return stringInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LongInstance createLongInstance() {
		LongInstanceImpl longInstance = new LongInstanceImpl();
		return longInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FloatInstance createFloatInstance() {
		FloatInstanceImpl floatInstance = new FloatInstanceImpl();
		return floatInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CharInstance createCharInstance() {
		CharInstanceImpl charInstance = new CharInstanceImpl();
		return charInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollectionInstance createCollectionInstance() {
		CollectionInstanceImpl collectionInstance = new CollectionInstanceImpl();
		return collectionInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TreeInstance createTreeInstance() {
		TreeInstanceImpl treeInstance = new TreeInstanceImpl();
		return treeInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OwnersValue createOwnersValueFromString(EDataType eDataType, String initialValue) {
		OwnersValue result = OwnersValue.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOwnersValueToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FileType createFileTypeFromString(EDataType eDataType, String initialValue) {
		FileType result = FileType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertFileTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstancePackage getCollavizInstancePackage() {
		return (CollavizInstancePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CollavizInstancePackage getPackage() {
		return CollavizInstancePackage.eINSTANCE;
	}

} //CollavizInstanceFactoryImpl
