/**
 */
package CollavizInstance.impl;

import CollavizInstance.*;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;

import CollavizInstance.AttributeInstance;
import CollavizInstance.CollavizInstanceFactory;
import CollavizInstance.CollavizInstancePackage;
import CollavizInstance.CollavizModelInstance;
import CollavizInstance.CollavizObjectInstance;
import CollavizInstance.DependencyInstance;
import CollavizInstance.Position10;
import CollavizInstance.Position6;
import CollavizInstance.Position9;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizInstanceFactoryImpl extends EFactoryImpl implements CollavizInstanceFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CollavizInstanceFactory init() {
		try {
			CollavizInstanceFactory theCollavizInstanceFactory = (CollavizInstanceFactory)EPackage.Registry.INSTANCE.getEFactory("http://CollavizInstance"); 
			if (theCollavizInstanceFactory != null) {
				return theCollavizInstanceFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CollavizInstanceFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstanceFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case CollavizInstancePackage.COLLAVIZ_MODEL_INSTANCE: return createCollavizModelInstance();
			case CollavizInstancePackage.COLLAVIZ_OBJECT_INSTANCE: return createCollavizObjectInstance();
			case CollavizInstancePackage.DEPENDENCY_INSTANCE: return createDependencyInstance();
			case CollavizInstancePackage.ATTRIBUTE_INSTANCE: return createAttributeInstance();
			case CollavizInstancePackage.POSITION6: return createPosition6();
			case CollavizInstancePackage.POSITION9: return createPosition9();
			case CollavizInstancePackage.POSITION10: return createPosition10();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case CollavizInstancePackage.OWNERS_VALUE:
				return createOwnersValueFromString(eDataType, initialValue);
			case CollavizInstancePackage.FILE_TYPE:
				return createFileTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case CollavizInstancePackage.OWNERS_VALUE:
				return convertOwnersValueToString(eDataType, instanceValue);
			case CollavizInstancePackage.FILE_TYPE:
				return convertFileTypeToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizModelInstance createCollavizModelInstance() {
		CollavizModelInstanceImpl collavizModelInstance = new CollavizModelInstanceImpl();
		return collavizModelInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObjectInstance createCollavizObjectInstance() {
		CollavizObjectInstanceImpl collavizObjectInstance = new CollavizObjectInstanceImpl();
		return collavizObjectInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DependencyInstance createDependencyInstance() {
		DependencyInstanceImpl dependencyInstance = new DependencyInstanceImpl();
		return dependencyInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeInstance createAttributeInstance() {
		AttributeInstanceImpl attributeInstance = new AttributeInstanceImpl();
		return attributeInstance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Position6 createPosition6() {
		Position6Impl position6 = new Position6Impl();
		return position6;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Position9 createPosition9() {
		Position9Impl position9 = new Position9Impl();
		return position9;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Position10 createPosition10() {
		Position10Impl position10 = new Position10Impl();
		return position10;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OwnersValue createOwnersValueFromString(EDataType eDataType, String initialValue) {
		OwnersValue result = OwnersValue.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOwnersValueToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FileType createFileTypeFromString(EDataType eDataType, String initialValue) {
		FileType result = FileType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertFileTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizInstancePackage getCollavizInstancePackage() {
		return (CollavizInstancePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CollavizInstancePackage getPackage() {
		return CollavizInstancePackage.eINSTANCE;
	}

} //CollavizInstanceFactoryImpl
