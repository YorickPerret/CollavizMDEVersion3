/**
 */
package CollavizInstance;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstancePackage
 * @generated
 */
public interface CollavizInstanceFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CollavizInstanceFactory eINSTANCE = CollavizInstance.impl.CollavizInstanceFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Collaviz Model Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Collaviz Model Instance</em>'.
	 * @generated
	 */
	CollavizModelInstance createCollavizModelInstance();

	/**
	 * Returns a new object of class '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Collaviz Object Instance</em>'.
	 * @generated
	 */
	CollavizObjectInstance createCollavizObjectInstance();

	/**
	 * Returns a new object of class '<em>Dependency Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dependency Instance</em>'.
	 * @generated
	 */
	DependencyInstance createDependencyInstance();

	/**
	 * Returns a new object of class '<em>Attribute Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attribute Instance</em>'.
	 * @generated
	 */
	AttributeInstance createAttributeInstance();

	/**
	 * Returns a new object of class '<em>Transform Euler Angles</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transform Euler Angles</em>'.
	 * @generated
	 */
	TransformEulerAngles createTransformEulerAngles();

	/**
	 * Returns a new object of class '<em>Transform Euler Angles Scale</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transform Euler Angles Scale</em>'.
	 * @generated
	 */
	TransformEulerAnglesScale createTransformEulerAnglesScale();

	/**
	 * Returns a new object of class '<em>Transform Quaternion Scale</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transform Quaternion Scale</em>'.
	 * @generated
	 */
	TransformQuaternionScale createTransformQuaternionScale();

	/**
	 * Returns a new object of class '<em>Color</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Color</em>'.
	 * @generated
	 */
	Color createColor();

	/**
	 * Returns a new object of class '<em>Integer Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Integer Instance</em>'.
	 * @generated
	 */
	IntegerInstance createIntegerInstance();

	/**
	 * Returns a new object of class '<em>Double Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Double Instance</em>'.
	 * @generated
	 */
	DoubleInstance createDoubleInstance();

	/**
	 * Returns a new object of class '<em>Boolean Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Boolean Instance</em>'.
	 * @generated
	 */
	BooleanInstance createBooleanInstance();

	/**
	 * Returns a new object of class '<em>Short Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Short Instance</em>'.
	 * @generated
	 */
	ShortInstance createShortInstance();

	/**
	 * Returns a new object of class '<em>String Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>String Instance</em>'.
	 * @generated
	 */
	StringInstance createStringInstance();

	/**
	 * Returns a new object of class '<em>Long Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Long Instance</em>'.
	 * @generated
	 */
	LongInstance createLongInstance();

	/**
	 * Returns a new object of class '<em>Float Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Float Instance</em>'.
	 * @generated
	 */
	FloatInstance createFloatInstance();

	/**
	 * Returns a new object of class '<em>Char Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Char Instance</em>'.
	 * @generated
	 */
	CharInstance createCharInstance();

	/**
	 * Returns a new object of class '<em>Collection Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Collection Instance</em>'.
	 * @generated
	 */
	CollectionInstance createCollectionInstance();

	/**
	 * Returns a new object of class '<em>Tree Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tree Instance</em>'.
	 * @generated
	 */
	TreeInstance createTreeInstance();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	CollavizInstancePackage getCollavizInstancePackage();

} //CollavizInstanceFactory
