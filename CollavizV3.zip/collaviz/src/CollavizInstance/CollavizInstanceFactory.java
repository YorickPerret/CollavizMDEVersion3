/**
 */
package CollavizInstance;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstancePackage
 * @generated
 */
public interface CollavizInstanceFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CollavizInstanceFactory eINSTANCE = CollavizInstance.impl.CollavizInstanceFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Collaviz Model Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Collaviz Model Instance</em>'.
	 * @generated
	 */
	CollavizModelInstance createCollavizModelInstance();

	/**
	 * Returns a new object of class '<em>Collaviz Object Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Collaviz Object Instance</em>'.
	 * @generated
	 */
	CollavizObjectInstance createCollavizObjectInstance();

	/**
	 * Returns a new object of class '<em>Dependency Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dependency Instance</em>'.
	 * @generated
	 */
	DependencyInstance createDependencyInstance();

	/**
	 * Returns a new object of class '<em>Attribute Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attribute Instance</em>'.
	 * @generated
	 */
	AttributeInstance createAttributeInstance();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	CollavizInstancePackage getCollavizInstancePackage();

} //CollavizInstanceFactory
