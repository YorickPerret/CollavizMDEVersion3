/**
 */
package CollavizInstance;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Position</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.Position#getName <em>Name</em>}</li>
 *   <li>{@link CollavizInstance.Position#getValue <em>Value</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getPosition()
 * @model abstract="true"
 * @generated
 */
public interface Position extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * The default value is <code>"position"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see CollavizInstance.CollavizInstancePackage#getPosition_Name()
	 * @model default="position" id="true" dataType="Collaviz.String" changeable="false"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL derivation='if self.getParent().support.oclIsUndefined() then\r\n\t\'position\'\r\nelse\r\n\t\'offset\'\r\nendif'"
	 * @generated
	 */
	String getName();

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * The default value is <code>"0 0 0 0 0 0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(String)
	 * @see CollavizInstance.CollavizInstancePackage#getPosition_Value()
	 * @model default="0 0 0 0 0 0" dataType="Collaviz.String" required="true"
	 * @generated
	 */
	String getValue();

	/**
	 * Sets the value of the '{@link CollavizInstance.Position#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation" required="true"
	 * @generated
	 */
	CollavizObjectInstance getParent();

} // Position
