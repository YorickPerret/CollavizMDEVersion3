/**
 */
package CollavizInstance;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstanceFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL'"
 * @generated
 */
public interface CollavizInstancePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "CollavizInstance";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://CollavizInstance";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "CollavizInstance";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CollavizInstancePackage eINSTANCE = CollavizInstance.impl.CollavizInstancePackageImpl.init();

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CollavizModelInstanceImpl <em>Collaviz Model Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CollavizModelInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizModelInstance()
	 * @generated
	 */
	int COLLAVIZ_MODEL_INSTANCE = 0;

	/**
	 * The feature id for the '<em><b>Object Instances</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE__NAME = 1;

	/**
	 * The feature id for the '<em><b>File Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE__FILE_TYPE = 2;

	/**
	 * The number of structural features of the '<em>Collaviz Model Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CollavizObjectInstanceImpl <em>Collaviz Object Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CollavizObjectInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizObjectInstance()
	 * @generated
	 */
	int COLLAVIZ_OBJECT_INSTANCE = 1;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES = 1;

	/**
	 * The feature id for the '<em><b>Dependencies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__NAME = 3;

	/**
	 * The feature id for the '<em><b>Support</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__SUPPORT = 4;

	/**
	 * The feature id for the '<em><b>Supported</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__SUPPORTED = 5;

	/**
	 * The feature id for the '<em><b>Position</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__POSITION = 6;

	/**
	 * The feature id for the '<em><b>Owners</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__OWNERS = 7;

	/**
	 * The feature id for the '<em><b>Access Level</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__ACCESS_LEVEL = 8;

	/**
	 * The feature id for the '<em><b>Ref Proxy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__REF_PROXY = 9;

	/**
	 * The feature id for the '<em><b>Become Referent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__BECOME_REFERENT = 10;

	/**
	 * The feature id for the '<em><b>Become Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__BECOME_OWNER = 11;

	/**
	 * The feature id for the '<em><b>Color</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__COLOR = 12;

	/**
	 * The number of structural features of the '<em>Collaviz Object Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE_FEATURE_COUNT = 13;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.DependencyInstanceImpl <em>Dependency Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.DependencyInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDependencyInstance()
	 * @generated
	 */
	int DEPENDENCY_INSTANCE = 2;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Dependency Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.AttributeInstanceImpl <em>Attribute Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.AttributeInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getAttributeInstance()
	 * @generated
	 */
	int ATTRIBUTE_INSTANCE = 3;

	/**
	 * The feature id for the '<em><b>Value</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__INSTANCE_OF = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Attribute Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.ValueImpl <em>Value</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.ValueImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getValue()
	 * @generated
	 */
	int VALUE = 19;

	/**
	 * The number of structural features of the '<em>Value</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_FEATURE_COUNT = 0;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.TransformImpl <em>Transform</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.TransformImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransform()
	 * @generated
	 */
	int TRANSFORM = 4;

	/**
	 * The feature id for the '<em><b>Is Relative</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM__IS_RELATIVE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM__X = VALUE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM__Y = VALUE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Z</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM__Z = VALUE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Transform</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_FEATURE_COUNT = VALUE_FEATURE_COUNT + 4;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.TransformEulerAnglesImpl <em>Transform Euler Angles</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.TransformEulerAnglesImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransformEulerAngles()
	 * @generated
	 */
	int TRANSFORM_EULER_ANGLES = 5;

	/**
	 * The feature id for the '<em><b>Is Relative</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES__IS_RELATIVE = TRANSFORM__IS_RELATIVE;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES__X = TRANSFORM__X;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES__Y = TRANSFORM__Y;

	/**
	 * The feature id for the '<em><b>Z</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES__Z = TRANSFORM__Z;

	/**
	 * The feature id for the '<em><b>H</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES__H = TRANSFORM_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>P</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES__P = TRANSFORM_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>R</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES__R = TRANSFORM_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Transform Euler Angles</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_FEATURE_COUNT = TRANSFORM_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl <em>Transform Euler Angles Scale</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.TransformEulerAnglesScaleImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransformEulerAnglesScale()
	 * @generated
	 */
	int TRANSFORM_EULER_ANGLES_SCALE = 6;

	/**
	 * The feature id for the '<em><b>Is Relative</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__IS_RELATIVE = TRANSFORM__IS_RELATIVE;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__X = TRANSFORM__X;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__Y = TRANSFORM__Y;

	/**
	 * The feature id for the '<em><b>Z</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__Z = TRANSFORM__Z;

	/**
	 * The feature id for the '<em><b>H</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__H = TRANSFORM_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>P</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__P = TRANSFORM_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>R</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__R = TRANSFORM_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Sx</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__SX = TRANSFORM_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Sy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__SY = TRANSFORM_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Sz</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE__SZ = TRANSFORM_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Transform Euler Angles Scale</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_EULER_ANGLES_SCALE_FEATURE_COUNT = TRANSFORM_FEATURE_COUNT + 6;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.TransformQuaternionScaleImpl <em>Transform Quaternion Scale</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.TransformQuaternionScaleImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransformQuaternionScale()
	 * @generated
	 */
	int TRANSFORM_QUATERNION_SCALE = 7;

	/**
	 * The feature id for the '<em><b>Is Relative</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__IS_RELATIVE = TRANSFORM__IS_RELATIVE;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__X = TRANSFORM__X;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__Y = TRANSFORM__Y;

	/**
	 * The feature id for the '<em><b>Z</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__Z = TRANSFORM__Z;

	/**
	 * The feature id for the '<em><b>Qx</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__QX = TRANSFORM_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Qy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__QY = TRANSFORM_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Qz</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__QZ = TRANSFORM_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Qw</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__QW = TRANSFORM_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Sx</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__SX = TRANSFORM_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Sy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__SY = TRANSFORM_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Sz</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE__SZ = TRANSFORM_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the '<em>Transform Quaternion Scale</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFORM_QUATERNION_SCALE_FEATURE_COUNT = TRANSFORM_FEATURE_COUNT + 7;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.ColorImpl <em>Color</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.ColorImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getColor()
	 * @generated
	 */
	int COLOR = 8;

	/**
	 * The feature id for the '<em><b>R</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR__R = VALUE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>G</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR__G = VALUE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>B</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR__B = VALUE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>A</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR__A = VALUE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Color</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR_FEATURE_COUNT = VALUE_FEATURE_COUNT + 4;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.IntegerInstanceImpl <em>Integer Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.IntegerInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getIntegerInstance()
	 * @generated
	 */
	int INTEGER_INSTANCE = 9;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTEGER_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Integer Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTEGER_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.DoubleInstanceImpl <em>Double Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.DoubleInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDoubleInstance()
	 * @generated
	 */
	int DOUBLE_INSTANCE = 10;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOUBLE_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Double Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOUBLE_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.BooleanInstanceImpl <em>Boolean Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.BooleanInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getBooleanInstance()
	 * @generated
	 */
	int BOOLEAN_INSTANCE = 11;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOLEAN_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Boolean Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOLEAN_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.ShortInstanceImpl <em>Short Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.ShortInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getShortInstance()
	 * @generated
	 */
	int SHORT_INSTANCE = 12;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHORT_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Short Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHORT_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.StringInstanceImpl <em>String Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.StringInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getStringInstance()
	 * @generated
	 */
	int STRING_INSTANCE = 13;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>String Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.LongInstanceImpl <em>Long Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.LongInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getLongInstance()
	 * @generated
	 */
	int LONG_INSTANCE = 14;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LONG_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Long Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LONG_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.FloatInstanceImpl <em>Float Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.FloatInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getFloatInstance()
	 * @generated
	 */
	int FLOAT_INSTANCE = 15;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOAT_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Float Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FLOAT_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CharInstanceImpl <em>Char Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CharInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCharInstance()
	 * @generated
	 */
	int CHAR_INSTANCE = 16;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHAR_INSTANCE__VALUE = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Char Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHAR_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CollectionInstanceImpl <em>Collection Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CollectionInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollectionInstance()
	 * @generated
	 */
	int COLLECTION_INSTANCE = 17;

	/**
	 * The feature id for the '<em><b>Values</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLECTION_INSTANCE__VALUES = VALUE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Collection Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLECTION_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.TreeInstanceImpl <em>Tree Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.TreeInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTreeInstance()
	 * @generated
	 */
	int TREE_INSTANCE = 18;

	/**
	 * The feature id for the '<em><b>Values</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREE_INSTANCE__VALUES = VALUE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREE_INSTANCE__NAME = VALUE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Tree Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREE_INSTANCE_FEATURE_COUNT = VALUE_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link CollavizInstance.OwnersValue <em>Owners Value</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.OwnersValue
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getOwnersValue()
	 * @generated
	 */
	int OWNERS_VALUE = 20;

	/**
	 * The meta object id for the '{@link CollavizInstance.FileType <em>File Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.FileType
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getFileType()
	 * @generated
	 */
	int FILE_TYPE = 21;

	/**
	 * Returns the meta object for class '{@link CollavizInstance.CollavizModelInstance <em>Collaviz Model Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collaviz Model Instance</em>'.
	 * @see CollavizInstance.CollavizModelInstance
	 * @generated
	 */
	EClass getCollavizModelInstance();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizModelInstance#getObjectInstances <em>Object Instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Object Instances</em>'.
	 * @see CollavizInstance.CollavizModelInstance#getObjectInstances()
	 * @see #getCollavizModelInstance()
	 * @generated
	 */
	EReference getCollavizModelInstance_ObjectInstances();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizModelInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.CollavizModelInstance#getName()
	 * @see #getCollavizModelInstance()
	 * @generated
	 */
	EAttribute getCollavizModelInstance_Name();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizModelInstance#getFileType <em>File Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Type</em>'.
	 * @see CollavizInstance.CollavizModelInstance#getFileType()
	 * @see #getCollavizModelInstance()
	 * @generated
	 */
	EAttribute getCollavizModelInstance_FileType();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.CollavizObjectInstance <em>Collaviz Object Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collaviz Object Instance</em>'.
	 * @see CollavizInstance.CollavizObjectInstance
	 * @generated
	 */
	EClass getCollavizObjectInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.CollavizObjectInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getInstanceOf()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_InstanceOf();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizObjectInstance#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getAttributes()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Attributes();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizObjectInstance#getDependencies <em>Dependencies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependencies</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getDependencies()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Dependencies();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getName()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_Name();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.CollavizObjectInstance#getSupport <em>Support</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Support</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getSupport()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Support();

	/**
	 * Returns the meta object for the reference list '{@link CollavizInstance.CollavizObjectInstance#getSupported <em>Supported</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Supported</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getSupported()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Supported();

	/**
	 * Returns the meta object for the containment reference '{@link CollavizInstance.CollavizObjectInstance#getPosition <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Position</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getPosition()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Position();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getOwners <em>Owners</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Owners</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getOwners()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_Owners();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getAccessLevel <em>Access Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Access Level</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getAccessLevel()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_AccessLevel();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getRefProxy <em>Ref Proxy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ref Proxy</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getRefProxy()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_RefProxy();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getBecomeReferent <em>Become Referent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Become Referent</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getBecomeReferent()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_BecomeReferent();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getBecomeOwner <em>Become Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Become Owner</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getBecomeOwner()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_BecomeOwner();

	/**
	 * Returns the meta object for the containment reference '{@link CollavizInstance.CollavizObjectInstance#getColor <em>Color</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Color</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getColor()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Color();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.DependencyInstance <em>Dependency Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dependency Instance</em>'.
	 * @see CollavizInstance.DependencyInstance
	 * @generated
	 */
	EClass getDependencyInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.DependencyInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.DependencyInstance#getInstanceOf()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EReference getDependencyInstance_InstanceOf();

	/**
	 * Returns the meta object for the reference list '{@link CollavizInstance.DependencyInstance#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Target</em>'.
	 * @see CollavizInstance.DependencyInstance#getTarget()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EReference getDependencyInstance_Target();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.DependencyInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.DependencyInstance#getName()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EAttribute getDependencyInstance_Name();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.AttributeInstance <em>Attribute Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute Instance</em>'.
	 * @see CollavizInstance.AttributeInstance
	 * @generated
	 */
	EClass getAttributeInstance();

	/**
	 * Returns the meta object for the containment reference '{@link CollavizInstance.AttributeInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Value</em>'.
	 * @see CollavizInstance.AttributeInstance#getValue()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EReference getAttributeInstance_Value();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.AttributeInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.AttributeInstance#getInstanceOf()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EReference getAttributeInstance_InstanceOf();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.AttributeInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.AttributeInstance#getName()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EAttribute getAttributeInstance_Name();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.Transform <em>Transform</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transform</em>'.
	 * @see CollavizInstance.Transform
	 * @generated
	 */
	EClass getTransform();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Transform#getIsRelative <em>Is Relative</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Relative</em>'.
	 * @see CollavizInstance.Transform#getIsRelative()
	 * @see #getTransform()
	 * @generated
	 */
	EAttribute getTransform_IsRelative();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Transform#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see CollavizInstance.Transform#getX()
	 * @see #getTransform()
	 * @generated
	 */
	EAttribute getTransform_X();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Transform#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see CollavizInstance.Transform#getY()
	 * @see #getTransform()
	 * @generated
	 */
	EAttribute getTransform_Y();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Transform#getZ <em>Z</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Z</em>'.
	 * @see CollavizInstance.Transform#getZ()
	 * @see #getTransform()
	 * @generated
	 */
	EAttribute getTransform_Z();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.TransformEulerAngles <em>Transform Euler Angles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transform Euler Angles</em>'.
	 * @see CollavizInstance.TransformEulerAngles
	 * @generated
	 */
	EClass getTransformEulerAngles();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAngles#getH <em>H</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>H</em>'.
	 * @see CollavizInstance.TransformEulerAngles#getH()
	 * @see #getTransformEulerAngles()
	 * @generated
	 */
	EAttribute getTransformEulerAngles_H();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAngles#getP <em>P</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>P</em>'.
	 * @see CollavizInstance.TransformEulerAngles#getP()
	 * @see #getTransformEulerAngles()
	 * @generated
	 */
	EAttribute getTransformEulerAngles_P();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAngles#getR <em>R</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>R</em>'.
	 * @see CollavizInstance.TransformEulerAngles#getR()
	 * @see #getTransformEulerAngles()
	 * @generated
	 */
	EAttribute getTransformEulerAngles_R();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.TransformEulerAnglesScale <em>Transform Euler Angles Scale</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transform Euler Angles Scale</em>'.
	 * @see CollavizInstance.TransformEulerAnglesScale
	 * @generated
	 */
	EClass getTransformEulerAnglesScale();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAnglesScale#getH <em>H</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>H</em>'.
	 * @see CollavizInstance.TransformEulerAnglesScale#getH()
	 * @see #getTransformEulerAnglesScale()
	 * @generated
	 */
	EAttribute getTransformEulerAnglesScale_H();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAnglesScale#getP <em>P</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>P</em>'.
	 * @see CollavizInstance.TransformEulerAnglesScale#getP()
	 * @see #getTransformEulerAnglesScale()
	 * @generated
	 */
	EAttribute getTransformEulerAnglesScale_P();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAnglesScale#getR <em>R</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>R</em>'.
	 * @see CollavizInstance.TransformEulerAnglesScale#getR()
	 * @see #getTransformEulerAnglesScale()
	 * @generated
	 */
	EAttribute getTransformEulerAnglesScale_R();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAnglesScale#getSx <em>Sx</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sx</em>'.
	 * @see CollavizInstance.TransformEulerAnglesScale#getSx()
	 * @see #getTransformEulerAnglesScale()
	 * @generated
	 */
	EAttribute getTransformEulerAnglesScale_Sx();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAnglesScale#getSy <em>Sy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sy</em>'.
	 * @see CollavizInstance.TransformEulerAnglesScale#getSy()
	 * @see #getTransformEulerAnglesScale()
	 * @generated
	 */
	EAttribute getTransformEulerAnglesScale_Sy();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformEulerAnglesScale#getSz <em>Sz</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sz</em>'.
	 * @see CollavizInstance.TransformEulerAnglesScale#getSz()
	 * @see #getTransformEulerAnglesScale()
	 * @generated
	 */
	EAttribute getTransformEulerAnglesScale_Sz();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.TransformQuaternionScale <em>Transform Quaternion Scale</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transform Quaternion Scale</em>'.
	 * @see CollavizInstance.TransformQuaternionScale
	 * @generated
	 */
	EClass getTransformQuaternionScale();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformQuaternionScale#getQx <em>Qx</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Qx</em>'.
	 * @see CollavizInstance.TransformQuaternionScale#getQx()
	 * @see #getTransformQuaternionScale()
	 * @generated
	 */
	EAttribute getTransformQuaternionScale_Qx();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformQuaternionScale#getQy <em>Qy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Qy</em>'.
	 * @see CollavizInstance.TransformQuaternionScale#getQy()
	 * @see #getTransformQuaternionScale()
	 * @generated
	 */
	EAttribute getTransformQuaternionScale_Qy();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformQuaternionScale#getQz <em>Qz</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Qz</em>'.
	 * @see CollavizInstance.TransformQuaternionScale#getQz()
	 * @see #getTransformQuaternionScale()
	 * @generated
	 */
	EAttribute getTransformQuaternionScale_Qz();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformQuaternionScale#getQw <em>Qw</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Qw</em>'.
	 * @see CollavizInstance.TransformQuaternionScale#getQw()
	 * @see #getTransformQuaternionScale()
	 * @generated
	 */
	EAttribute getTransformQuaternionScale_Qw();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformQuaternionScale#getSx <em>Sx</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sx</em>'.
	 * @see CollavizInstance.TransformQuaternionScale#getSx()
	 * @see #getTransformQuaternionScale()
	 * @generated
	 */
	EAttribute getTransformQuaternionScale_Sx();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformQuaternionScale#getSy <em>Sy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sy</em>'.
	 * @see CollavizInstance.TransformQuaternionScale#getSy()
	 * @see #getTransformQuaternionScale()
	 * @generated
	 */
	EAttribute getTransformQuaternionScale_Sy();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TransformQuaternionScale#getSz <em>Sz</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sz</em>'.
	 * @see CollavizInstance.TransformQuaternionScale#getSz()
	 * @see #getTransformQuaternionScale()
	 * @generated
	 */
	EAttribute getTransformQuaternionScale_Sz();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.Color <em>Color</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Color</em>'.
	 * @see CollavizInstance.Color
	 * @generated
	 */
	EClass getColor();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Color#getR <em>R</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>R</em>'.
	 * @see CollavizInstance.Color#getR()
	 * @see #getColor()
	 * @generated
	 */
	EAttribute getColor_R();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Color#getG <em>G</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>G</em>'.
	 * @see CollavizInstance.Color#getG()
	 * @see #getColor()
	 * @generated
	 */
	EAttribute getColor_G();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Color#getB <em>B</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>B</em>'.
	 * @see CollavizInstance.Color#getB()
	 * @see #getColor()
	 * @generated
	 */
	EAttribute getColor_B();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Color#getA <em>A</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>A</em>'.
	 * @see CollavizInstance.Color#getA()
	 * @see #getColor()
	 * @generated
	 */
	EAttribute getColor_A();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.IntegerInstance <em>Integer Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Integer Instance</em>'.
	 * @see CollavizInstance.IntegerInstance
	 * @generated
	 */
	EClass getIntegerInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.IntegerInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.IntegerInstance#getValue()
	 * @see #getIntegerInstance()
	 * @generated
	 */
	EAttribute getIntegerInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.DoubleInstance <em>Double Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Double Instance</em>'.
	 * @see CollavizInstance.DoubleInstance
	 * @generated
	 */
	EClass getDoubleInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.DoubleInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.DoubleInstance#getValue()
	 * @see #getDoubleInstance()
	 * @generated
	 */
	EAttribute getDoubleInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.BooleanInstance <em>Boolean Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Boolean Instance</em>'.
	 * @see CollavizInstance.BooleanInstance
	 * @generated
	 */
	EClass getBooleanInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.BooleanInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.BooleanInstance#getValue()
	 * @see #getBooleanInstance()
	 * @generated
	 */
	EAttribute getBooleanInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.ShortInstance <em>Short Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Short Instance</em>'.
	 * @see CollavizInstance.ShortInstance
	 * @generated
	 */
	EClass getShortInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.ShortInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.ShortInstance#getValue()
	 * @see #getShortInstance()
	 * @generated
	 */
	EAttribute getShortInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.StringInstance <em>String Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String Instance</em>'.
	 * @see CollavizInstance.StringInstance
	 * @generated
	 */
	EClass getStringInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.StringInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.StringInstance#getValue()
	 * @see #getStringInstance()
	 * @generated
	 */
	EAttribute getStringInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.LongInstance <em>Long Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Long Instance</em>'.
	 * @see CollavizInstance.LongInstance
	 * @generated
	 */
	EClass getLongInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.LongInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.LongInstance#getValue()
	 * @see #getLongInstance()
	 * @generated
	 */
	EAttribute getLongInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.FloatInstance <em>Float Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Float Instance</em>'.
	 * @see CollavizInstance.FloatInstance
	 * @generated
	 */
	EClass getFloatInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.FloatInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.FloatInstance#getValue()
	 * @see #getFloatInstance()
	 * @generated
	 */
	EAttribute getFloatInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.CharInstance <em>Char Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Char Instance</em>'.
	 * @see CollavizInstance.CharInstance
	 * @generated
	 */
	EClass getCharInstance();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CharInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.CharInstance#getValue()
	 * @see #getCharInstance()
	 * @generated
	 */
	EAttribute getCharInstance_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.CollectionInstance <em>Collection Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collection Instance</em>'.
	 * @see CollavizInstance.CollectionInstance
	 * @generated
	 */
	EClass getCollectionInstance();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollectionInstance#getValues <em>Values</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Values</em>'.
	 * @see CollavizInstance.CollectionInstance#getValues()
	 * @see #getCollectionInstance()
	 * @generated
	 */
	EReference getCollectionInstance_Values();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.TreeInstance <em>Tree Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tree Instance</em>'.
	 * @see CollavizInstance.TreeInstance
	 * @generated
	 */
	EClass getTreeInstance();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.TreeInstance#getValues <em>Values</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Values</em>'.
	 * @see CollavizInstance.TreeInstance#getValues()
	 * @see #getTreeInstance()
	 * @generated
	 */
	EReference getTreeInstance_Values();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.TreeInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.TreeInstance#getName()
	 * @see #getTreeInstance()
	 * @generated
	 */
	EAttribute getTreeInstance_Name();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.Value <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Value</em>'.
	 * @see CollavizInstance.Value
	 * @generated
	 */
	EClass getValue();

	/**
	 * Returns the meta object for enum '{@link CollavizInstance.OwnersValue <em>Owners Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Owners Value</em>'.
	 * @see CollavizInstance.OwnersValue
	 * @generated
	 */
	EEnum getOwnersValue();

	/**
	 * Returns the meta object for enum '{@link CollavizInstance.FileType <em>File Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>File Type</em>'.
	 * @see CollavizInstance.FileType
	 * @generated
	 */
	EEnum getFileType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CollavizInstanceFactory getCollavizInstanceFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CollavizModelInstanceImpl <em>Collaviz Model Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CollavizModelInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizModelInstance()
		 * @generated
		 */
		EClass COLLAVIZ_MODEL_INSTANCE = eINSTANCE.getCollavizModelInstance();

		/**
		 * The meta object literal for the '<em><b>Object Instances</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES = eINSTANCE.getCollavizModelInstance_ObjectInstances();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_MODEL_INSTANCE__NAME = eINSTANCE.getCollavizModelInstance_Name();

		/**
		 * The meta object literal for the '<em><b>File Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_MODEL_INSTANCE__FILE_TYPE = eINSTANCE.getCollavizModelInstance_FileType();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CollavizObjectInstanceImpl <em>Collaviz Object Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CollavizObjectInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizObjectInstance()
		 * @generated
		 */
		EClass COLLAVIZ_OBJECT_INSTANCE = eINSTANCE.getCollavizObjectInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF = eINSTANCE.getCollavizObjectInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES = eINSTANCE.getCollavizObjectInstance_Attributes();

		/**
		 * The meta object literal for the '<em><b>Dependencies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES = eINSTANCE.getCollavizObjectInstance_Dependencies();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__NAME = eINSTANCE.getCollavizObjectInstance_Name();

		/**
		 * The meta object literal for the '<em><b>Support</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__SUPPORT = eINSTANCE.getCollavizObjectInstance_Support();

		/**
		 * The meta object literal for the '<em><b>Supported</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__SUPPORTED = eINSTANCE.getCollavizObjectInstance_Supported();

		/**
		 * The meta object literal for the '<em><b>Position</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__POSITION = eINSTANCE.getCollavizObjectInstance_Position();

		/**
		 * The meta object literal for the '<em><b>Owners</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__OWNERS = eINSTANCE.getCollavizObjectInstance_Owners();

		/**
		 * The meta object literal for the '<em><b>Access Level</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__ACCESS_LEVEL = eINSTANCE.getCollavizObjectInstance_AccessLevel();

		/**
		 * The meta object literal for the '<em><b>Ref Proxy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__REF_PROXY = eINSTANCE.getCollavizObjectInstance_RefProxy();

		/**
		 * The meta object literal for the '<em><b>Become Referent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__BECOME_REFERENT = eINSTANCE.getCollavizObjectInstance_BecomeReferent();

		/**
		 * The meta object literal for the '<em><b>Become Owner</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__BECOME_OWNER = eINSTANCE.getCollavizObjectInstance_BecomeOwner();

		/**
		 * The meta object literal for the '<em><b>Color</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__COLOR = eINSTANCE.getCollavizObjectInstance_Color();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.DependencyInstanceImpl <em>Dependency Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.DependencyInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDependencyInstance()
		 * @generated
		 */
		EClass DEPENDENCY_INSTANCE = eINSTANCE.getDependencyInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY_INSTANCE__INSTANCE_OF = eINSTANCE.getDependencyInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY_INSTANCE__TARGET = eINSTANCE.getDependencyInstance_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPENDENCY_INSTANCE__NAME = eINSTANCE.getDependencyInstance_Name();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.AttributeInstanceImpl <em>Attribute Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.AttributeInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getAttributeInstance()
		 * @generated
		 */
		EClass ATTRIBUTE_INSTANCE = eINSTANCE.getAttributeInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRIBUTE_INSTANCE__VALUE = eINSTANCE.getAttributeInstance_Value();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRIBUTE_INSTANCE__INSTANCE_OF = eINSTANCE.getAttributeInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE_INSTANCE__NAME = eINSTANCE.getAttributeInstance_Name();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.TransformImpl <em>Transform</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.TransformImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransform()
		 * @generated
		 */
		EClass TRANSFORM = eINSTANCE.getTransform();

		/**
		 * The meta object literal for the '<em><b>Is Relative</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM__IS_RELATIVE = eINSTANCE.getTransform_IsRelative();

		/**
		 * The meta object literal for the '<em><b>X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM__X = eINSTANCE.getTransform_X();

		/**
		 * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM__Y = eINSTANCE.getTransform_Y();

		/**
		 * The meta object literal for the '<em><b>Z</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM__Z = eINSTANCE.getTransform_Z();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.TransformEulerAnglesImpl <em>Transform Euler Angles</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.TransformEulerAnglesImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransformEulerAngles()
		 * @generated
		 */
		EClass TRANSFORM_EULER_ANGLES = eINSTANCE.getTransformEulerAngles();

		/**
		 * The meta object literal for the '<em><b>H</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES__H = eINSTANCE.getTransformEulerAngles_H();

		/**
		 * The meta object literal for the '<em><b>P</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES__P = eINSTANCE.getTransformEulerAngles_P();

		/**
		 * The meta object literal for the '<em><b>R</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES__R = eINSTANCE.getTransformEulerAngles_R();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.TransformEulerAnglesScaleImpl <em>Transform Euler Angles Scale</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.TransformEulerAnglesScaleImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransformEulerAnglesScale()
		 * @generated
		 */
		EClass TRANSFORM_EULER_ANGLES_SCALE = eINSTANCE.getTransformEulerAnglesScale();

		/**
		 * The meta object literal for the '<em><b>H</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES_SCALE__H = eINSTANCE.getTransformEulerAnglesScale_H();

		/**
		 * The meta object literal for the '<em><b>P</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES_SCALE__P = eINSTANCE.getTransformEulerAnglesScale_P();

		/**
		 * The meta object literal for the '<em><b>R</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES_SCALE__R = eINSTANCE.getTransformEulerAnglesScale_R();

		/**
		 * The meta object literal for the '<em><b>Sx</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES_SCALE__SX = eINSTANCE.getTransformEulerAnglesScale_Sx();

		/**
		 * The meta object literal for the '<em><b>Sy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES_SCALE__SY = eINSTANCE.getTransformEulerAnglesScale_Sy();

		/**
		 * The meta object literal for the '<em><b>Sz</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_EULER_ANGLES_SCALE__SZ = eINSTANCE.getTransformEulerAnglesScale_Sz();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.TransformQuaternionScaleImpl <em>Transform Quaternion Scale</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.TransformQuaternionScaleImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTransformQuaternionScale()
		 * @generated
		 */
		EClass TRANSFORM_QUATERNION_SCALE = eINSTANCE.getTransformQuaternionScale();

		/**
		 * The meta object literal for the '<em><b>Qx</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_QUATERNION_SCALE__QX = eINSTANCE.getTransformQuaternionScale_Qx();

		/**
		 * The meta object literal for the '<em><b>Qy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_QUATERNION_SCALE__QY = eINSTANCE.getTransformQuaternionScale_Qy();

		/**
		 * The meta object literal for the '<em><b>Qz</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_QUATERNION_SCALE__QZ = eINSTANCE.getTransformQuaternionScale_Qz();

		/**
		 * The meta object literal for the '<em><b>Qw</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_QUATERNION_SCALE__QW = eINSTANCE.getTransformQuaternionScale_Qw();

		/**
		 * The meta object literal for the '<em><b>Sx</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_QUATERNION_SCALE__SX = eINSTANCE.getTransformQuaternionScale_Sx();

		/**
		 * The meta object literal for the '<em><b>Sy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_QUATERNION_SCALE__SY = eINSTANCE.getTransformQuaternionScale_Sy();

		/**
		 * The meta object literal for the '<em><b>Sz</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSFORM_QUATERNION_SCALE__SZ = eINSTANCE.getTransformQuaternionScale_Sz();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.ColorImpl <em>Color</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.ColorImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getColor()
		 * @generated
		 */
		EClass COLOR = eINSTANCE.getColor();

		/**
		 * The meta object literal for the '<em><b>R</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR__R = eINSTANCE.getColor_R();

		/**
		 * The meta object literal for the '<em><b>G</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR__G = eINSTANCE.getColor_G();

		/**
		 * The meta object literal for the '<em><b>B</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR__B = eINSTANCE.getColor_B();

		/**
		 * The meta object literal for the '<em><b>A</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR__A = eINSTANCE.getColor_A();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.IntegerInstanceImpl <em>Integer Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.IntegerInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getIntegerInstance()
		 * @generated
		 */
		EClass INTEGER_INSTANCE = eINSTANCE.getIntegerInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTEGER_INSTANCE__VALUE = eINSTANCE.getIntegerInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.DoubleInstanceImpl <em>Double Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.DoubleInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDoubleInstance()
		 * @generated
		 */
		EClass DOUBLE_INSTANCE = eINSTANCE.getDoubleInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOUBLE_INSTANCE__VALUE = eINSTANCE.getDoubleInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.BooleanInstanceImpl <em>Boolean Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.BooleanInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getBooleanInstance()
		 * @generated
		 */
		EClass BOOLEAN_INSTANCE = eINSTANCE.getBooleanInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BOOLEAN_INSTANCE__VALUE = eINSTANCE.getBooleanInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.ShortInstanceImpl <em>Short Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.ShortInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getShortInstance()
		 * @generated
		 */
		EClass SHORT_INSTANCE = eINSTANCE.getShortInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHORT_INSTANCE__VALUE = eINSTANCE.getShortInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.StringInstanceImpl <em>String Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.StringInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getStringInstance()
		 * @generated
		 */
		EClass STRING_INSTANCE = eINSTANCE.getStringInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STRING_INSTANCE__VALUE = eINSTANCE.getStringInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.LongInstanceImpl <em>Long Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.LongInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getLongInstance()
		 * @generated
		 */
		EClass LONG_INSTANCE = eINSTANCE.getLongInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LONG_INSTANCE__VALUE = eINSTANCE.getLongInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.FloatInstanceImpl <em>Float Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.FloatInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getFloatInstance()
		 * @generated
		 */
		EClass FLOAT_INSTANCE = eINSTANCE.getFloatInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FLOAT_INSTANCE__VALUE = eINSTANCE.getFloatInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CharInstanceImpl <em>Char Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CharInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCharInstance()
		 * @generated
		 */
		EClass CHAR_INSTANCE = eINSTANCE.getCharInstance();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHAR_INSTANCE__VALUE = eINSTANCE.getCharInstance_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CollectionInstanceImpl <em>Collection Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CollectionInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollectionInstance()
		 * @generated
		 */
		EClass COLLECTION_INSTANCE = eINSTANCE.getCollectionInstance();

		/**
		 * The meta object literal for the '<em><b>Values</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLECTION_INSTANCE__VALUES = eINSTANCE.getCollectionInstance_Values();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.TreeInstanceImpl <em>Tree Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.TreeInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getTreeInstance()
		 * @generated
		 */
		EClass TREE_INSTANCE = eINSTANCE.getTreeInstance();

		/**
		 * The meta object literal for the '<em><b>Values</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TREE_INSTANCE__VALUES = eINSTANCE.getTreeInstance_Values();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TREE_INSTANCE__NAME = eINSTANCE.getTreeInstance_Name();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.ValueImpl <em>Value</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.ValueImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getValue()
		 * @generated
		 */
		EClass VALUE = eINSTANCE.getValue();

		/**
		 * The meta object literal for the '{@link CollavizInstance.OwnersValue <em>Owners Value</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.OwnersValue
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getOwnersValue()
		 * @generated
		 */
		EEnum OWNERS_VALUE = eINSTANCE.getOwnersValue();

		/**
		 * The meta object literal for the '{@link CollavizInstance.FileType <em>File Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.FileType
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getFileType()
		 * @generated
		 */
		EEnum FILE_TYPE = eINSTANCE.getFileType();

	}

} //CollavizInstancePackage
