/**
 */
package CollavizInstance;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstanceFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL'"
 * @generated
 */
public interface CollavizInstancePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "CollavizInstance";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://CollavizInstance";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "CollavizInstance";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CollavizInstancePackage eINSTANCE = CollavizInstance.impl.CollavizInstancePackageImpl.init();

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CollavizModelInstanceImpl <em>Collaviz Model Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CollavizModelInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizModelInstance()
	 * @generated
	 */
	int COLLAVIZ_MODEL_INSTANCE = 0;

	/**
	 * The feature id for the '<em><b>Object Instances</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES = 0;

	/**
	 * The number of structural features of the '<em>Collaviz Model Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CollavizObjectInstanceImpl <em>Collaviz Object Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CollavizObjectInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizObjectInstance()
	 * @generated
	 */
	int COLLAVIZ_OBJECT_INSTANCE = 1;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES = 1;

	/**
	 * The feature id for the '<em><b>Dependencies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__NAME = 3;

	/**
	 * The number of structural features of the '<em>Collaviz Object Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.DependencyInstanceImpl <em>Dependency Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.DependencyInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDependencyInstance()
	 * @generated
	 */
	int DEPENDENCY_INSTANCE = 2;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Dependency Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.AttributeInstanceImpl <em>Attribute Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.AttributeInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getAttributeInstance()
	 * @generated
	 */
	int ATTRIBUTE_INSTANCE = 3;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__VALUE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Attribute Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '<em>String</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getString()
	 * @generated
	 */
	int STRING = 4;


	/**
	 * Returns the meta object for class '{@link CollavizInstance.CollavizModelInstance <em>Collaviz Model Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collaviz Model Instance</em>'.
	 * @see CollavizInstance.CollavizModelInstance
	 * @generated
	 */
	EClass getCollavizModelInstance();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizModelInstance#getObjectInstances <em>Object Instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Object Instances</em>'.
	 * @see CollavizInstance.CollavizModelInstance#getObjectInstances()
	 * @see #getCollavizModelInstance()
	 * @generated
	 */
	EReference getCollavizModelInstance_ObjectInstances();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.CollavizObjectInstance <em>Collaviz Object Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collaviz Object Instance</em>'.
	 * @see CollavizInstance.CollavizObjectInstance
	 * @generated
	 */
	EClass getCollavizObjectInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.CollavizObjectInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getInstanceOf()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_InstanceOf();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizObjectInstance#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getAttributes()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Attributes();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizObjectInstance#getDependencies <em>Dependencies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependencies</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getDependencies()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Dependencies();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getName()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_Name();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.DependencyInstance <em>Dependency Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dependency Instance</em>'.
	 * @see CollavizInstance.DependencyInstance
	 * @generated
	 */
	EClass getDependencyInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.DependencyInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.DependencyInstance#getInstanceOf()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EReference getDependencyInstance_InstanceOf();

	/**
	 * Returns the meta object for the reference list '{@link CollavizInstance.DependencyInstance#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Target</em>'.
	 * @see CollavizInstance.DependencyInstance#getTarget()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EReference getDependencyInstance_Target();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.DependencyInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.DependencyInstance#getName()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EAttribute getDependencyInstance_Name();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.AttributeInstance <em>Attribute Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute Instance</em>'.
	 * @see CollavizInstance.AttributeInstance
	 * @generated
	 */
	EClass getAttributeInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.AttributeInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.AttributeInstance#getInstanceOf()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EReference getAttributeInstance_InstanceOf();

	/**
	 * Returns the meta object for the attribute list '{@link CollavizInstance.AttributeInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Value</em>'.
	 * @see CollavizInstance.AttributeInstance#getValue()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EAttribute getAttributeInstance_Value();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.AttributeInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.AttributeInstance#getName()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EAttribute getAttributeInstance_Name();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>String</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>String</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 * @generated
	 */
	EDataType getString();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CollavizInstanceFactory getCollavizInstanceFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CollavizModelInstanceImpl <em>Collaviz Model Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CollavizModelInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizModelInstance()
		 * @generated
		 */
		EClass COLLAVIZ_MODEL_INSTANCE = eINSTANCE.getCollavizModelInstance();

		/**
		 * The meta object literal for the '<em><b>Object Instances</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES = eINSTANCE.getCollavizModelInstance_ObjectInstances();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CollavizObjectInstanceImpl <em>Collaviz Object Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CollavizObjectInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizObjectInstance()
		 * @generated
		 */
		EClass COLLAVIZ_OBJECT_INSTANCE = eINSTANCE.getCollavizObjectInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF = eINSTANCE.getCollavizObjectInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES = eINSTANCE.getCollavizObjectInstance_Attributes();

		/**
		 * The meta object literal for the '<em><b>Dependencies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES = eINSTANCE.getCollavizObjectInstance_Dependencies();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__NAME = eINSTANCE.getCollavizObjectInstance_Name();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.DependencyInstanceImpl <em>Dependency Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.DependencyInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDependencyInstance()
		 * @generated
		 */
		EClass DEPENDENCY_INSTANCE = eINSTANCE.getDependencyInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY_INSTANCE__INSTANCE_OF = eINSTANCE.getDependencyInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY_INSTANCE__TARGET = eINSTANCE.getDependencyInstance_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPENDENCY_INSTANCE__NAME = eINSTANCE.getDependencyInstance_Name();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.AttributeInstanceImpl <em>Attribute Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.AttributeInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getAttributeInstance()
		 * @generated
		 */
		EClass ATTRIBUTE_INSTANCE = eINSTANCE.getAttributeInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRIBUTE_INSTANCE__INSTANCE_OF = eINSTANCE.getAttributeInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE_INSTANCE__VALUE = eINSTANCE.getAttributeInstance_Value();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE_INSTANCE__NAME = eINSTANCE.getAttributeInstance_Name();

		/**
		 * The meta object literal for the '<em>String</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getString()
		 * @generated
		 */
		EDataType STRING = eINSTANCE.getString();

	}

} //CollavizInstancePackage
