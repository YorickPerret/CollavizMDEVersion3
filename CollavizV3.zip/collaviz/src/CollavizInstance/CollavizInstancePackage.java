/**
 */
package CollavizInstance;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see CollavizInstance.CollavizInstanceFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL'"
 * @generated
 */
public interface CollavizInstancePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "CollavizInstance";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://CollavizInstance";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "CollavizInstance";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CollavizInstancePackage eINSTANCE = CollavizInstance.impl.CollavizInstancePackageImpl.init();

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CollavizModelInstanceImpl <em>Collaviz Model Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CollavizModelInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizModelInstance()
	 * @generated
	 */
	int COLLAVIZ_MODEL_INSTANCE = 0;

	/**
	 * The feature id for the '<em><b>Object Instances</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE__NAME = 1;

	/**
	 * The feature id for the '<em><b>File Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE__FILE_TYPE = 2;

	/**
	 * The number of structural features of the '<em>Collaviz Model Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_MODEL_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.CollavizObjectInstanceImpl <em>Collaviz Object Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.CollavizObjectInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizObjectInstance()
	 * @generated
	 */
	int COLLAVIZ_OBJECT_INSTANCE = 1;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES = 1;

	/**
	 * The feature id for the '<em><b>Dependencies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__NAME = 3;

	/**
	 * The feature id for the '<em><b>Support</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__SUPPORT = 4;

	/**
	 * The feature id for the '<em><b>Supported</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__SUPPORTED = 5;

	/**
	 * The feature id for the '<em><b>Position</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__POSITION = 6;

	/**
	 * The feature id for the '<em><b>Owners</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__OWNERS = 7;

	/**
	 * The feature id for the '<em><b>Access Level</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__ACCESS_LEVEL = 8;

	/**
	 * The feature id for the '<em><b>Ref Proxy</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__REF_PROXY = 9;

	/**
	 * The feature id for the '<em><b>Become Referent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__BECOME_REFERENT = 10;

	/**
	 * The feature id for the '<em><b>Become Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE__BECOME_OWNER = 11;

	/**
	 * The number of structural features of the '<em>Collaviz Object Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLAVIZ_OBJECT_INSTANCE_FEATURE_COUNT = 12;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.DependencyInstanceImpl <em>Dependency Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.DependencyInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDependencyInstance()
	 * @generated
	 */
	int DEPENDENCY_INSTANCE = 2;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Dependency Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.AttributeInstanceImpl <em>Attribute Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.AttributeInstanceImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getAttributeInstance()
	 * @generated
	 */
	int ATTRIBUTE_INSTANCE = 3;

	/**
	 * The feature id for the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__INSTANCE_OF = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__VALUE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Attribute Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_INSTANCE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.PositionImpl <em>Position</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.PositionImpl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition()
	 * @generated
	 */
	int POSITION = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__VALUE = 1;

	/**
	 * The number of structural features of the '<em>Position</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.Position6Impl <em>Position6</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.Position6Impl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition6()
	 * @generated
	 */
	int POSITION6 = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION6__NAME = POSITION__NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION6__VALUE = POSITION__VALUE;

	/**
	 * The number of structural features of the '<em>Position6</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION6_FEATURE_COUNT = POSITION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.Position9Impl <em>Position9</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.Position9Impl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition9()
	 * @generated
	 */
	int POSITION9 = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION9__NAME = POSITION__NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION9__VALUE = POSITION__VALUE;

	/**
	 * The number of structural features of the '<em>Position9</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION9_FEATURE_COUNT = POSITION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link CollavizInstance.impl.Position10Impl <em>Position10</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.impl.Position10Impl
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition10()
	 * @generated
	 */
	int POSITION10 = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION10__NAME = POSITION__NAME;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION10__VALUE = POSITION__VALUE;

	/**
	 * The number of structural features of the '<em>Position10</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION10_FEATURE_COUNT = POSITION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link CollavizInstance.OwnersValue <em>Owners Value</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.OwnersValue
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getOwnersValue()
	 * @generated
	 */
	int OWNERS_VALUE = 8;

	/**
	 * The meta object id for the '{@link CollavizInstance.FileType <em>File Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CollavizInstance.FileType
	 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getFileType()
	 * @generated
	 */
	int FILE_TYPE = 9;

	/**
	 * Returns the meta object for class '{@link CollavizInstance.CollavizModelInstance <em>Collaviz Model Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collaviz Model Instance</em>'.
	 * @see CollavizInstance.CollavizModelInstance
	 * @generated
	 */
	EClass getCollavizModelInstance();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizModelInstance#getObjectInstances <em>Object Instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Object Instances</em>'.
	 * @see CollavizInstance.CollavizModelInstance#getObjectInstances()
	 * @see #getCollavizModelInstance()
	 * @generated
	 */
	EReference getCollavizModelInstance_ObjectInstances();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizModelInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.CollavizModelInstance#getName()
	 * @see #getCollavizModelInstance()
	 * @generated
	 */
	EAttribute getCollavizModelInstance_Name();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizModelInstance#getFileType <em>File Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Type</em>'.
	 * @see CollavizInstance.CollavizModelInstance#getFileType()
	 * @see #getCollavizModelInstance()
	 * @generated
	 */
	EAttribute getCollavizModelInstance_FileType();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.CollavizObjectInstance <em>Collaviz Object Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collaviz Object Instance</em>'.
	 * @see CollavizInstance.CollavizObjectInstance
	 * @generated
	 */
	EClass getCollavizObjectInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.CollavizObjectInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getInstanceOf()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_InstanceOf();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizObjectInstance#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getAttributes()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Attributes();

	/**
	 * Returns the meta object for the containment reference list '{@link CollavizInstance.CollavizObjectInstance#getDependencies <em>Dependencies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependencies</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getDependencies()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Dependencies();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getName()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_Name();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.CollavizObjectInstance#getSupport <em>Support</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Support</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getSupport()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Support();

	/**
	 * Returns the meta object for the reference list '{@link CollavizInstance.CollavizObjectInstance#getSupported <em>Supported</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Supported</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getSupported()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Supported();

	/**
	 * Returns the meta object for the containment reference '{@link CollavizInstance.CollavizObjectInstance#getPosition <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Position</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getPosition()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EReference getCollavizObjectInstance_Position();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getOwners <em>Owners</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Owners</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getOwners()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_Owners();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getAccessLevel <em>Access Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Access Level</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getAccessLevel()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_AccessLevel();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getRefProxy <em>Ref Proxy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ref Proxy</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getRefProxy()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_RefProxy();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getBecomeReferent <em>Become Referent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Become Referent</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getBecomeReferent()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_BecomeReferent();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.CollavizObjectInstance#getBecomeOwner <em>Become Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Become Owner</em>'.
	 * @see CollavizInstance.CollavizObjectInstance#getBecomeOwner()
	 * @see #getCollavizObjectInstance()
	 * @generated
	 */
	EAttribute getCollavizObjectInstance_BecomeOwner();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.DependencyInstance <em>Dependency Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dependency Instance</em>'.
	 * @see CollavizInstance.DependencyInstance
	 * @generated
	 */
	EClass getDependencyInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.DependencyInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.DependencyInstance#getInstanceOf()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EReference getDependencyInstance_InstanceOf();

	/**
	 * Returns the meta object for the reference list '{@link CollavizInstance.DependencyInstance#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Target</em>'.
	 * @see CollavizInstance.DependencyInstance#getTarget()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EReference getDependencyInstance_Target();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.DependencyInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.DependencyInstance#getName()
	 * @see #getDependencyInstance()
	 * @generated
	 */
	EAttribute getDependencyInstance_Name();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.AttributeInstance <em>Attribute Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute Instance</em>'.
	 * @see CollavizInstance.AttributeInstance
	 * @generated
	 */
	EClass getAttributeInstance();

	/**
	 * Returns the meta object for the reference '{@link CollavizInstance.AttributeInstance#getInstanceOf <em>Instance Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance Of</em>'.
	 * @see CollavizInstance.AttributeInstance#getInstanceOf()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EReference getAttributeInstance_InstanceOf();

	/**
	 * Returns the meta object for the attribute list '{@link CollavizInstance.AttributeInstance#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Value</em>'.
	 * @see CollavizInstance.AttributeInstance#getValue()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EAttribute getAttributeInstance_Value();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.AttributeInstance#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.AttributeInstance#getName()
	 * @see #getAttributeInstance()
	 * @generated
	 */
	EAttribute getAttributeInstance_Name();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.Position <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Position</em>'.
	 * @see CollavizInstance.Position
	 * @generated
	 */
	EClass getPosition();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Position#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see CollavizInstance.Position#getName()
	 * @see #getPosition()
	 * @generated
	 */
	EAttribute getPosition_Name();

	/**
	 * Returns the meta object for the attribute '{@link CollavizInstance.Position#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see CollavizInstance.Position#getValue()
	 * @see #getPosition()
	 * @generated
	 */
	EAttribute getPosition_Value();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.Position6 <em>Position6</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Position6</em>'.
	 * @see CollavizInstance.Position6
	 * @generated
	 */
	EClass getPosition6();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.Position9 <em>Position9</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Position9</em>'.
	 * @see CollavizInstance.Position9
	 * @generated
	 */
	EClass getPosition9();

	/**
	 * Returns the meta object for class '{@link CollavizInstance.Position10 <em>Position10</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Position10</em>'.
	 * @see CollavizInstance.Position10
	 * @generated
	 */
	EClass getPosition10();

	/**
	 * Returns the meta object for enum '{@link CollavizInstance.OwnersValue <em>Owners Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Owners Value</em>'.
	 * @see CollavizInstance.OwnersValue
	 * @generated
	 */
	EEnum getOwnersValue();

	/**
	 * Returns the meta object for enum '{@link CollavizInstance.FileType <em>File Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>File Type</em>'.
	 * @see CollavizInstance.FileType
	 * @generated
	 */
	EEnum getFileType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CollavizInstanceFactory getCollavizInstanceFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CollavizModelInstanceImpl <em>Collaviz Model Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CollavizModelInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizModelInstance()
		 * @generated
		 */
		EClass COLLAVIZ_MODEL_INSTANCE = eINSTANCE.getCollavizModelInstance();

		/**
		 * The meta object literal for the '<em><b>Object Instances</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_MODEL_INSTANCE__OBJECT_INSTANCES = eINSTANCE.getCollavizModelInstance_ObjectInstances();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_MODEL_INSTANCE__NAME = eINSTANCE.getCollavizModelInstance_Name();

		/**
		 * The meta object literal for the '<em><b>File Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_MODEL_INSTANCE__FILE_TYPE = eINSTANCE.getCollavizModelInstance_FileType();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.CollavizObjectInstanceImpl <em>Collaviz Object Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.CollavizObjectInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getCollavizObjectInstance()
		 * @generated
		 */
		EClass COLLAVIZ_OBJECT_INSTANCE = eINSTANCE.getCollavizObjectInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__INSTANCE_OF = eINSTANCE.getCollavizObjectInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__ATTRIBUTES = eINSTANCE.getCollavizObjectInstance_Attributes();

		/**
		 * The meta object literal for the '<em><b>Dependencies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__DEPENDENCIES = eINSTANCE.getCollavizObjectInstance_Dependencies();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__NAME = eINSTANCE.getCollavizObjectInstance_Name();

		/**
		 * The meta object literal for the '<em><b>Support</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__SUPPORT = eINSTANCE.getCollavizObjectInstance_Support();

		/**
		 * The meta object literal for the '<em><b>Supported</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__SUPPORTED = eINSTANCE.getCollavizObjectInstance_Supported();

		/**
		 * The meta object literal for the '<em><b>Position</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COLLAVIZ_OBJECT_INSTANCE__POSITION = eINSTANCE.getCollavizObjectInstance_Position();

		/**
		 * The meta object literal for the '<em><b>Owners</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__OWNERS = eINSTANCE.getCollavizObjectInstance_Owners();

		/**
		 * The meta object literal for the '<em><b>Access Level</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__ACCESS_LEVEL = eINSTANCE.getCollavizObjectInstance_AccessLevel();

		/**
		 * The meta object literal for the '<em><b>Ref Proxy</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__REF_PROXY = eINSTANCE.getCollavizObjectInstance_RefProxy();

		/**
		 * The meta object literal for the '<em><b>Become Referent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__BECOME_REFERENT = eINSTANCE.getCollavizObjectInstance_BecomeReferent();

		/**
		 * The meta object literal for the '<em><b>Become Owner</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLAVIZ_OBJECT_INSTANCE__BECOME_OWNER = eINSTANCE.getCollavizObjectInstance_BecomeOwner();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.DependencyInstanceImpl <em>Dependency Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.DependencyInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getDependencyInstance()
		 * @generated
		 */
		EClass DEPENDENCY_INSTANCE = eINSTANCE.getDependencyInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY_INSTANCE__INSTANCE_OF = eINSTANCE.getDependencyInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCY_INSTANCE__TARGET = eINSTANCE.getDependencyInstance_Target();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPENDENCY_INSTANCE__NAME = eINSTANCE.getDependencyInstance_Name();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.AttributeInstanceImpl <em>Attribute Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.AttributeInstanceImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getAttributeInstance()
		 * @generated
		 */
		EClass ATTRIBUTE_INSTANCE = eINSTANCE.getAttributeInstance();

		/**
		 * The meta object literal for the '<em><b>Instance Of</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRIBUTE_INSTANCE__INSTANCE_OF = eINSTANCE.getAttributeInstance_InstanceOf();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE_INSTANCE__VALUE = eINSTANCE.getAttributeInstance_Value();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE_INSTANCE__NAME = eINSTANCE.getAttributeInstance_Name();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.PositionImpl <em>Position</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.PositionImpl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition()
		 * @generated
		 */
		EClass POSITION = eINSTANCE.getPosition();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__NAME = eINSTANCE.getPosition_Name();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__VALUE = eINSTANCE.getPosition_Value();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.Position6Impl <em>Position6</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.Position6Impl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition6()
		 * @generated
		 */
		EClass POSITION6 = eINSTANCE.getPosition6();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.Position9Impl <em>Position9</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.Position9Impl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition9()
		 * @generated
		 */
		EClass POSITION9 = eINSTANCE.getPosition9();

		/**
		 * The meta object literal for the '{@link CollavizInstance.impl.Position10Impl <em>Position10</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.impl.Position10Impl
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getPosition10()
		 * @generated
		 */
		EClass POSITION10 = eINSTANCE.getPosition10();

		/**
		 * The meta object literal for the '{@link CollavizInstance.OwnersValue <em>Owners Value</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.OwnersValue
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getOwnersValue()
		 * @generated
		 */
		EEnum OWNERS_VALUE = eINSTANCE.getOwnersValue();

		/**
		 * The meta object literal for the '{@link CollavizInstance.FileType <em>File Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see CollavizInstance.FileType
		 * @see CollavizInstance.impl.CollavizInstancePackageImpl#getFileType()
		 * @generated
		 */
		EEnum FILE_TYPE = eINSTANCE.getFileType();

	}

} //CollavizInstancePackage
