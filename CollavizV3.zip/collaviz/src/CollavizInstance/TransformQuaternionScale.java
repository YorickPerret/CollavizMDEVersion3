/**
 */
package CollavizInstance;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transform Quaternion Scale</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.TransformQuaternionScale#getQx <em>Qx</em>}</li>
 *   <li>{@link CollavizInstance.TransformQuaternionScale#getQy <em>Qy</em>}</li>
 *   <li>{@link CollavizInstance.TransformQuaternionScale#getQz <em>Qz</em>}</li>
 *   <li>{@link CollavizInstance.TransformQuaternionScale#getQw <em>Qw</em>}</li>
 *   <li>{@link CollavizInstance.TransformQuaternionScale#getSx <em>Sx</em>}</li>
 *   <li>{@link CollavizInstance.TransformQuaternionScale#getSy <em>Sy</em>}</li>
 *   <li>{@link CollavizInstance.TransformQuaternionScale#getSz <em>Sz</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale()
 * @model
 * @generated
 */
public interface TransformQuaternionScale extends Transform {
	/**
	 * Returns the value of the '<em><b>Qx</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Qx</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Qx</em>' attribute.
	 * @see #setQx(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale_Qx()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getQx();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformQuaternionScale#getQx <em>Qx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Qx</em>' attribute.
	 * @see #getQx()
	 * @generated
	 */
	void setQx(Double value);

	/**
	 * Returns the value of the '<em><b>Qy</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Qy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Qy</em>' attribute.
	 * @see #setQy(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale_Qy()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getQy();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformQuaternionScale#getQy <em>Qy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Qy</em>' attribute.
	 * @see #getQy()
	 * @generated
	 */
	void setQy(Double value);

	/**
	 * Returns the value of the '<em><b>Qz</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Qz</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Qz</em>' attribute.
	 * @see #setQz(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale_Qz()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getQz();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformQuaternionScale#getQz <em>Qz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Qz</em>' attribute.
	 * @see #getQz()
	 * @generated
	 */
	void setQz(Double value);

	/**
	 * Returns the value of the '<em><b>Qw</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Qw</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Qw</em>' attribute.
	 * @see #setQw(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale_Qw()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getQw();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformQuaternionScale#getQw <em>Qw</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Qw</em>' attribute.
	 * @see #getQw()
	 * @generated
	 */
	void setQw(Double value);

	/**
	 * Returns the value of the '<em><b>Sx</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sx</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sx</em>' attribute.
	 * @see #setSx(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale_Sx()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getSx();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformQuaternionScale#getSx <em>Sx</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sx</em>' attribute.
	 * @see #getSx()
	 * @generated
	 */
	void setSx(Double value);

	/**
	 * Returns the value of the '<em><b>Sy</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sy</em>' attribute.
	 * @see #setSy(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale_Sy()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getSy();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformQuaternionScale#getSy <em>Sy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sy</em>' attribute.
	 * @see #getSy()
	 * @generated
	 */
	void setSy(Double value);

	/**
	 * Returns the value of the '<em><b>Sz</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sz</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sz</em>' attribute.
	 * @see #setSz(Double)
	 * @see CollavizInstance.CollavizInstancePackage#getTransformQuaternionScale_Sz()
	 * @model default="0.0" dataType="Collaviz.double" required="true"
	 * @generated
	 */
	Double getSz();

	/**
	 * Sets the value of the '{@link CollavizInstance.TransformQuaternionScale#getSz <em>Sz</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sz</em>' attribute.
	 * @see #getSz()
	 * @generated
	 */
	void setSz(Double value);
	
	void setQXQYQZQW(String qxqyqzqw);
	
	String getQXQYQZQW();
	
	void setSXSYSZ(String sxsysz);
	
	String getSXSYSZ();

} // TransformQuaternionScale
