/**
 */
package CollavizInstance;

import Collaviz.CollavizObject;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collaviz Object Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getInstanceOf <em>Instance Of</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getDependencies <em>Dependencies</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getName <em>Name</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getSupport <em>Support</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getSupported <em>Supported</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getPosition <em>Position</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getOwners <em>Owners</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getAccessLevel <em>Access Level</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getRefProxy <em>Ref Proxy</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getBecomeReferent <em>Become Referent</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getBecomeOwner <em>Become Owner</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getColor <em>Color</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='DependencyMustBeSet DependencyInstanceIsUnique DependencyOnlyInObjectDefinition AttributeMustBeSet AttributeInstanceIsUnique AttributeOnlyInObjectDefinition'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL DependencyMustBeSet='let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependencies->forAll(d : Collaviz::GenericAttribute | dependenciesInstance->includes(d)) and dependencies->size() <= dependenciesInstance->size()' DependencyInstanceIsUnique='let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(d1 : Collaviz::Dependency |  dependenciesInstance->count(d1)=1)' DependencyOnlyInObjectDefinition='let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(di : Collaviz::Dependency | dependencies->includes(di))' AttributeMustBeSet='let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributes->forAll(a : Collaviz::GenericAttribute | attributesInstance->includes(a)) and attributes->size() <= attributesInstance->size()' AttributeInstanceIsUnique='let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(a : Collaviz::Attribute |  attributesInstance->count(a)=1)' AttributeOnlyInObjectDefinition='let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(ai : Collaviz::Attribute | attributes->includes(ai))'"
 * @generated
 */
public interface CollavizObjectInstance extends EObject {
	/**
	 * Returns the value of the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instance Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance Of</em>' reference.
	 * @see #setInstanceOf(CollavizObject)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_InstanceOf()
	 * @model required="true"
	 * @generated
	 */
	CollavizObject getInstanceOf();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getInstanceOf <em>Instance Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instance Of</em>' reference.
	 * @see #getInstanceOf()
	 * @generated
	 */
	void setInstanceOf(CollavizObject value);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link CollavizInstance.AttributeInstance}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Attributes()
	 * @model containment="true"
	 * @generated
	 */
	EList<AttributeInstance> getAttributes();

	/**
	 * Returns the value of the '<em><b>Dependencies</b></em>' containment reference list.
	 * The list contents are of type {@link CollavizInstance.DependencyInstance}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dependencies</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependencies</em>' containment reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Dependencies()
	 * @model containment="true"
	 * @generated
	 */
	EList<DependencyInstance> getDependencies();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Name()
	 * @model id="true" dataType="Collaviz.String" required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Support</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link CollavizInstance.CollavizObjectInstance#getSupported <em>Supported</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Support</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Support</em>' reference.
	 * @see #setSupport(CollavizObjectInstance)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Support()
	 * @see CollavizInstance.CollavizObjectInstance#getSupported
	 * @model opposite="supported"
	 * @generated
	 */
	CollavizObjectInstance getSupport();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getSupport <em>Support</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Support</em>' reference.
	 * @see #getSupport()
	 * @generated
	 */
	void setSupport(CollavizObjectInstance value);

	/**
	 * Returns the value of the '<em><b>Supported</b></em>' reference list.
	 * The list contents are of type {@link CollavizInstance.CollavizObjectInstance}.
	 * It is bidirectional and its opposite is '{@link CollavizInstance.CollavizObjectInstance#getSupport <em>Support</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Supported</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Supported</em>' reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Supported()
	 * @see CollavizInstance.CollavizObjectInstance#getSupport
	 * @model opposite="support"
	 * @generated
	 */
	EList<CollavizObjectInstance> getSupported();

	/**
	 * Returns the value of the '<em><b>Position</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Position</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Position</em>' containment reference.
	 * @see #setPosition(Transform)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Position()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Transform getPosition();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getPosition <em>Position</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Position</em>' containment reference.
	 * @see #getPosition()
	 * @generated
	 */
	void setPosition(Transform value);

	/**
	 * Returns the value of the '<em><b>Owners</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * The literals are from the enumeration {@link CollavizInstance.OwnersValue}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owners</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owners</em>' attribute.
	 * @see CollavizInstance.OwnersValue
	 * @see #setOwners(OwnersValue)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Owners()
	 * @model default="0" required="true"
	 * @generated
	 */
	OwnersValue getOwners();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getOwners <em>Owners</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owners</em>' attribute.
	 * @see CollavizInstance.OwnersValue
	 * @see #getOwners()
	 * @generated
	 */
	void setOwners(OwnersValue value);

	/**
	 * Returns the value of the '<em><b>Access Level</b></em>' attribute.
	 * The default value is <code>"3"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Access Level</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Access Level</em>' attribute.
	 * @see #setAccessLevel(Integer)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_AccessLevel()
	 * @model default="3" dataType="Collaviz.int" required="true"
	 * @generated
	 */
	Integer getAccessLevel();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getAccessLevel <em>Access Level</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Access Level</em>' attribute.
	 * @see #getAccessLevel()
	 * @generated
	 */
	void setAccessLevel(Integer value);

	/**
	 * Returns the value of the '<em><b>Ref Proxy</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ref Proxy</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ref Proxy</em>' attribute.
	 * @see #setRefProxy(Boolean)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_RefProxy()
	 * @model default="true" dataType="Collaviz.boolean" required="true"
	 * @generated
	 */
	Boolean getRefProxy();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getRefProxy <em>Ref Proxy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ref Proxy</em>' attribute.
	 * @see #getRefProxy()
	 * @generated
	 */
	void setRefProxy(Boolean value);

	/**
	 * Returns the value of the '<em><b>Become Referent</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Become Referent</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Become Referent</em>' attribute.
	 * @see #setBecomeReferent(Boolean)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_BecomeReferent()
	 * @model default="true" dataType="Collaviz.boolean" required="true"
	 * @generated
	 */
	Boolean getBecomeReferent();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getBecomeReferent <em>Become Referent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Become Referent</em>' attribute.
	 * @see #getBecomeReferent()
	 * @generated
	 */
	void setBecomeReferent(Boolean value);

	/**
	 * Returns the value of the '<em><b>Become Owner</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Become Owner</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Become Owner</em>' attribute.
	 * @see #setBecomeOwner(Boolean)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_BecomeOwner()
	 * @model default="true" dataType="Collaviz.boolean" required="true"
	 * @generated
	 */
	Boolean getBecomeOwner();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getBecomeOwner <em>Become Owner</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Become Owner</em>' attribute.
	 * @see #getBecomeOwner()
	 * @generated
	 */
	void setBecomeOwner(Boolean value);

	/**
	 * Returns the value of the '<em><b>Color</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Color</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Color</em>' containment reference.
	 * @see #setColor(Color)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Color()
	 * @model containment="true"
	 * @generated
	 */
	Color getColor();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getColor <em>Color</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Color</em>' containment reference.
	 * @see #getColor()
	 * @generated
	 */
	void setColor(Color value);

} // CollavizObjectInstance
