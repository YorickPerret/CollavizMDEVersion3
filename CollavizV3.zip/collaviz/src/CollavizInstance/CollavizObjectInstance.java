/**
 */
package CollavizInstance;

import Collaviz.CollavizObject;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collaviz Object Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getInstanceOf <em>Instance Of</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getDependencies <em>Dependencies</em>}</li>
 *   <li>{@link CollavizInstance.CollavizObjectInstance#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='DependencyMustBeSet DependencyInstanceIsUnique DependencyOnlyInObjectDefinition AttributeMustBeSet AttributeInstanceIsUnique AttributeOnlyInObjectDefinition'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL DependencyMustBeSet='let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency) and ga.lowerBound>0)\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependencies->forAll(d : Collaviz::GenericAttribute | dependenciesInstance->includes(d)) and dependencies->size() <= dependenciesInstance->size()' DependencyInstanceIsUnique='let dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(d1 : Collaviz::Dependency |  dependenciesInstance->count(d1)=1)' DependencyOnlyInObjectDefinition='let dependenciesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependenciesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Dependency))\r\nin\r\nlet dependencies : Sequence(Collaviz::GenericAttribute)=dependenciesInstanceOf->asSequence()->union(dependenciesSuper)\r\nin\r\nlet dependenciesInstance : Sequence(Collaviz::Dependency)=self.dependencies.instanceOf\r\nin\r\ndependenciesInstance->forAll(di : Collaviz::Dependency | dependencies->includes(di))' AttributeMustBeSet='let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute) and ga.lowerBound>0)\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributes->forAll(a : Collaviz::GenericAttribute | attributesInstance->includes(a)) and attributes->size() <= attributesInstance->size()' AttributeInstanceIsUnique='let attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(a : Collaviz::Attribute |  attributesInstance->count(a)=1)' AttributeOnlyInObjectDefinition='let attributesSuper : Sequence(Collaviz::GenericAttribute)=self.instanceOf.getAllSuperTypes().attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributesInstanceOf : OrderedSet(Collaviz::GenericAttribute)=self.instanceOf.attributes->select(ga : Collaviz::GenericAttribute | ga.oclIsTypeOf(Collaviz::Attribute))\r\nin\r\nlet attributes : Sequence(Collaviz::GenericAttribute)=attributesInstanceOf->asSequence()->union(attributesSuper)\r\nin\r\nlet attributesInstance : Sequence(Collaviz::Attribute)=self.attributes.instanceOf\r\nin\r\nattributesInstance->forAll(ai : Collaviz::Attribute | attributes->includes(ai))'"
 * @generated
 */
public interface CollavizObjectInstance extends EObject {
	/**
	 * Returns the value of the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instance Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance Of</em>' reference.
	 * @see #setInstanceOf(CollavizObject)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_InstanceOf()
	 * @model required="true"
	 * @generated
	 */
	CollavizObject getInstanceOf();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getInstanceOf <em>Instance Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instance Of</em>' reference.
	 * @see #getInstanceOf()
	 * @generated
	 */
	void setInstanceOf(CollavizObject value);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link CollavizInstance.AttributeInstance}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Attributes()
	 * @model containment="true"
	 * @generated
	 */
	EList<AttributeInstance> getAttributes();

	/**
	 * Returns the value of the '<em><b>Dependencies</b></em>' containment reference list.
	 * The list contents are of type {@link CollavizInstance.DependencyInstance}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dependencies</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependencies</em>' containment reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Dependencies()
	 * @model containment="true"
	 * @generated
	 */
	EList<DependencyInstance> getDependencies();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see CollavizInstance.CollavizInstancePackage#getCollavizObjectInstance_Name()
	 * @model dataType="CollavizInstance.String" required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link CollavizInstance.CollavizObjectInstance#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // CollavizObjectInstance
