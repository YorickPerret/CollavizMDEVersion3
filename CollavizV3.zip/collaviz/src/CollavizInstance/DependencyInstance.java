/**
 */
package CollavizInstance;

import Collaviz.Dependency;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dependency Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CollavizInstance.DependencyInstance#getInstanceOf <em>Instance Of</em>}</li>
 *   <li>{@link CollavizInstance.DependencyInstance#getTarget <em>Target</em>}</li>
 *   <li>{@link CollavizInstance.DependencyInstance#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see CollavizInstance.CollavizInstancePackage#getDependencyInstance()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='DependencyInstanceTargetNumber DependencyInstanceTargetGoodType'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL DependencyInstanceTargetNumber='if self.instanceOf.upperBound=-1 then\r\n\tself.target->size()>=self.instanceOf.lowerBound\r\nelse\r\n\tself.target->size()>=self.instanceOf.lowerBound and self.target->size()<=self.instanceOf.upperBound\r\nendif' DependencyInstanceTargetGoodType='self.target->forAll(t : CollavizObjectInstance | \t\t\r\n\tlet superTypes : Sequence(Collaviz::CollavizObject)=t.instanceOf.getAllSuperTypes()->union(Sequence{t.instanceOf})\r\n\tin\r\n\tsuperTypes->includes(self.instanceOf.type))'"
 * @generated
 */
public interface DependencyInstance extends EObject {
	/**
	 * Returns the value of the '<em><b>Instance Of</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instance Of</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance Of</em>' reference.
	 * @see #setInstanceOf(Dependency)
	 * @see CollavizInstance.CollavizInstancePackage#getDependencyInstance_InstanceOf()
	 * @model required="true"
	 * @generated
	 */
	Dependency getInstanceOf();

	/**
	 * Sets the value of the '{@link CollavizInstance.DependencyInstance#getInstanceOf <em>Instance Of</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instance Of</em>' reference.
	 * @see #getInstanceOf()
	 * @generated
	 */
	void setInstanceOf(Dependency value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference list.
	 * The list contents are of type {@link CollavizInstance.CollavizObjectInstance}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference list.
	 * @see CollavizInstance.CollavizInstancePackage#getDependencyInstance_Target()
	 * @model required="true"
	 * @generated
	 */
	EList<CollavizObjectInstance> getTarget();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see CollavizInstance.CollavizInstancePackage#getDependencyInstance_Name()
	 * @model default="" dataType="Collaviz.String" changeable="false" derived="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL derivation='if self.instanceOf.oclIsUndefined() then\r\n\t\'\'\r\nelse\r\n\tself.instanceOf.name\r\nendif'"
	 * @generated
	 */
	String getName();

} // DependencyInstance
