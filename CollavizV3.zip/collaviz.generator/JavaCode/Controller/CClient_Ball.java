package org.collaviz.iivc.control.client;
import org.collaviz.collaboration.objects.abstraction.IA_SharedObject ;
import org.collaviz.collaboration.objects.control.client.CClient_ObjectManager ;
import org.collaviz.iivc.control.IC_Ball ;

public class CClient_Ball extends CClient_SupportedObject implements IC_Ball {

	public CClient_Ball(IA_SharedObject abstraction, boolean referentProxyArchi, int accessLevel, CClient_ObjectManager objectManager) {
		super (abstraction, referentProxyArchi, accessLevel, objectManager) ;
	}


}