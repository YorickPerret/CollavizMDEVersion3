package org.collaviz.iivc.control.service;
import org.collaviz.collaboration.objects.abstraction.IA_SharedObject ;
import org.collaviz.collaboration.objects.control.service.CService_ObjectManager ;
import org.collaviz.iivc.control.IC_Ball ;

public class CService_Ball extends CService_SupportedObject implements IC_Ball {

	public CService_Ball(IA_SharedObject abstraction, boolean referentProxyArchi, int accessLevel, CService_ObjectManager objectManager) {
		super (abstraction, referentProxyArchi, accessLevel, objectManager) ;
	}


}