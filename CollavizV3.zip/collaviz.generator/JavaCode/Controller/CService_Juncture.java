package org.collaviz.iivc.control.service;
import org.collaviz.collaboration.objects.abstraction.IA_SharedObject ;
import org.collaviz.collaboration.objects.control.service.CService_ObjectManager ;
import org.collaviz.iivc.control.IC_Juncture ;

public class CService_Juncture extends CService_SupportedObject implements IC_Juncture {

	public CService_Juncture(IA_SharedObject abstraction, boolean referentProxyArchi, int accessLevel, CService_ObjectManager objectManager) {
		super (abstraction, referentProxyArchi, accessLevel, objectManager) ;
	}

	@Override
	public void setNewRadius (double newRadius){
		callModificationMethod ("setNewRadius",newRadius);
	}


}