package org.collaviz.clientJava3D.pJava3D;

import java.util.Map ;
import javax.vecmath.Quat4d ;
import javax.vecmath.Vector3d ;
import org.collaviz.collaboration.objects.control.IC_SharedObject ;

public class PJava3D_Juncture extends PJava3D_DeformableObject implements IPJava3D_Juncture {

	protected double radius;
	protected double length;

	public PJava3D_Juncture (IC_SharedObject ctr, Vector3d translation, Quat4d rotation, Vector3d scale, PJava3D_ObjectManager presObjManager, String geometry, double _radius, double _length) {
		super (ctr, translation, rotation, scale, geometry, presObjManager);

		this.radius = _radius;
		this.length = _length;

	}

	@Override
	public void update(String userId, Map<String, Object> params, IC_SharedObject source) {
		super.update (userId, params, source);

		double _radius = (double)params.get("Radius");
		if(_radius!=null){
			this.radius=_radius;
			updateRadius();
		}

		double _length = (double)params.get("Length");
		if(_length!=null){
			this.length=_length;
			updateLength();
		}

	}

	public void updateRadius(double radius){

	}
	public void updateLength(double length){

	}

}