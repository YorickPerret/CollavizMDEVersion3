package org.collaviz.clientJava3D.pJava3D;



public interface IPJava3D_Juncture{
	public void updateRadius(double radius);
	public void updateLength(double length);

}