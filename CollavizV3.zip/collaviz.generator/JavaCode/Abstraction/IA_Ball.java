package org.collaviz.iivc.abstraction



public interface IA_Ball {

}