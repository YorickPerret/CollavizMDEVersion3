package org.collaviz.iivc.abstraction;
import org.collaviz.collaboration.objects.control.IC_ObjectManager ;
import org.collaviz.collaboration.objects.utils.ICallbackHandler ;
import org.collaviz.collaboration.objects.utils.Transform ;

public class A_Juncture extends A_SupportedObject implements IA_Juncture {

	protected double radius;

	public A_Juncture (String objectType, String objectName, IC_ObjectManager objectManager) {
		super (objectType, objectName, objectManager) ;

		parameters.put("Radius",radius);

		registerModificationCallback ("setNewRadius", new ICallbackHandler () {
			@Override
			public void callback (Object [] args) {
				final double _newRadius = (double)args[0];
				setNewRadius(_newRadius);
			}
		});

	}

	@Override
	public void setNewRadius (double newRadius){
		//you have to add modifications.put("ParameterName", val);
		//for each parameter you want to update
 	}

	@Override
	protected void processUpdate (Map<String, Object> params) {
		super.processUpdate (params) ;

		final double _radius = (double)params.get("Radius");
		if(_radius!=null){
			this.radius=_radius;
			parameters.put("Radius",this.radius);
		}

	}
	@Override
	protected void processModify (Map<String, Object> params) {
		super.processModify (params) ;

		final double _radius = (double)params.get("Radius");
		if(_radius!=null){
			this.radius=_radius;
			modifications.put("Radius",this.radius);
		}

	}

}