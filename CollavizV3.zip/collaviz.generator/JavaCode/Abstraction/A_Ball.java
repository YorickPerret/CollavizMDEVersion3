package org.collaviz.iivc.abstraction;
import org.collaviz.collaboration.objects.control.IC_ObjectManager ;
import org.collaviz.collaboration.objects.utils.ICallbackHandler ;
import org.collaviz.collaboration.objects.utils.Transform ;

public class A_Ball extends A_SupportedObject implements IA_Ball {


	public A_Ball (String objectType, String objectName, IC_ObjectManager objectManager) {
		super (objectType, objectName, objectManager) ;



	}

	@Override
	protected void processUpdate (Map<String, Object> params) {
		super.processUpdate (params) ;

	}
	@Override
	protected void processModify (Map<String, Object> params) {
		super.processModify (params) ;

	}

}